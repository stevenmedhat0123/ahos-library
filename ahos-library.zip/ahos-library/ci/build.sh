#!/usr/bin/env bash
# Builds a signed release APK. Called by .github/workflows/build-apk.yml (project root = current dir).
# Needs: BUILD_NUMBER, REPO, AHOS_SIGNING (secret), and Node 22 + JDK 21 + Android SDK (preinstalled on GitHub runners).
set -euo pipefail

say() { printf '\n=== %s ===\n' "$*"; }

if [ -z "${AHOS_SIGNING:-}" ]; then
  cat <<'MSG'
::error title=Signing key missing::The secret AHOS_SIGNING is not set. Add it in: Settings > Secrets and variables > Actions > New repository secret. See README. / سر التوقيع AHOS_SIGNING غير مضاف - راجع ملف README.
MSG
  exit 1
fi

VERSION=$(node -p "require('./release.json').version")
CHANNEL=$(node -p "require('./release.json').channel === 'stable' ? 'stable' : 'beta'")
NOTES=$(node -p "require('./release.json').notes || ''")
N="${BUILD_NUMBER:?BUILD_NUMBER missing}"
export BUILD_NUMBER="$N"

say "AHOS Library $VERSION ($CHANNEL) build $N"

say "Signing key"
KS="$PWD/release.keystore"
printf '%s' "$AHOS_SIGNING" | head -n 1 | tr -d '\r\n ' > .store-pass
printf '%s' "$AHOS_SIGNING" | tail -n +2 | tr -d '\r\n ' | base64 -d > "$KS"
export AHOS_KEYSTORE="$KS"
export AHOS_STORE_PASSWORD="$(cat .store-pass)"
export AHOS_KEY_ALIAS="ahos"
rm -f .store-pass
keytool -list -keystore "$KS" -storepass "$AHOS_STORE_PASSWORD" -alias ahos >/dev/null \
  || { echo "::error title=Bad signing key::AHOS_SIGNING could not be read. Copy the whole file content again. / ملف المفتاح غير صالح - انسخ محتوى الملف كاملا"; exit 1; }
echo "signing key OK"

say "Install"
npm install --no-audit --no-fund

say "Stamp version"
node tools/stamp.mjs

say "Android build"
# First try with the native playback plugin. If the Android build rejects it for any reason,
# rebuild without it so a release is never blocked by the optional extra (the app then plays in the foreground only).
NATIVE=1
if ! bash ci/android.sh 1; then
  echo "::warning title=Native playback plugin skipped::The build with the native plugin failed, building without it. / تم البناء بدون الإضافة الأصلية"
  NATIVE=0
  rm -rf android
  bash ci/android.sh 0
fi

say "Collect"
APK_SRC=$(find android/app/build/outputs/apk/release -name '*.apk' | head -n 1)
[ -n "$APK_SRC" ] || { echo "::error::APK not found"; exit 1; }
mkdir -p dist
APK="dist/AHOS-Library-${VERSION}-build${N}.apk"
cp "$APK_SRC" "$APK"

APKSIGNER=$(find "${ANDROID_HOME:-/usr/local/lib/android/sdk}/build-tools" -name apksigner 2>/dev/null | sort | tail -n 1 || true)
if [ -n "$APKSIGNER" ]; then "$APKSIGNER" verify --print-certs "$APK" | grep -E 'Signer #1 certificate (DN|SHA-256)' || true; fi

{
  echo "**AHOS Library $VERSION** · build $N · ${CHANNEL}"
  echo
  [ -n "$NOTES" ] && echo "$NOTES" && echo
  if [ "$NATIVE" = "0" ]; then
    echo "> Note: this build has no background-playback notification (the optional native part could not be built)."
    echo "> ملاحظة: النسخة دي من غير إشعار التشغيل في الخلفية (الجزء الأصلي ماتبناش)."
    echo
  fi
  echo "Install: download the .apk on your Android phone and open it. Updating keeps your library."
  echo "التثبيت: نزّل ملف apk على الموبايل وافتحه. التحديث بيحافظ على مكتبتك."
} > dist/notes.md

if [ -n "${GITHUB_OUTPUT:-}" ]; then
  {
    echo "apk=$APK"
    echo "tag=build-$N"
    echo "title=AHOS Library $VERSION (${CHANNEL}) · build $N"
    echo "prerelease=$([ "$CHANNEL" = beta ] && echo true || echo false)"
  } >> "$GITHUB_OUTPUT"
fi
echo "done: $APK"
