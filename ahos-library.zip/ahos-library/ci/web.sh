#!/usr/bin/env bash
# Publishes the web (Chrome) version = the same www folder, marked as a web copy, to the gh-pages branch.
# Called by ci/build.sh. It must never fail the APK build, so every problem here only prints a warning.
set -uo pipefail

[ -d www ] || { echo "web: no www folder, skipped"; exit 0; }
[ -f www/update.json ] || { echo "web: update.json missing (run tools/stamp.mjs first), skipped"; exit 0; }

REMOTE="${WEB_REMOTE:-}"
HEADER=""
if [ -z "$REMOTE" ]; then
  [ -n "${REPO:-}" ] && [ -n "${GITHUB_WORKSPACE:-}" ] || { echo "web: not running on GitHub, skipped"; exit 0; }
  REMOTE="https://github.com/${REPO}.git"
  HEADER=$(git -C "$GITHUB_WORKSPACE" config --get http.https://github.com/.extraheader 2>/dev/null || true)
  if [ -z "$HEADER" ]; then
    echo "::warning title=Web version skipped::No git credentials were found, so the web version was not published. The APK is not affected. / ما لقيتش صلاحية الرفع، فنسخة الويب ماتنشرتش. الـ APK مش متأثر."
    exit 0
  fi
fi

OUT=$(mktemp -d)
cp -r www/. "$OUT/"
# mark the copy as a web page: no APK update checks, no build-number noise
node -e "
const fs=require('fs');const f='$OUT/update.json';const j=JSON.parse(fs.readFileSync(f,'utf8'));j.web=true;fs.writeFileSync(f,JSON.stringify(j,null,2)+'\n');"
touch "$OUT/.nojekyll"

VERSION=$(node -p "require('./release.json').version")
cd "$OUT"
git init -q -b gh-pages
git config user.name "github-actions[bot]"
git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
git add -A
git commit -q -m "Web version ${VERSION} (build ${BUILD_NUMBER:-0})"
if [ -n "$HEADER" ]; then
  timeout 180 git -c "http.https://github.com/.extraheader=${HEADER}" push -f "$REMOTE" gh-pages 2>&1 | sed 's/AUTHORIZATION: basic [^ ]*/AUTHORIZATION: ***/'
else
  timeout 180 git push -f "$REMOTE" gh-pages 2>&1
fi
RC=${PIPESTATUS[0]}
if [ "$RC" -ne 0 ]; then
  echo "::warning title=Web version not published::Pushing the gh-pages branch failed (code $RC). The APK is not affected. / فشل رفع نسخة الويب. الـ APK مش متأثر."
  exit 0
fi
echo "web: published to the gh-pages branch (v${VERSION})"
