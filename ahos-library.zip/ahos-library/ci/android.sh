#!/usr/bin/env bash
# Generates the Android project and builds the release APK.  Usage: bash ci/android.sh <native 0|1>
# native=1 adds the optional native playback plugin (background audio + notification + keep-screen-on).
set -euo pipefail
NATIVE="${1:-0}"

echo "--- Android project (native extras: $NATIVE)"
rm -rf android
npx cap add android
node tools/patch-android.mjs
if [ "$NATIVE" = "1" ]; then node tools/patch-native.mjs; fi
npx cap sync android

echo "--- Accept SDK licenses"
if [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
fi

echo "--- Gradle build"
( cd android && chmod +x gradlew && ./gradlew --no-daemon --stacktrace assembleRelease )
