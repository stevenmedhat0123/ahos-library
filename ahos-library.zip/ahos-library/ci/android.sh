#!/usr/bin/env bash
# Generates the Android project and builds the release APK.  Usage: bash ci/android.sh <extras>
# extras: 0 = none, base = native playback plugin + updater, folder = base + folder / Google Drive picker,
#         share = base + "Share / Open with" + phone storage, folder+share = everything.
set -euo pipefail
NATIVE="${1:-0}"

echo "--- Android project (native extras: $NATIVE)"
rm -rf android
npx cap add android
node tools/patch-android.mjs
if [ "$NATIVE" != "0" ]; then node tools/patch-native.mjs "$NATIVE"; fi
npx cap sync android

echo "--- Accept SDK licenses"
if [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
fi

echo "--- Gradle build"
# The whole Gradle output goes to a file (it can be tens of thousands of lines); only the reason is printed when it fails.
LOG="$PWD/build-${NATIVE//+/_}-c${AHOS_COSMETIC:-1}.log"
set +e
( cd android && chmod +x gradlew && ./gradlew --no-daemon --console=plain --stacktrace assembleRelease ) > "$LOG" 2>&1
RC=$?
set -e
if [ "$RC" -ne 0 ]; then
  WHY=$( { grep -m1 -A12 "What went wrong" "$LOG" | cut -c1-260; grep -E "\.java:[0-9]+: error|error: |AAPT: error|Android resource (linking|compilation) failed|OutOfMemoryError|Unsupported class file|Could not (resolve|find|get|download)" "$LOG" | sort -u | head -15 | cut -c1-260; } | head -30 ) || true
  echo "::error title=Android build failed (extras: $NATIVE, cosmetic: ${AHOS_COSMETIC:-1})::$(printf '%s' "$WHY" | sed ':a;N;$!ba;s/\n/%0A/g')"
  echo "----- why the Android build failed (extras: $NATIVE, cosmetic: ${AHOS_COSMETIC:-1}) -----"
  printf '%s\n' "$WHY"
  echo "----- last 40 lines of the Gradle output -----"
  tail -n 40 "$LOG" | cut -c1-260
  if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
    { echo "### Android build failed (extras: $NATIVE, cosmetic: ${AHOS_COSMETIC:-1})"; echo '```'; printf '%s\n' "$WHY"; echo '```'; } >> "$GITHUB_STEP_SUMMARY"
  fi
  exit "$RC"
fi
tail -n 3 "$LOG"
