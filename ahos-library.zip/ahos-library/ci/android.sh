#!/usr/bin/env bash
# Generates the Android project and builds the release APK.  Usage: bash ci/android.sh <extras>
# extras: 0 = none, base = native playback plugin + updater, folder = base + folder / Google Drive picker,
#         share = base + "Share / Open with" + phone storage, folder+share = everything.
set -euo pipefail
NATIVE="${1:-0}"

echo "--- Android project (native extras: $NATIVE)"
rm -rf android
npx cap add android
node tools/patch-android.mjs
if [ "$NATIVE" != "0" ]; then node tools/patch-native.mjs "$NATIVE"; fi
npx cap sync android

echo "--- Accept SDK licenses"
if [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
fi

echo "--- Gradle build"
( cd android && chmod +x gradlew && ./gradlew --no-daemon --stacktrace assembleRelease )
