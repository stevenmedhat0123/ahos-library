// The notification centre (the bell on the Hub): messages are kept on the phone in a small inbox; the owner's broadcasts will land here too.
import { h } from './util.js';
import { ic } from './icons.js';
import { t, lang } from './i18n.js';
import { openSheet } from './ui.js';

const KEY = 'ahos.inbox';
const MAX = 80;
const listeners = new Set();
let cache = null;

function load() {
  if (cache) return cache;
  try { const a = JSON.parse(localStorage.getItem(KEY) || '[]'); cache = Array.isArray(a) ? a.slice(0, MAX) : []; } catch { cache = []; }
  return cache;
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(cache)); } catch { /* storage blocked: kept in memory for this session */ }
  listeners.forEach((f) => { try { f(); } catch { /* a listener must never break the others */ } });
}

export const inboxItems = () => load();
export const inboxUnread = () => load().reduce((n, m) => n + (m.read ? 0 : 1), 0);
/** Calls fn whenever the inbox changes; returns a function that stops it. */
export function onInbox(fn) { listeners.add(fn); return () => listeners.delete(fn); }

/** Adds a message ({title, text, id?}); the same id twice is ignored, so a message fetched again never doubles. */
export function addInbox({ id, title = '', text = '', time = Date.now() }) {
  const a = load();
  const mid = id || `${time}-${Math.random().toString(36).slice(2, 7)}`;
  if (a.some((m) => m.id === mid)) return false;
  a.unshift({ id: mid, title, text, time, read: false });
  if (a.length > MAX) a.length = MAX;
  save();
  return true;
}
export function markAllRead() { let ch = false; load().forEach((m) => { if (!m.read) { m.read = true; ch = true; } }); if (ch) save(); }
export function clearInbox() { cache = []; save(); }

const when = (ts) => new Date(ts).toLocaleString(lang() === 'ar' ? 'ar-EG' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/** The sheet with the messages. Opening it marks them read (the badge goes away) once it is closed, so unread ones can still be told apart while reading. */
export function openInbox() {
  const items = load().slice();
  const unreadIds = new Set(items.filter((m) => !m.read).map((m) => m.id));
  const sheet = openSheet({ title: t('bell_title'), onClose: () => markAllRead() });
  sheet.body.append(
    h('div', { class: 'inbox' },
      items.length
        ? items.map((m) => h('article', { class: 'inbox-item' + (unreadIds.has(m.id) ? ' new' : '') },
          h('div', { class: 'inbox-hd' }, h('b', { dir: 'auto' }, m.title || t('bell_title')), h('small', null, when(m.time))),
          m.text ? h('p', { dir: 'auto' }, m.text) : null))
        : h('div', { class: 'inbox-empty' }, h('span', { html: ic('bell') }), h('p', null, t('bell_empty')))),
    items.length ? h('button', { class: 'btn ghost sm inbox-clear', type: 'button', onClick: () => { clearInbox(); sheet.close(); } }, t('bell_clear')) : null);
  return sheet;
}
