// Thin wrappers around Capacitor (Android app) with safe web fallbacks.
// The app is plain JS with no bundler, so plugins are reached through the native bridge at runtime.
import { isNative, extOf } from './util.js';

const cap = () => window.Capacitor;

async function call(plugin, method, opts) {
  const c = cap();
  if (!c) throw new Error('Capacitor missing');
  const p = c.Plugins && c.Plugins[plugin];
  if (p && typeof p[method] === 'function') return p[method](opts);
  if (typeof c.nativePromise === 'function') return c.nativePromise(plugin, method, opts || {});
  throw new Error(`Plugin ${plugin} unavailable`);
}

export async function onHardwareBack(handler) {
  if (!isNative()) return;
  try {
    const c = cap();
    const app = c.Plugins && c.Plugins.App;
    if (app && typeof app.addListener === 'function') await app.addListener('backButton', handler);
    else if (typeof c.nativeCallback === 'function') c.nativeCallback('App', 'addListener', { eventName: 'backButton' }, handler);
  } catch (e) { console.warn('back button hook failed', e); }
}

export const exitApp = () => call('App', 'exitApp').catch(() => {});

/** Opens a link in the phone's browser (used for downloading updates). */
export async function openExternal(url) {
  if (isNative()) {
    try { await call('App', 'openUrl', { url }); return; } catch { /* fall back below */ }
  }
  window.open(url, '_blank', 'noopener');
}

export async function immersive(on) {
  if (!isNative()) return;
  try { await call('SystemBars', on ? 'hide' : 'show', {}); return; } catch { /* older Capacitor, try the StatusBar plugin */ }
  try { await call('StatusBar', on ? 'hide' : 'show'); } catch { /* optional */ }
}

export async function lockOrientation(mode) {
  // mode: 'landscape' | 'portrait' | null (unlock)
  try {
    if (isNative()) {
      if (mode) await call('ScreenOrientation', 'lock', { orientation: mode });
      else await call('ScreenOrientation', 'unlock');
      return;
    }
    if (screen.orientation?.lock) {
      if (mode) await screen.orientation.lock(mode); else screen.orientation.unlock();
    }
  } catch { /* not supported or not in fullscreen */ }
}

let wake = null;
export async function keepAwake(on) {
  try {
    if (on) { if (!wake && navigator.wakeLock) wake = await navigator.wakeLock.request('screen'); }
    else if (wake) { await wake.release(); wake = null; }
  } catch { wake = null; }
}

/* ---------------- export / share ---------------- */
const CHUNK = 3 * 1024 * 1024; // multiple of 3 so base64 chunks concatenate cleanly

function blobToBase64(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1] || '');
    r.onerror = () => rej(r.error);
    r.readAsDataURL(blob);
  });
}

const safeName = (n) => n.replace(/[\\/:*?"<>|]+/g, '_');

/** Opens the system share sheet (Android) or downloads the file (browser). */
export async function exportBlob(name, blob, onProgress) {
  if (isNative()) {
    const dir = 'ahos-export';
    const path = `${dir}/${safeName(name)}`;
    try { await call('Filesystem', 'mkdir', { path: dir, directory: 'CACHE', recursive: true }); } catch { /* exists */ }
    let off = 0, first = true;
    while (off < blob.size || first) {
      const data = await blobToBase64(blob.slice(off, off + CHUNK));
      if (first) await call('Filesystem', 'writeFile', { path, directory: 'CACHE', data, recursive: true });
      else await call('Filesystem', 'appendFile', { path, directory: 'CACHE', data });
      first = false;
      off += CHUNK;
      onProgress?.(Math.min(1, off / (blob.size || 1)));
    }
    const { uri } = await call('Filesystem', 'getUri', { path, directory: 'CACHE' });
    await call('Share', 'share', { title: name, dialogTitle: name, url: uri });
    return;
  }
  const file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  onProgress?.(1);
}

export { extOf };
