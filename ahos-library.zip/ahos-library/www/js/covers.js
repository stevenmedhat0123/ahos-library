// Covers and thumbnails: real previews when we can make them, generated contour art when we can't.
import { h, hashStr, rng, canvasToBlob, loadImage, stripExt, extOf, esc } from './util.js';
import { ic, kindIcon } from './icons.js';
import { onRemove } from './store.js';

/* ---------------- object URL cache for thumbnails ---------------- */
const urls = new Map();
export function thumbURL(item) {
  if (!item.thumb) return null;
  let u = urls.get(item.id);
  if (!u || u.blob !== item.thumb) {
    if (u) URL.revokeObjectURL(u.url);
    u = { blob: item.thumb, url: URL.createObjectURL(item.thumb) };
    urls.set(item.id, u);
  }
  return u.url;
}
onRemove((id) => { const u = urls.get(id); if (u) { URL.revokeObjectURL(u.url); urls.delete(id); } });

/* ---------------- generated art ---------------- */
const PAL = {
  video: { a: '#0f4a5c', b: '#0a1233', accent: '#3CCBBC' },
  image: { a: '#43286e', b: '#0a1233', accent: '#F0C96B' },
  book: { a: '#6a4a10', b: '#0a1233', accent: '#E7B94F' },
  audio: { a: '#24388f', b: '#0a1233', accent: '#9fb6ff' },
  file: { a: '#2d3770', b: '#0a1233', accent: '#98A2D0' },
  folder: { a: '#2d3770', b: '#0a1233', accent: '#98A2D0' },
};

function blobPath(r, cx, cy, rad, n = 10) {
  const pts = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const k = rad * (1 + (r() - 0.5) * 0.55);
    pts.push([cx + Math.cos(a) * k * 1.4, cy + Math.sin(a) * k]);
  }
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += `C${c1[0].toFixed(1)} ${c1[1].toFixed(1)} ${c2[0].toFixed(1)} ${c2[1].toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return d + 'Z';
}

export function genSVG(seedText, kind) {
  const seed = hashStr(seedText);
  const r = rng(seed);
  const pal = PAL[kind] || PAL.file;
  const cx = 50 + r() * 100, cy = 28 + r() * 70;
  let rings = '';
  for (let i = 0; i < 7; i++) {
    const rad = 7 + i * 11 + i * i * 0.9;
    rings += `<path d="${blobPath(r, cx, cy, rad)}" fill="none" stroke="${pal.accent}" stroke-opacity="${Math.max(0.1, 0.62 - i * 0.075).toFixed(2)}" stroke-width="${i % 3 === 0 ? 1.4 : 0.7}"/>`;
  }
  const id = 'g' + seed.toString(36);
  return `<svg viewBox="0 0 200 125" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${pal.a}"/><stop offset="1" stop-color="${pal.b}"/></linearGradient></defs><rect width="200" height="125" fill="url(#${id})"/>${rings}</svg>`;
}

/** A cover element for an item: real thumbnail or generated art. */
export function coverEl(item, { eager = false } = {}) {
  const u = thumbURL(item);
  const wrap = h('div', { class: `cover k-${item.kind}` + (u ? '' : ' gen') });
  if (u) {
    const im = h('img', { src: u, alt: '', decoding: 'async', draggable: 'false' });
    if (!eager) im.loading = 'lazy';
    im.addEventListener('load', () => im.classList.add('ready'));
    if (im.complete) im.classList.add('ready');
    wrap.append(im);
  } else {
    wrap.innerHTML = genSVG(item.id + item.name, item.kind);
    if (item.kind === 'book') {
      wrap.append(h('div', { class: 'gen-title', dir: 'auto' }, item.meta?.title || stripExt(item.name)));
    } else {
      wrap.append(h('div', { class: 'gen-ic', html: ic(kindIcon[item.kind] || 'file') }));
    }
    wrap.append(h('div', { class: 'gen-ext' }, (extOf(item.name) || item.kind).slice(0, 5)));
  }
  return wrap;
}

export function folderArt(f) {
  return genSVG('folder' + f.id + f.name, 'folder');
}

/* ---------------- thumbnails + metadata ---------------- */
const TW = 420;

async function drawToThumb(source, sw, sh) {
  const scale = Math.min(1, TW / Math.max(sw, sh));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(sw * scale)); c.height = Math.max(1, Math.round(sh * scale));
  const x = c.getContext('2d');
  x.fillStyle = '#0b1233'; x.fillRect(0, 0, c.width, c.height);
  x.drawImage(source, 0, 0, c.width, c.height);
  return canvasToBlob(c, 'image/jpeg', 0.74);
}

async function imageThumb(file) {
  let bmp, w, h2;
  try {
    bmp = await createImageBitmap(file);
    w = bmp.width; h2 = bmp.height;
    const thumb = await drawToThumb(bmp, w, h2);
    bmp.close?.();
    return { thumb, meta: { w, h: h2 } };
  } catch {
    const url = URL.createObjectURL(file);
    try {
      const im = await loadImage(url);
      const thumb = await drawToThumb(im, im.naturalWidth || 300, im.naturalHeight || 300);
      return { thumb, meta: { w: im.naturalWidth, h: im.naturalHeight } };
    } finally { URL.revokeObjectURL(url); }
  }
}

function videoThumb(file) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.muted = true; v.playsInline = true; v.preload = 'auto';
    const url = URL.createObjectURL(file);
    let done = false;
    const finish = (r) => {
      if (done) return;
      done = true; clearTimeout(to);
      URL.revokeObjectURL(url); v.removeAttribute('src'); try { v.load(); } catch { /* ignore */ }
      resolve(r);
    };
    const to = setTimeout(() => finish({ thumb: null, meta: {} }), 9000);
    v.onloadedmetadata = () => {
      const d = v.duration;
      try { v.currentTime = isFinite(d) && d > 0 ? Math.min(d * 0.1, 8) : 0.4; } catch { /* seek not ready */ }
    };
    v.onseeked = async () => {
      try {
        const thumb = await drawToThumb(v, v.videoWidth || 320, v.videoHeight || 180);
        finish({ thumb, meta: { duration: v.duration, w: v.videoWidth, h: v.videoHeight } });
      } catch { finish({ thumb: null, meta: { duration: v.duration } }); }
    };
    v.onerror = () => finish({ thumb: null, meta: { unsupported: true } });
    v.src = url;
  });
}

function audioMeta(file) {
  return new Promise((resolve) => {
    const a = document.createElement('audio');
    const url = URL.createObjectURL(file);
    const finish = (m) => { clearTimeout(to); URL.revokeObjectURL(url); a.removeAttribute('src'); resolve(m); };
    const to = setTimeout(() => finish({}), 5000);
    a.preload = 'metadata';
    a.onloadedmetadata = () => finish({ duration: a.duration });
    a.onerror = () => finish({ unsupported: true });
    a.src = url;
  });
}

/** Minimal ID3v2 reader: title, artist and embedded cover art. */
async function id3(file) {
  const head = new Uint8Array(await file.slice(0, 10).arrayBuffer());
  if (head[0] !== 0x49 || head[1] !== 0x44 || head[2] !== 0x33) return {};
  const ver = head[3];
  const size = (head[6] << 21) | (head[7] << 14) | (head[8] << 7) | head[9];
  const buf = new Uint8Array(await file.slice(10, 10 + Math.min(size, 6 * 1024 * 1024)).arrayBuffer());
  const out = {};
  let p = 0;
  const dec = (bytes, enc) => {
    try { return new TextDecoder(enc === 1 ? 'utf-16' : enc === 2 ? 'utf-16be' : enc === 3 ? 'utf-8' : 'windows-1252').decode(bytes).replace(/\0+$/g, '').replace(/^﻿/, ''); } catch { return ''; }
  };
  while (p + 10 < buf.length) {
    const id = String.fromCharCode(buf[p], buf[p + 1], buf[p + 2], buf[p + 3]);
    if (!/^[A-Z0-9]{4}$/.test(id)) break;
    const fs = ver === 4 ? (buf[p + 4] << 21) | (buf[p + 5] << 14) | (buf[p + 6] << 7) | buf[p + 7] : (buf[p + 4] << 24) | (buf[p + 5] << 16) | (buf[p + 6] << 8) | buf[p + 7];
    const start = p + 10, end = start + fs;
    if (fs <= 0 || end > buf.length) break;
    const f = buf.subarray(start, end);
    if (id === 'TIT2') out.title = dec(f.subarray(1), f[0]);
    else if (id === 'TPE1') out.artist = dec(f.subarray(1), f[0]);
    else if (id === 'APIC' && !out.cover) {
      const enc = f[0];
      let i = 1;
      let mime = '';
      while (i < f.length && f[i] !== 0) mime += String.fromCharCode(f[i++]);
      i += 2; // null + picture type
      if (enc === 1 || enc === 2) { while (i + 1 < f.length && !(f[i] === 0 && f[i + 1] === 0)) i += 2; i += 2; }
      else { while (i < f.length && f[i] !== 0) i++; i += 1; }
      const img = f.subarray(i);
      if (img.length > 200) out.cover = new Blob([img], { type: /png/i.test(mime) ? 'image/png' : 'image/jpeg' });
    }
    p = end;
  }
  return out;
}

async function audioThumb(file, ext) {
  const meta = await audioMeta(file);
  let thumb = null;
  if (ext === 'mp3') {
    try {
      const tag = await id3(file);
      if (tag.title) meta.title = tag.title;
      if (tag.artist) meta.author = tag.artist;
      if (tag.cover) {
        const url = URL.createObjectURL(tag.cover);
        try { const im = await loadImage(url); thumb = await drawToThumb(im, im.naturalWidth, im.naturalHeight); } finally { URL.revokeObjectURL(url); }
      }
    } catch { /* tags are optional */ }
  }
  return { thumb, meta };
}

async function pdfThumb(file) {
  const { loadPdfjs, pdfParams } = await import('./pdf-loader.js');
  const pdfjs = await loadPdfjs();
  const task = pdfjs.getDocument(pdfParams(new Uint8Array(await file.arrayBuffer())));
  const doc = await task.promise;
  try {
    const page = await doc.getPage(1);
    const vp = page.getViewport({ scale: 1 });
    const scale = 360 / vp.width;
    const c = document.createElement('canvas');
    const v2 = page.getViewport({ scale });
    c.width = Math.round(v2.width); c.height = Math.round(v2.height);
    const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: x, viewport: v2 }).promise;
    let title = '';
    try { const info = await doc.getMetadata(); title = info?.info?.Title || ''; } catch { /* optional */ }
    return { thumb: await canvasToBlob(c, 'image/jpeg', 0.72), meta: { pages: doc.numPages, title: title.trim() } };
  } finally { try { await task.destroy(); } catch { /* ignore */ } }
}

async function epubThumb(file) {
  const { openEpub } = await import('./epub-core.js');
  const book = await openEpub(file);
  let thumb = null;
  try {
    const cb = await book.coverBlob();
    if (cb) {
      const url = URL.createObjectURL(cb);
      try { const im = await loadImage(url); thumb = await drawToThumb(im, im.naturalWidth, im.naturalHeight); } finally { URL.revokeObjectURL(url); }
    }
  } catch { /* no cover */ }
  const meta = { title: book.title, author: book.author, lang: book.lang, chapters: book.spine.length };
  book.destroy();
  return { thumb, meta };
}

export async function analyze(file, kind, ext) {
  try {
    if (kind === 'image') return await imageThumb(file);
    if (kind === 'video') return await videoThumb(file);
    if (kind === 'audio') return await audioThumb(file, ext);
    if (kind === 'book' && ext === 'pdf') return await pdfThumb(file);
    if (kind === 'book' && ext === 'epub') return await epubThumb(file);
  } catch (e) { console.warn('analyze failed for', file.name, e); }
  return { thumb: null, meta: {} };
}

export { esc };
