// Drawing for the whiteboard: paper + patterns, strokes, shapes, text, placed objects. Used by the viewer, thumbnails and export.
import { outline, FREE, cropOf } from './geom.js';

export const PAPERS = [
  { id: 'white', c: '#ffffff' }, { id: 'cream', c: '#fbf3df' }, { id: 'blue', c: '#e6f0fb' }, { id: 'mint', c: '#e5f5ea' },
  { id: 'gray', c: '#2b2f3a' }, { id: 'black', c: '#000000' }, { id: 'board', c: '#1f3d2c' },
];
export const PATTERNS = ['none', 'lines', 'grid', 'dots', 'graph', 'cornell'];
export const A4 = [595, 842];

export const lum = (hex) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return 1;
  const n = parseInt(m[1], 16);
  return (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
};
export const isDark = (hex) => lum(hex) < 0.45;
export const inkFor = (paper) => (isDark(paper) ? '#ffffff' : '#14161c');

/* ---------------- rainbow ink ----------------
 * A "colour" that is really a recipe: the hue turns along the stroke (by arc length), so the line itself is a rainbow.
 * The full colour wheel at maximum saturation, drawn as a glossy tube. Shapes and text get the same rainbow as a gradient. */
export const RB_L = 'rb:l', RB_D = 'rb:d';
const CYCLE = 260;   // world units for one full turn through all the colours: not rushed, not lazy
// Every "magic ink" is a ring of [hue, lightness shift] keys: the colour flows from one key to the next (always the short way round the wheel)
// as ONE continuously changing colour. The deep rainbow has all the colours of the neon-clouds reference picture:
// coral red, red-orange, orange, gold, olive-yellow, lime, green, emerald, teal, turquoise, cyan, azure, blue, indigo, violet, purple, magenta, hot pink.
const KEYS_D = [
  [2, 3], [14, 3], [30, 2], [48, -2], [66, -5], [85, -4], [125, -6], [152, -6], [168, -5], [182, -3],
  [196, -1], [212, 1], [228, 3], [252, 5], [270, 4], [288, 2], [308, 2], [330, 4],
];
// the light rainbow: the same journey round the wheel, in sweet pastel tones
const KEYS_L = [[350, 0], [12, 0], [32, 0], [50, -1], [78, -2], [110, -2], [145, -2], [170, -2], [190, -1], [208, 0], [228, 1], [255, 2], [278, 2], [300, 1], [325, 0]];
const ink = (name, keys, o = {}) => ({ name, keys, sat: 100, rim: 25, body: 46, sheen: 62, glint: 91, thin: 47, hl: 48, shape: 48, lift: 14, cycle: CYCLE, solid: '#e11d2e', ...o });
const INKS = {
  'rb:d': ink('bd_rbDark', KEYS_D),
  'rb:l': ink('bd_rbLight', KEYS_L, { sat: 90, rim: 56, body: 72, sheen: 83, glint: 97, thin: 70, hl: 74, shape: 70, lift: 3, solid: '#f48fb1' }),
  'gr:sunset': ink('bd_inkSunset', [[14, 0], [32, 2], [48, 3], [20, 1], [350, 0], [326, 0], [300, -2], [326, 0], [350, 0]], { cycle: 220, solid: '#f97316' }),
  'gr:fire': ink('bd_inkFire', [[0, -2], [10, 0], [24, 2], [40, 3], [52, 4], [40, 3], [24, 2], [10, 0]], { cycle: 200, solid: '#ea580c' }),
  'gr:ocean': ink('bd_inkOcean', [[178, -2], [190, 0], [204, 2], [220, 3], [236, 3], [220, 3], [204, 2], [190, 0]], { cycle: 220, solid: '#0284c7' }),
  'gr:aurora': ink('bd_inkAurora', [[150, -4], [168, -3], [188, 0], [216, 3], [262, 4], [296, 3], [262, 4], [216, 3], [188, 0], [168, -3]], { cycle: 240, solid: '#14b8a6' }),
  'gr:galaxy': ink('bd_inkGalaxy', [[236, 0], [256, 2], [276, 3], [300, 3], [322, 2], [300, 3], [276, 3], [256, 2]], { cycle: 210, solid: '#7c3aed' }),
  'gr:forest': ink('bd_inkForest', [[96, -8], [118, -7], [140, -6], [160, -4], [140, -6], [118, -7]], { cycle: 190, solid: '#15803d' }),
  'gr:gold': ink('bd_inkGold', [[36, -3], [44, 1], [52, 5], [58, 8], [52, 5], [44, 1]], { cycle: 150, body: 50, sheen: 68, glint: 95, thin: 50, hl: 54, shape: 52, solid: '#eab308' }),
};
export const INK_IDS = Object.keys(INKS);
export const isRainbow = (c) => typeof c === 'string' && Object.prototype.hasOwnProperty.call(INKS, c);   // "is a magic ink" (kept under the old name)
export const inkName = (c) => (INKS[c] ? INKS[c].name : '');
// Equal length for every colour. The keys above only say WHICH colours come in WHICH order. How far along the stroke each one lasts is decided here:
// the ring is sampled finely, every step is measured as a perceived colour difference (OKLab), and the stroke position is mapped so that the colour
// changes at the same perceived speed everywhere. So no colour is long and none is squeezed into a tiny spot.
const hsl2rgb = (h, s, l) => { s /= 100; l /= 100; const k = (n) => (n + h / 30) % 12, a = s * Math.min(l, 1 - l); const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return [f(0), f(8), f(4)]; };
const lin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
const oklab = ([r, g, b]) => {
  r = lin(r); g = lin(g); b = lin(b);
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b), m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b), q = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  return [0.2104542553 * l + 0.793617785 * m - 0.0040720468 * q, 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * q, 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * q];
};
const rawAt = (f, keys) => {            // f in [0,1): position along the key ring -> [hue, lightness shift]
  const n = keys.length, g = f * n;
  const i = Math.floor(g) % n, j = (i + 1) % n, k = g - Math.floor(g);
  const dh = ((keys[j][0] - keys[i][0] + 540) % 360) - 180;   // always blend the short way round the wheel, up or down
  return [keys[i][0] + dh * k, keys[i][1] + (keys[j][1] - keys[i][1]) * k];
};
const WARP_N = 1440;
function warpOf(K) {
  if (K.warp) return K.warp;
  const cum = new Float64Array(WARP_N + 1);
  let prev = null;
  for (let i = 0; i <= WARP_N; i++) {
    const [h, dl] = rawAt((i % WARP_N) / WARP_N, K.keys);
    const c = oklab(hsl2rgb(((h % 360) + 360) % 360, K.sat, Math.max(8, Math.min(97, K.body + dl))));
    cum[i] = i ? cum[i - 1] + Math.hypot(c[0] - prev[0], c[1] - prev[1], c[2] - prev[2]) : 0;
    prev = c;
  }
  return (K.warp = cum);
}
/** Position t in [0,1) along one cycle -> raw ring position, so that equal steps of t are equal perceived colour changes. */
function unwarp(K, t) {
  const cum = warpOf(K), total = cum[WARP_N], goal = t * total;
  let lo = 0, hi = WARP_N;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (cum[mid] <= goal) lo = mid; else hi = mid; }
  const span = cum[hi] - cum[lo];
  return (lo + (span > 1e-9 ? (goal - cum[lo]) / span : 0)) / WARP_N;
}
const INK_BY_KEYS = new Map(Object.values(INKS).map((k) => [k.keys, k]));
const colorAt = (deg, keys) => {
  const t = (((deg % 360) + 360) % 360) / 360;
  return rawAt(unwarp(INK_BY_KEYS.get(keys), t) % 1, keys);
};
const hsl = (deg, s, l, keys) => { const [h, dl] = colorAt(deg, keys); return `hsl(${(((Math.round(h * 10) / 10) % 360) + 360) % 360} ${s}% ${Math.round(Math.max(8, Math.min(97, l + dl)) * 10) / 10}%)`; };
/** A CSS background for swatches and previews: the colours in the same even order the stroke shows them. */
export const inkCss = (c) => {
  const k = INKS[c];
  if (!k) return c;
  const N = 14, stops = [];
  for (let i = 0; i <= N; i++) stops.push(`${hsl((i / N) * 360, k.sat, k.body, k.keys)} ${Math.round((i / N) * 100)}%`);
  return `linear-gradient(135deg,${stops.join(',')})`;
};
/** The colours of one cycle (for tests): n evenly spaced stops of the body colour, as hsl() strings. */
export const inkRamp = (c, n = 48) => { const k = INKS[c]; return Array.from({ length: n }, (_, i) => hsl((i / n) * 360, k.sat, k.body, k.keys)); };
/** A plain colour to use where a gradient cannot be (text caret, tiny previews). */
export const inkSolid = (c) => (INKS[c] ? INKS[c].solid : c);
export const inkLabel = (c) => (INKS[c] ? INKS[c].name : c);

/** Rainbow gradient across a box, for shapes and text (two full turns of the wheel). */
function rainbowGradient(ctx, c, b, dark) {
  const k = INKS[c] || INKS['rb:d'];
  const [x0, y0, x1, y1] = b;
  const g = ctx.createLinearGradient(x0, y0, x1 === x0 ? x0 + 1 : x1, y1 === y0 ? y0 + 1 : y1);
  const n = 36;
  for (let i = 0; i <= n; i++) g.addColorStop(i / n, hsl((i / n) * 720, k.sat, k.shape + (dark ? Math.min(8, k.lift) : 0), k.keys));
  return g;
}

/** Densifies the stroke so long straight pieces still change colour smoothly. Returns { x, y, w, d } arrays. */
function rbSamples(s, ch) {
  const p = s.pts, n = p.length / 2, pr = s.pr && s.t !== 'hl' ? s.pr : null;
  const gap = ch;                   // longest straight piece between samples
  const total = n > 1 ? n : 1;
  const x = [p[0]], y = [p[1]], w = [pr ? pr[0] : 0.5], d = [s.u || 0];
  let dist = s.u || 0;
  const maxPts = 9000;
  const lim = total > 2500 ? gap * 2 : gap;
  for (let i = 1; i < n; i++) {
    const ax = p[i * 2 - 2], ay = p[i * 2 - 1], bx = p[i * 2], by = p[i * 2 + 1];
    const L = Math.hypot(bx - ax, by - ay);
    const k = Math.min(60, Math.max(1, Math.ceil(L / lim)));
    for (let j = 1; j <= k && x.length < maxPts; j++) {
      const t = j / k;
      x.push(ax + (bx - ax) * t); y.push(ay + (by - ay) * t);
      w.push(pr ? pr[i - 1] + (pr[i] - pr[i - 1]) * t : 0.5);
      d.push(dist + L * t);
    }
    dist += L;
  }
  return { x, y, w, d, pr: !!pr };
}

function drawRainbowFree(ctx, s, env) {
  const hl = s.t === 'hl';
  const K = INKS[s.c] || INKS['rb:d'], CYC = K.cycle, KS = K.keys;
  const dk = env.dark ? K.lift : 0;   // on a dark page the colours are lifted a little so they still glow
  const p = s.pts, np = p.length / 2;
  if (hl) {
    // a marker is one see-through layer, so it is a single stroke with the rainbow as a gradient along its chord
    ctx.globalAlpha = env.dark ? 0.5 : 0.42; if (!env.live && !env.dark) ctx.globalCompositeOperation = 'multiply';
    ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = s.w;
    const x0 = p[0], y0 = p[1], x1 = p[np * 2 - 2], y1 = p[np * 2 - 1];
    const chord = Math.hypot(x1 - x0, y1 - y0);
    if (np < 2 || chord < 2) {
      ctx.fillStyle = hsl(((s.u || 0) / CYC) * 360, K.sat - 5, K.hl + dk, KS);
      ctx.beginPath(); ctx.arc(x0, y0, Math.max(s.w / 2, 0.4), 0, 6.2832); ctx.fill();
      return;
    }
    const g = ctx.createLinearGradient(x0, y0, x1, y1);
    const stops = Math.min(60, Math.max(3, Math.ceil(chord / (CYC / 18))));
    for (let i = 0; i <= stops; i++) g.addColorStop(i / stops, hsl(((((s.u || 0) + (i / stops) * chord) / CYC) * 360) % 360, K.sat - 5, K.hl + dk, KS));
    ctx.strokeStyle = g;
    ctx.beginPath(); smoothPath(ctx, p); ctx.stroke();
    return;
  }
  const CH = Math.min(8, Math.max(2.5, 60 / Math.max(1, s.w)));   // thick tubes are cut finer so the colour lines stay square to the stroke
  const smp = rbSamples(s, CH), n = smp.x.length;
  const baseW = s.w;
  const widthAt = (i0, i1) => {
    if (!smp.pr) return baseW;
    let a = 0; for (let i = i0; i <= i1; i++) a += smp.w[i];
    return baseW * (0.4 + 1.2 * a / (i1 - i0 + 1));
  };
  // dot
  let same = true;
  for (let i = 1; i < n; i++) if (Math.abs(smp.x[i] - smp.x[0]) > 0.05 || Math.abs(smp.y[i] - smp.y[0]) > 0.05) { same = false; break; }
  if (n === 1 || same) {
    const h0 = ((smp.d[0] / CYC) * 360) % 360;
    ctx.fillStyle = hsl(h0, K.sat, K.body + dk, KS);
    ctx.beginPath(); ctx.arc(smp.x[0], smp.y[0], Math.max(baseW / 2, 0.4), 0, 6.2832); ctx.fill();
    return;
  }
  // The stroke is cut into short pieces. Each piece is one gradient from its start colour to its end colour, and the next piece starts with
  // exactly that colour, so the colour flows without a single visible step. Pieces overlap by one sample (no seams) and are butt-capped;
  // the very ends are round, and so are joints on sharp turns.
  const chunks = [];
  let ca = 0;
  for (let i = 1; i < n; i++) {
    if (smp.d[i] - smp.d[ca] >= CH || i === n - 1) { chunks.push([ca, i]); ca = i; }
  }
  const bend = chunks.map(([a], k) => {
    if (!k || a < 1 || a + 1 >= n) return 0;
    const ux = smp.x[a] - smp.x[a - 1], uy = smp.y[a] - smp.y[a - 1], vx = smp.x[a + 1] - smp.x[a], vy = smp.y[a + 1] - smp.y[a];
    const m = Math.hypot(ux, uy) * Math.hypot(vx, vy);
    return m > 1e-6 ? Math.acos(Math.max(-1, Math.min(1, (ux * vx + uy * vy) / m))) : 0;
  });
  const degOf = (d) => (d / CYC) * 360;
  const pass = (width, color, dx = 0, dy = 0) => {
    ctx.lineCap = 'butt';
    for (let k = 0; k < chunks.length; k++) {
      const [a, b] = chunks[k];
      const lw = Math.max(0.3, width(a, b));
      const from = k ? a - 1 : a;
      const x0 = smp.x[a] + dx, y0 = smp.y[a] + dy, x1 = smp.x[b] + dx, y1 = smp.y[b] + dy;
      const c0 = color(degOf(smp.d[a])), c1 = color(degOf(smp.d[b]));
      if (Math.hypot(x1 - x0, y1 - y0) > 0.05) {
        const g = ctx.createLinearGradient(x0, y0, x1, y1);
        g.addColorStop(0, c0); g.addColorStop(0.5, color(degOf((smp.d[a] + smp.d[b]) / 2))); g.addColorStop(1, c1);
        ctx.strokeStyle = g;
      } else ctx.strokeStyle = c0;
      ctx.lineWidth = lw;
      ctx.beginPath(); ctx.moveTo(smp.x[from] + dx, smp.y[from] + dy);
      for (let i = from + 1; i <= b; i++) ctx.lineTo(smp.x[i] + dx, smp.y[i] + dy);
      ctx.stroke();
      if (k === 0 || bend[k] > 0.35) { ctx.fillStyle = c0; ctx.beginPath(); ctx.arc(x0, y0, lw / 2, 0, 6.2832); ctx.fill(); }
      if (k === chunks.length - 1) { ctx.fillStyle = c1; ctx.beginPath(); ctx.arc(x1, y1, lw / 2, 0, 6.2832); ctx.fill(); }
    }
  };
  const W = (f) => (a, b) => widthAt(a, b) * f;
  if (baseW < 2.4) {
    pass(W(1), (g) => hsl(g, K.sat, K.thin + dk, KS));
  } else {
    pass(W(1), (g) => hsl(g, K.sat, K.rim + dk * 0.5, KS));                                 // deep rim
    pass(W(0.8), (g) => hsl(g, K.sat, K.body + dk, KS));                                    // saturated body
    pass(W(0.46), (g) => hsl(g, K.sat, K.sheen + dk * 0.6, KS), -baseW * 0.07, -baseW * 0.1); // sheen
    pass(W(0.15), (g) => hsl(g, K.sat, K.glint, KS), -baseW * 0.13, -baseW * 0.18);           // specular glint
  }
}

const FONT = '"Segoe UI", Roboto, "Noto Sans Arabic", "Noto Naskh Arabic", system-ui, sans-serif';
export const fontOf = (s) => `${s.bold ? '700 ' : ''}${s.size}px ${FONT}`;
const RTL = /[֐-ࣿיִ-﷿ﹰ-ﻼ]/;
const strongRtl = (str) => { for (const ch of str) { if (RTL.test(ch)) return true; if (/[A-Za-zÀ-ɏЀ-ӿ]/.test(ch)) return false; } return false; };

/* ---------------- text ---------------- */
const layouts = new WeakMap();
export const textPad = (s) => (s.bg ? 10 : 3);

/** Wraps the text to the box width. Returns { lines:[{t, rtl}], lh, h }. Cached per stroke. */
export function layoutText(ctx, s) {
  let l = layouts.get(s);
  if (l) return l;
  ctx.save();
  ctx.font = fontOf(s);
  const maxW = Math.max(10, s.bw - textPad(s) * 2);
  const lines = [];
  for (const para of String(s.s).split('\n')) {
    if (!para) { lines.push({ t: '', rtl: false }); continue; }
    const rtl = strongRtl(para);
    const words = para.split(/(\s+)/);
    let cur = '';
    for (const w of words) {
      const test = cur + w;
      if (cur && ctx.measureText(test).width > maxW) {
        lines.push({ t: cur.trimEnd(), rtl });
        cur = w.trimStart();
      } else cur = test;
      // a single word longer than the box: break it by characters
      while (ctx.measureText(cur).width > maxW && cur.length > 1) {
        let i = cur.length - 1;
        while (i > 1 && ctx.measureText(cur.slice(0, i)).width > maxW) i--;
        lines.push({ t: cur.slice(0, i), rtl });
        cur = cur.slice(i);
      }
    }
    lines.push({ t: cur.trimEnd(), rtl });
  }
  ctx.restore();
  const lh = s.size * 1.32;
  l = { lines, lh, h: lines.length * lh + textPad(s) * 2 };
  layouts.set(s, l);
  return l;
}

/** Natural width for new text: the longest line (up to maxW), so a short word doesn't get a huge box. */
export function naturalWidth(ctx, text, size, bold, bg, maxW) {
  ctx.save();
  ctx.font = fontOf({ size, bold });
  let w = 0;
  for (const line of String(text).split('\n')) w = Math.max(w, ctx.measureText(line).width);
  ctx.restore();
  return Math.min(maxW, Math.max(60, Math.ceil(w + textPad({ bg }) * 2 + 4)));
}

/** Returns the text stroke with its height recomputed for its width and content. */
export function refitText(ctx, s) {
  const probe = { ...s, bh: 0 };
  const l = layoutText(ctx, probe);
  const out = { ...s, bh: Math.ceil(l.h) };
  return out;
}

/* ---------------- paper ---------------- */
function patternColor(dark, a = 1) { return dark ? `rgba(255,255,255,${0.15 * a})` : `rgba(45,70,120,${0.17 * a})`; }

/**
 * Paints the paper (and its ruling) for the visible part of the page.
 * vp = { x, y, s, W, H } maps world -> css pixels; the context is already scaled to world units.
 */
export function drawPaper(ctx, page, paper, pattern, vp) {
  const dark = isDark(paper);
  const fixed = !!page.w;
  const x0 = fixed ? 0 : -vp.x / vp.s, y0 = fixed ? 0 : -vp.y / vp.s;
  const w = fixed ? page.w : vp.W / vp.s, h = fixed ? page.h : vp.H / vp.s;
  ctx.fillStyle = paper;
  ctx.fillRect(x0, y0, w, h);
  if (pattern === 'none' || !pattern) { outlinePage(ctx, page, dark, vp); return; }
  // visible part only
  const vx1 = Math.max(x0, -vp.x / vp.s), vy1 = Math.max(y0, -vp.y / vp.s);
  const vx2 = Math.min(x0 + w, (vp.W - vp.x) / vp.s), vy2 = Math.min(y0 + h, (vp.H - vp.y) / vp.s);
  if (vx2 <= vx1 || vy2 <= vy1) return;
  const px = 1 / vp.s;
  ctx.save();
  ctx.beginPath(); ctx.rect(x0, y0, w, h); ctx.clip();
  let sp = pattern === 'dots' ? 24 : pattern === 'grid' ? 24 : pattern === 'graph' ? 12 : 32;
  while (sp * vp.s < (pattern === 'graph' ? 5 : 8)) sp *= 2;
  const fromX = Math.floor(vx1 / sp) * sp, fromY = Math.floor(vy1 / sp) * sp;
  if (pattern === 'dots') {
    ctx.fillStyle = patternColor(dark, 1.7);
    const r = Math.max(1.1, 1.3 * px);
    ctx.beginPath();
    for (let y = fromY; y <= vy2; y += sp) for (let x = fromX; x <= vx2; x += sp) { ctx.moveTo(x + r, y); ctx.arc(x, y, r, 0, 6.2832); }
    ctx.fill();
  } else {
    ctx.lineWidth = Math.max(px, 0.8);
    ctx.strokeStyle = patternColor(dark);
    ctx.beginPath();
    if (pattern !== 'lines' && pattern !== 'cornell') for (let x = fromX; x <= vx2; x += sp) { ctx.moveTo(x, vy1); ctx.lineTo(x, vy2); }
    for (let y = fromY; y <= vy2; y += sp) { ctx.moveTo(vx1, y); ctx.lineTo(vx2, y); }
    ctx.stroke();
    if (pattern === 'graph') {
      const big = sp * 5;
      ctx.strokeStyle = patternColor(dark, 1.9); ctx.beginPath();
      for (let x = Math.floor(vx1 / big) * big; x <= vx2; x += big) { ctx.moveTo(x, vy1); ctx.lineTo(x, vy2); }
      for (let y = Math.floor(vy1 / big) * big; y <= vy2; y += big) { ctx.moveTo(vx1, y); ctx.lineTo(vx2, y); }
      ctx.stroke();
    }
    if ((pattern === 'lines' || pattern === 'cornell') && fixed) {
      ctx.strokeStyle = dark ? 'rgba(255,120,120,.4)' : 'rgba(220,60,60,.35)';
      ctx.beginPath();
      if (pattern === 'lines') { ctx.moveTo(56, 0); ctx.lineTo(56, h); }
      else { ctx.moveTo(150, 0); ctx.lineTo(150, h - 130); ctx.moveTo(0, h - 130); ctx.lineTo(w, h - 130); }
      ctx.stroke();
    }
  }
  ctx.restore();
  outlinePage(ctx, page, dark, vp);
}

function outlinePage(ctx, page, dark, vp) {
  if (!page.w) return;
  ctx.lineWidth = 1 / vp.s;
  ctx.strokeStyle = dark ? 'rgba(255,255,255,.28)' : 'rgba(0,0,0,.22)';
  ctx.strokeRect(0, 0, page.w, page.h);
}

/* ---------------- strokes ---------------- */
function smoothPath(ctx, p) {
  const n = p.length / 2;
  ctx.moveTo(p[0], p[1]);
  if (n === 2) { ctx.lineTo(p[2], p[3]); return; }
  for (let i = 1; i < n - 1; i++) ctx.quadraticCurveTo(p[i * 2], p[i * 2 + 1], (p[i * 2] + p[i * 2 + 2]) / 2, (p[i * 2 + 1] + p[i * 2 + 3]) / 2);
  ctx.lineTo(p[(n - 1) * 2], p[(n - 1) * 2 + 1]);
}

function drawFree(ctx, s, env) {
  if (isRainbow(s.c)) { drawRainbowFree(ctx, s, env); return; }
  const p = s.pts, n = p.length / 2;
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const hl = s.t === 'hl';
  if (hl) { ctx.globalAlpha = env.dark ? 0.5 : 0.42; if (!env.live && !env.dark) ctx.globalCompositeOperation = 'multiply'; }
  ctx.strokeStyle = ctx.fillStyle = s.c;
  let same = true;
  for (let i = 2; i < p.length; i += 2) if (Math.abs(p[i] - p[0]) > 0.05 || Math.abs(p[i + 1] - p[1]) > 0.05) { same = false; break; }
  if (n === 1 || same) {
    ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(s.w / 2, 0.4), 0, 6.2832); ctx.fill();
  } else if (s.pr && !hl) {
    // width follows pressure / speed: runs of segments with (nearly) the same width are drawn as one path
    let q = -1, open = false;
    for (let i = 0; i < n - 1; i++) {
      const lw = Math.round(s.w * (0.4 + 1.2 * ((s.pr[i] + s.pr[i + 1]) / 2)) * 8) / 8;
      if (lw !== q) {
        if (open) ctx.stroke();
        q = lw; ctx.lineWidth = Math.max(0.2, lw); ctx.beginPath(); ctx.moveTo(p[i * 2], p[i * 2 + 1]); open = true;
      }
      ctx.lineTo(p[i * 2 + 2], p[i * 2 + 3]);
    }
    if (open) ctx.stroke();
  } else {
    ctx.lineWidth = s.w;
    ctx.beginPath(); smoothPath(ctx, p); ctx.stroke();
  }
}

function shapeBox(s) {
  if (s.a && s.b) return [Math.min(s.a[0], s.b[0]), Math.min(s.a[1], s.b[1]), Math.max(s.a[0], s.b[0]), Math.max(s.a[1], s.b[1])];
  const o = outline(s).pts;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (let i = 0; i < o.length; i += 2) { x0 = Math.min(x0, o[i]); x1 = Math.max(x1, o[i]); y0 = Math.min(y0, o[i + 1]); y1 = Math.max(y1, o[i + 1]); }
  return [x0, y0, x1, y1];
}

function polyPath(ctx, pts, closed) {
  ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  if (closed) ctx.closePath();
}

function drawShape(ctx, s, env) {
  ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = s.w;
  ctx.strokeStyle = ctx.fillStyle = isRainbow(s.c) ? rainbowGradient(ctx, s.c, shapeBox(s), env?.dark) : s.c;
  ctx.beginPath();
  if (s.t === 'ellipse') {
    const cx = (s.a[0] + s.b[0]) / 2, cy = (s.a[1] + s.b[1]) / 2;
    ctx.ellipse(cx, cy, Math.max(0.1, Math.abs(s.b[0] - s.a[0]) / 2), Math.max(0.1, Math.abs(s.b[1] - s.a[1]) / 2), 0, 0, 6.2832);
  } else {
    const o = outline(s);
    polyPath(ctx, o.pts, o.closed);
  }
  if (s.f && s.t !== 'line' && s.t !== 'arrow') { ctx.save(); ctx.globalAlpha = 0.22; ctx.fill(); ctx.restore(); }
  ctx.stroke();
  if (s.t === 'arrow') {
    const [x1, y1] = s.a, [x2, y2] = s.b;
    const ang = Math.atan2(y2 - y1, x2 - x1), hd = Math.max(10, s.w * 4.2);
    ctx.beginPath();
    ctx.moveTo(x2 - hd * Math.cos(ang - 0.5), y2 - hd * Math.sin(ang - 0.5)); ctx.lineTo(x2, y2); ctx.lineTo(x2 - hd * Math.cos(ang + 0.5), y2 - hd * Math.sin(ang + 0.5));
    ctx.stroke();
  }
}

function drawText(ctx, s, env) {
  const l = layoutText(ctx, s);
  const pad = textPad(s);
  if (s.bg) {
    ctx.fillStyle = s.bg;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(s.x, s.y, s.bw, s.bh, 5); else ctx.rect(s.x, s.y, s.bw, s.bh);
    ctx.fill();
  }
  ctx.font = fontOf(s);
  ctx.fillStyle = isRainbow(s.c) ? rainbowGradient(ctx, s.c, [s.x, s.y, s.x + s.bw, s.y + s.bh], env?.dark) : s.c;
  ctx.textBaseline = 'top';
  let y = s.y + pad + (s.size * 1.32 - s.size) / 2;
  for (const ln of l.lines) {
    ctx.direction = ln.rtl ? 'rtl' : 'ltr';
    ctx.textAlign = ln.rtl ? 'right' : 'left';
    ctx.fillText(ln.t, ln.rtl ? s.x + s.bw - pad : s.x + pad, y);
    y += l.lh;
  }
  ctx.direction = 'ltr'; ctx.textAlign = 'left';
}

const roundRect = (ctx, x, y, w, h, r) => { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); };

function placeholder(ctx, s, text, dark) {
  ctx.fillStyle = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
  ctx.fillRect(s.x, s.y, s.w, s.h);
  ctx.strokeStyle = dark ? 'rgba(255,255,255,.25)' : 'rgba(0,0,0,.25)';
  ctx.lineWidth = 1; ctx.setLineDash([6, 5]); ctx.strokeRect(s.x, s.y, s.w, s.h); ctx.setLineDash([]);
  if (text) {
    ctx.fillStyle = dark ? 'rgba(255,255,255,.6)' : 'rgba(0,0,0,.55)';
    ctx.font = `${Math.max(10, Math.min(18, s.w / 12))}px ${FONT}`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, s.x + s.w / 2, s.y + s.h / 2, s.w - 12);
    ctx.textAlign = 'left';
  }
}

function drawMedia(ctx, s, env) {
  const thumb = env.assets?.thumb(s.ref);
  const video = s.kind === 'video';
  roundRect(ctx, s.x, s.y, s.w, s.h, Math.min(14, s.h / 6));
  ctx.save();
  ctx.clip();
  // a cropped video card shows part of the whole card: draw the whole card (F) and let the clip keep the part
  const cr = cropOf(s), fw = s.w / (cr[2] - cr[0]), fh = s.h / (cr[3] - cr[1]), fx = s.x - cr[0] * fw, fy = s.y - cr[1] * fh;
  if (thumb) {
    const k = Math.max(fw / thumb.w, fh / thumb.h);
    ctx.drawImage(thumb.src, fx + (fw - thumb.w * k) / 2, fy + (fh - thumb.h * k) / 2, thumb.w * k, thumb.h * k);
  } else {
    const g = ctx.createLinearGradient(fx, fy, fx + fw, fy + fh);
    if (video) { g.addColorStop(0, '#12485a'); g.addColorStop(1, '#0a1233'); } else { g.addColorStop(0, '#3a2c8a'); g.addColorStop(1, '#0f1640'); }
    ctx.fillStyle = g; ctx.fillRect(fx, fy, fw, fh);
  }
  const shade = ctx.createLinearGradient(0, s.y + s.h * 0.45, 0, s.y + s.h);
  shade.addColorStop(0, 'rgba(0,0,0,0)'); shade.addColorStop(1, 'rgba(0,0,0,.72)');
  ctx.fillStyle = shade; ctx.fillRect(s.x, s.y, s.w, s.h);
  ctx.restore();
  // play button
  const cx = s.x + s.w / 2, cy = s.y + s.h / 2 - Math.min(8, s.h * 0.05), r = Math.max(14, Math.min(s.w, s.h) * 0.17);
  ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.2832); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = Math.max(1.5, r * 0.08); ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.beginPath();
  ctx.moveTo(cx - r * 0.28, cy - r * 0.42); ctx.lineTo(cx + r * 0.5, cy); ctx.lineTo(cx - r * 0.28, cy + r * 0.42); ctx.closePath(); ctx.fill();
  // title
  ctx.fillStyle = '#fff';
  ctx.font = `600 ${Math.max(11, Math.min(17, s.h / 7))}px ${FONT}`;
  ctx.textBaseline = 'alphabetic';
  const title = s.title || '';
  const rtl = strongRtl(title);
  ctx.direction = rtl ? 'rtl' : 'ltr'; ctx.textAlign = rtl ? 'right' : 'left';
  ctx.fillText(title, rtl ? s.x + s.w - 10 : s.x + 10, s.y + s.h - 10, s.w - 20);
  ctx.direction = 'ltr'; ctx.textAlign = 'left';
  ctx.strokeStyle = 'rgba(255,255,255,.2)'; ctx.lineWidth = 1;
  roundRect(ctx, s.x, s.y, s.w, s.h, Math.min(14, s.h / 6)); ctx.stroke();
}

/**
 * env = { dark, assets, live, hideMedia }
 * dark: is the paper dark (changes highlighter blending); live: drawing on a transparent overlay; hideMedia: media card being played.
 */
export function drawStroke(ctx, s, env) {
  ctx.save();
  try {
    switch (s.t) {
      case 'pen': case 'hl': drawFree(ctx, s, env); break;
      case 'text': drawText(ctx, s, env); break;
      case 'img': {
        const b = env.assets?.image(s.ref);
        if (b) { const c = cropOf(s); ctx.drawImage(b.src, c[0] * b.w, c[1] * b.h, (c[2] - c[0]) * b.w, (c[3] - c[1]) * b.h, s.x, s.y, s.w, s.h); } else placeholder(ctx, s, env.assets?.missing(s.ref) ? '⚠' : '…', env.dark);
        break;
      }
      case 'pdfp': {
        const b = env.assets?.pdfPage(s.ref, s.page, Math.ceil(s.w * (env.scale || 1) * (env.dpr || 1)), false, s.crop ? cropOf(s) : null);
        if (b) { ctx.fillStyle = '#fff'; ctx.fillRect(s.x, s.y, s.w, s.h); ctx.drawImage(b.src, s.x, s.y, s.w, s.h); ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1 / (env.scale || 1); ctx.strokeRect(s.x, s.y, s.w, s.h); } else placeholder(ctx, s, env.assets?.missing(s.ref) ? '⚠ PDF' : 'PDF …', env.dark);
        break;
      }
      case 'media': if (env.hideMedia !== s) drawMedia(ctx, s, env); break;
      default: drawShape(ctx, s, env);
    }
  } finally { ctx.restore(); }
}

export const isFreeStroke = FREE;
