// Draws a book that lies on the board: flat ('2d') or like a real hardcover seen from above ('3d').
// Only the book is drawn here. Writing on its pages is ordinary board ink (drawn afterwards, so it is always on top).
import { bookModel, clampSp } from './bookmath.js';

export const COVER_COLORS = ['#2b3d6b', '#6b2b3a', '#1f5a46', '#4a3a2a', '#3b2b5e', '#2a2a2e', '#a3541f', '#1b6f8a'];
const PAPER = '#fbfaf6';

export const trimCrop = (tr) => (tr && (tr[0] > 0 || tr[1] > 0 || tr[2] > 0 || tr[3] > 0) ? [tr[0], tr[1], 1 - tr[2], 1 - tr[3]] : null);

function rr(ctx, x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
const shade = (hex, amt) => {
  const n = parseInt((hex || '#2b3d6b').slice(1), 16), f = (v) => Math.max(0, Math.min(255, v + amt));
  return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`;
};

/** The page a book shows at `sp`, or `over` = [l, r] while a leaf is turning. */
export function pagesShown(b, over) {
  const m = bookModel(b.n);
  return over || m.pagesOf(clampSp(b));
}

/** page `n` of the book as a bitmap source: a PDF page, the back cover, a blank pad page or nothing yet */
function pageSource(b, n, env, pwPx) {
  const m = bookModel(b.n);
  if (n > b.n) return n === m.BK ? 'back' : 'blank';
  const bm = env.assets?.pdfPage(b.ref, n, Math.ceil(pwPx), false, trimCrop(b.trim));
  return bm || 'wait';
}

export function drawPage(ctx, src, x, y, w, h, rtl, cc, flat) {
  ctx.save();
  if (src === 'back') {
    const g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, shade(cc, 14)); g.addColorStop(1, shade(cc, -26));
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = Math.max(0.6, w * 0.006); ctx.strokeRect(x + w * 0.08, y + w * 0.08, w * 0.84, h - w * 0.16);
  } else {
    ctx.fillStyle = PAPER; ctx.fillRect(x, y, w, h);
    if (src && src !== 'blank' && src !== 'wait') {
      if (rtl) { ctx.translate(x + w, 0); ctx.scale(-1, 1); ctx.drawImage(src.src, 0, y, w, h); } else ctx.drawImage(src.src, x, y, w, h);
    } else if (src === 'wait') {
      ctx.fillStyle = 'rgba(0,0,0,.06)'; ctx.fillRect(x + w * 0.12, y + h * 0.12, w * 0.76, h * 0.02); ctx.fillRect(x + w * 0.12, y + h * 0.18, w * 0.6, h * 0.02);
    }
  }
  ctx.restore();
  if (flat) { ctx.strokeStyle = 'rgba(0,0,0,.28)'; ctx.lineWidth = Math.max(0.5, w * 0.003); ctx.strokeRect(x, y, w, h); }
}

export function drawBook(ctx, b, env) {
  const m = bookModel(b.n), [l, r] = pagesShown(b, env.bookOver?.get(b.id));
  const pw = b.w / 2, ph = b.h, sx = b.x + pw, x0 = b.x, y0 = b.y, rtl = !!b.rtl;
  const sc = (env.scale || 1) * (env.dpr || 1), pwPx = pw * sc;
  const cc = b.cc || COVER_COLORS[0], flat = b.st === '2d';
  ctx.save();
  if (rtl) { ctx.translate(2 * b.x + b.w, 0); ctx.scale(-1, 1); }

  if (flat) {
    if (l) drawPage(ctx, pageSource(b, l, env, pwPx), x0, y0, pw, ph, rtl, cc, true);
    if (r) drawPage(ctx, pageSource(b, r, env, pwPx), sx, y0, pw, ph, rtl, cc, true);
    if (l && r) { const g = ctx.createLinearGradient(sx - pw * 0.05, 0, sx + pw * 0.05, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(0,0,0,.16)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(sx - pw * 0.05, y0, pw * 0.1, ph); }
    ctx.restore();
    return;
  }

  /* ---------- 3D: a hardcover book seen from above ---------- */
  const mg = pw * 0.08, mgb = pw * 0.11, rad = pw * 0.04, spine = pw * 0.05;   // the cover is clearly bigger than the paper: the paper sits inside its area
  const nl = l ? Math.min(l, b.n) : 0, nr = r ? b.n - Math.min(r, b.n) + 1 : 0;
  const thkMax = pw * (0.03 + 0.10 * Math.sqrt(Math.min(1, b.n / 200)));   // a thick book shows a thick block of pages
  const tl = thkMax * (nl / b.n), tr = thkMax * (nr / b.n);
  const both = l && r, closedFront = !l, closedBack = !r;
  const bx0 = both ? x0 - mg : closedFront ? sx - spine : x0 - mg;            // the board
  const bx1 = both ? sx + pw + mg : closedFront ? sx + pw + mg : sx + spine;
  const by0 = y0 - mg, bh = ph + mg + mgb;
  const dark = shade(cc, -46), body = (g0, g1) => { const g = ctx.createLinearGradient(0, by0, 0, by0 + bh); g.addColorStop(0, g0); g.addColorStop(1, g1); return g; };

  // The block of pages on each side is as thick as the pages that are on that side: a book opened in the middle shows two equal blocks,
  // opened near the start the right block is thick and the left one thin (and the other way round near the end).
  const strips = (x, w, t, dir) => {
    if (t < 0.4) return;
    const n = Math.max(1, Math.min(18, Math.ceil(t / (pw * 0.0042))));
    ctx.lineWidth = Math.max(0.4, pw * 0.0016);
    for (let i = n; i >= 1; i--) {
      const f = i / n, ox = dir * t * 0.62 * f, oy = t * 0.8 * f;
      ctx.fillStyle = shade('#f2ecdc', -Math.round(26 * f)); rr(ctx, dir > 0 ? x : x + ox, y0, w + Math.abs(ox), ph + oy, rad * 0.5); ctx.fill();   // reaches the spine and the top, so only the side and the lower edge show
      ctx.strokeStyle = 'rgba(95,75,45,.3)'; ctx.stroke();
    }
  };
  const cth = pw * 0.012;                                                     // thickness of the board
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,.42)'; ctx.shadowBlur = pw * 0.11 * sc; ctx.shadowOffsetY = pw * 0.035 * sc; ctx.shadowOffsetX = pw * 0.012 * sc;
  ctx.fillStyle = dark; rr(ctx, bx0, by0 + cth + Math.max(tl, tr) * 0.85, bx1 - bx0, bh, rad); ctx.fill();   // casts the shadow of the whole book
  ctx.restore();
  if (!both) { if (r) strips(sx, pw, tr, 1); if (l) strips(x0, pw, tl, -1); }  // closed: the cover lies over the pages, their edges peek out
  ctx.fillStyle = dark; rr(ctx, bx0, by0 + cth, bx1 - bx0, bh, rad); ctx.fill();                              // the lower edge of the board

  // 2. the board of the cover
  ctx.fillStyle = body(shade(cc, 20), shade(cc, -20)); rr(ctx, bx0, by0, bx1 - bx0, bh, rad); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = Math.max(0.5, pw * 0.004); rr(ctx, bx0 + pw * 0.004, by0 + pw * 0.004, bx1 - bx0 - pw * 0.008, bh - pw * 0.008, rad); ctx.stroke();
  if (both) { strips(sx, pw, tr, 1); strips(x0, pw, tl, -1); }                // open: the blocks of pages rest on the board

  // 3. the pages
  if (l) drawPage(ctx, pageSource(b, l, env, pwPx), x0, y0, pw, ph, rtl, cc, false);
  if (r) {
    if (closedFront) {                                                         // the front cover: the first page is printed on it
      const gap = pw * 0.05;
      drawPage(ctx, pageSource(b, r, env, pwPx), sx + gap, y0, pw - gap, ph, rtl, cc, false);
      const g = ctx.createLinearGradient(sx, 0, sx + gap * 1.6, 0); g.addColorStop(0, 'rgba(0,0,0,.45)'); g.addColorStop(0.55, 'rgba(255,255,255,.1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fillRect(sx - spine, by0, spine + gap * 1.6, bh);
    } else drawPage(ctx, pageSource(b, r, env, pwPx), sx, y0, pw, ph, rtl, cc, false);
  }
  if (closedBack && l) {                                                       // the back cover
    const g = ctx.createLinearGradient(sx - pw * 0.04, 0, sx, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.35)');
    ctx.fillStyle = g; ctx.fillRect(sx - pw * 0.04, by0, pw * 0.04 + spine, bh);
  }

  // 4. the gutter: pages curve down into the spine
  if (both) {
    const gw = pw * 0.13;
    let g = ctx.createLinearGradient(sx, 0, sx + gw, 0); g.addColorStop(0, 'rgba(0,0,0,.34)'); g.addColorStop(0.35, 'rgba(0,0,0,.1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(sx, y0, gw, ph);
    g = ctx.createLinearGradient(sx, 0, sx - gw, 0); g.addColorStop(0, 'rgba(0,0,0,.34)'); g.addColorStop(0.35, 'rgba(0,0,0,.1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(sx - gw, y0, gw, ph);
    ctx.fillStyle = 'rgba(0,0,0,.32)'; ctx.fillRect(sx - pw * 0.004, y0, pw * 0.008, ph);
  }
  // 5. the gloss of the cover when it is closed
  if (!both) {
    const gx0 = closedFront ? sx : x0, gw2 = pw + mg;
    const g = ctx.createLinearGradient(gx0, by0, gx0 + gw2, by0 + bh); g.addColorStop(0, 'rgba(255,255,255,.18)'); g.addColorStop(0.45, 'rgba(255,255,255,.02)'); g.addColorStop(1, 'rgba(0,0,0,.14)');
    ctx.fillStyle = g; rr(ctx, bx0, by0, bx1 - bx0, bh, rad); ctx.fill();
  }
  void m;
  ctx.restore();
}
