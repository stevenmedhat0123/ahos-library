// In-app update check. The app is fully offline; this only runs when you ask or when a connection happens to exist.
// Releases are published by the GitHub workflow (see README). update.json is rewritten at build time.
import { state } from './store.js';
import { toast } from './ui.js';
import { t } from './i18n.js';
import { openExternal } from './native.js';

let info = { version: '0.1.0', build: 0, channel: 'beta', repo: '', server: '' };

export async function loadAppInfo() {
  try {
    const r = await fetch(new URL('../update.json', import.meta.url), { cache: 'no-store' });
    if (r.ok) info = { ...info, ...(await r.json()) };
  } catch { /* offline first run, use defaults */ }
  return info;
}
export const getAppInfo = () => info;

function parseBuild(tag) {
  const m = /(\d+)\s*$/.exec(tag || '');
  return m ? parseInt(m[1], 10) : 0;
}

export async function checkForUpdates({ manual = false } = {}) {
  if (!info.repo) return { status: 'norepo' };
  if (navigator.onLine === false) return { status: 'error', reason: 'offline' };
  const channel = state.settings.channel || info.channel || 'stable';
  try {
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 9000);
    const r = await fetch(`https://api.github.com/repos/${info.repo}/releases?per_page=20`, { headers: { Accept: 'application/vnd.github+json' }, signal: ctl.signal });
    clearTimeout(to);
    if (!r.ok) return { status: 'error', reason: String(r.status) };
    const list = await r.json();
    let best = null;
    for (const rel of list) {
      if (rel.draft) continue;
      if (channel === 'stable' && rel.prerelease) continue;
      const apk = (rel.assets || []).find((a) => /\.apk$/i.test(a.name));
      if (!apk) continue;
      const build = parseBuild(rel.tag_name);
      if (!best || build > best.build) best = { build, label: (rel.name || rel.tag_name), url: apk.browser_download_url, size: apk.size, notes: rel.body || '', prerelease: !!rel.prerelease };
    }
    try { localStorage.setItem('ahos.lastCheck', String(Date.now())); } catch { /* ignore */ }
    if (best && best.build > (info.build || 0)) return { status: 'available', release: best };
    return { status: 'latest' };
  } catch (e) {
    if (manual) console.warn('update check failed', e);
    return { status: 'error', reason: String(e && e.message || e) };
  }
}

export function downloadUpdate(release) {
  openExternal(release.url);
}

/** Quiet background check: at most twice a day, only when online. */
export function autoCheck(onAvailable) {
  if (!info.repo) return;
  let last = 0;
  try { last = Number(localStorage.getItem('ahos.lastCheck') || 0); } catch { /* ignore */ }
  if (Date.now() - last < 12 * 3600 * 1000) return;
  setTimeout(async () => {
    const r = await checkForUpdates();
    if (r.status === 'available') {
      toast(t('updateAvailable', { v: r.release.label }), { action: t('view'), onAction: () => onAvailable(r.release), ms: 9000 });
    }
  }, 6000);
}
