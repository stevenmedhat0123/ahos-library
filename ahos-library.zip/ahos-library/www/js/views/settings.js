// Settings: language, look, hidden folders, storage, updates.
import { h, fmtBytes } from '../util.js';
import { ic } from '../icons.js';
import { t, lang, setLang } from '../i18n.js';
import { state, setSetting, storageInfo, requestPersist, wipeAll, emit } from '../store.js';
import { confirmDialog, toast } from '../ui.js';
import { hasPin, createPin, removePin } from '../actions.js';
import { getAppInfo, checkForUpdates, downloadUpdate } from '../updater.js';

function seg(options, value, onChange) {
  return h('div', { class: 'seg', role: 'radiogroup' }, options.map(([v, label]) =>
    h('button', { class: 'seg-b' + (value === v ? ' on' : ''), role: 'radio', 'aria-checked': String(value === v), onClick: () => onChange(v) }, label)));
}

function row({ icon, title, sub, control, onClick, danger }) {
  const el = h(onClick ? 'button' : 'div', { class: 'row' + (danger ? ' danger' : '') + (onClick ? ' tap' : ''), onClick },
    icon ? h('span', { class: 'row-ic', html: ic(icon) }) : null,
    h('span', { class: 'row-tx' }, h('b', null, title), sub ? h('small', null, sub) : null),
    control || null);
  return el;
}

function group(title, ...rows) {
  return h('section', { class: 'group' }, title ? h('h2', null, title) : null, h('div', { class: 'group-body' }, rows.filter(Boolean)));
}

export function renderSettings(ctx) {
  const s = state.settings;
  const info = getAppInfo();
  const root = h('div', { class: 'screen settings' });
  root.append(h('header', { class: 'top' }, h('h1', { class: 'top-title' }, t('settings'))));

  root.append(group(t('appearance'),
    row({ icon: 'globe', title: t('language'), control: seg([['ar', 'العربية'], ['en', 'English']], lang(), (v) => { setLang(v); setSetting('lang', v); ctx.applyAppearance(); }) }),
    row({ icon: 'sun', title: t('theme'), control: seg([['dark', t('themeDark')], ['light', t('themeLight')], ['auto', t('themeAuto')]], s.theme, (v) => { setSetting('theme', v); ctx.applyAppearance(); }) }),
    row({ icon: 'sparkle', title: t('background'), sub: t('backgroundSub'), control: seg([['full', t('bgFull')], ['calm', t('bgCalm')], ['off', t('bgOff')]], s.bg, (v) => { setSetting('bg', v); ctx.applyAppearance(); }) }),
    row({ icon: 'repeat', title: t('autoNext'), sub: t('autoNextSub'), control: seg([[true, t('on')], [false, t('off')]], s.autoNext, (v) => setSetting('autoNext', v)) })));

  root.append(group(t('privacy'),
    row({ icon: 'lock', title: t('hiddenFolders'), sub: hasPin() ? t('pinIsSet') : t('pinNotSet'),
      control: hasPin()
        ? h('div', { class: 'row-btns' }, h('button', { class: 'btn ghost sm', onClick: async () => { await removePin(); } }, t('removePin')))
        : h('button', { class: 'btn primary sm', onClick: async () => { await createPin(); emit(); } }, t('createPin')) }),
    h('p', { class: 'note' }, t('pinNote'))));

  const storage = h('div', { class: 'storage' }, h('div', { class: 'meter' }, h('i')), h('small', null, '…'));
  storageInfo().then((si) => {
    const pct = si.quota ? Math.min(100, (si.usage / si.quota) * 100) : 0;
    storage.querySelector('i').style.width = Math.max(2, pct) + '%';
    storage.querySelector('small').textContent = si.quota
      ? t('storageLine', { used: fmtBytes(si.usage), quota: fmtBytes(si.quota), files: fmtBytes(si.files) })
      : t('storageFiles', { files: fmtBytes(si.files) });
    if (!si.persisted && si.quota) {
      storage.append(h('button', { class: 'btn ghost sm', onClick: async () => { const ok = await requestPersist(); toast(ok ? t('persistOn') : t('persistDenied')); ctx.rerender(); } }, t('keepStorage')));
    } else if (si.persisted) storage.append(h('small', { class: 'ok' }, t('persistOn')));
  });
  root.append(group(t('storage'), row({ icon: 'storage', title: t('onThisDevice'), sub: t('offlineNote') }), storage));

  const upd = h('div', { class: 'upd-status' });
  const updBtn = h('button', { class: 'btn primary sm' }, t('checkUpdates'));
  const runCheck = async () => {
    updBtn.disabled = true; upd.textContent = t('checking');
    const r = await checkForUpdates({ manual: true });
    updBtn.disabled = false;
    if (r.status === 'available') {
      upd.replaceChildren(h('b', null, t('updateAvailable', { v: r.release.label })),
        h('button', { class: 'btn primary sm', onClick: () => downloadUpdate(r.release) }, t('downloadUpdate')));
    } else if (r.status === 'latest') upd.textContent = t('upToDate');
    else if (r.status === 'norepo') upd.textContent = t('noUpdateSource');
    else upd.textContent = t('updateError');
  };
  updBtn.addEventListener('click', runCheck);
  root.append(group(t('updates'),
    row({ icon: 'download', title: t('version'), sub: `${info.version}${info.channel === 'beta' ? ' beta' : ''} · build ${info.build}` }),
    row({ icon: 'sparkle', title: t('channel'), sub: t('channelSub'), control: seg([['stable', t('chStable')], ['beta', t('chBeta')]], s.channel || info.channel || 'stable', (v) => { setSetting('channel', v); ctx.rerender(); }) }),
    row({ icon: 'cloud', title: t('checkUpdates'), control: updBtn }),
    upd));

  if (ctx.canInstall()) {
    root.append(group(t('install'), row({ icon: 'mobile', title: t('installApp'), sub: t('installSub'), onClick: () => ctx.install() })));
  }

  root.append(group(t('data'),
    row({ icon: 'trash', title: t('deleteEverything'), sub: t('deleteEverythingSub'), danger: true, onClick: async () => {
      if (!(await confirmDialog({ title: t('deleteEverything'), message: t('deleteEverythingMsg'), ok: t('delete'), danger: true }))) return;
      await wipeAll(); toast(t('libraryCleared'));
    } })));

  root.append(h('footer', { class: 'about' },
    h('div', { class: 'about-mark' }, h('b', null, 'AHOS Library'), h('small', null, `v${info.version} · build ${info.build}`)),
    h('small', null, t('aboutLine'))));
  return root;
}
