// Home: continue where you left off, jump by type, recent and favourite items.
import { h, fmtBytes } from '../util.js';
import { ic } from '../icons.js';
import { mark } from '../brand.js';
import { t } from '../i18n.js';
import { state, visibleItems, hasVault } from '../store.js';
import { itemCard, sectionHead, hubBtn } from './shared.js';
import { mediaLists, stripNodes, wireMedia } from './mediastrips.js';
import { playlistCards } from '../playlists.js';
import { pushLayer } from '../ui.js';
import { setSearchQuery } from './search.js';


const KINDS = ['video', 'image', 'book', 'audio', 'file'];

/** Brand + icons with no band behind them. The search icon turns the header into a long search bar (covering the brand); Enter opens the results. */
function homeHeader(ctx) {
  const input = h('input', { class: 'hs-input', type: 'search', placeholder: t('searchPlaceholder'), enterkeyhint: 'search', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': t('search') });
  let layer = null;
  const head = h('header', { class: 'top home-top' });
  const shut = () => { head.classList.remove('searching'); input.blur(); };
  const close = () => { if (layer && !layer.closed) layer.close(); else shut(); };
  const openBar = () => {
    head.classList.add('searching');
    if (!layer || layer.closed) layer = pushLayer(() => { layer = null; shut(); });
    setTimeout(() => input.focus(), 40);
  };
  const form = h('form', { class: 'hs', role: 'search', onSubmit: (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (q) setSearchQuery(q);
    if (layer && !layer.closed) layer.close();
    ctx.go('search');
  } },
  h('span', { class: 'hs-ic', html: ic('search') }), input,
  h('button', { type: 'button', class: 'icon-btn sm', 'aria-label': t('cancel'), onClick: close, html: ic('close') }));
  head.append(
    hubBtn(ctx),
    h('div', { class: 'brand' }, h('span', { class: 'brand-mark', html: mark() }),
      h('span', { class: 'brand-name' }, 'AHOS', h('small', null, 'Library'))),
    h('div', { class: 'top-actions' },
      hasVault() ? h('button', { class: 'icon-btn', 'aria-label': state.vaultOpen ? t('hideAgain') : t('unlockHidden'), onClick: () => ctx.toggleVault(), html: ic(state.vaultOpen ? 'unlock' : 'lock') }) : null,
      h('button', { class: 'icon-btn', 'aria-label': t('search'), onClick: openBar, html: ic('search') })),
    form);
  return head;
}

export function renderHome(ctx) {
  const items = visibleItems();
  const root = h('div', { class: 'screen home' });

  root.append(homeHeader(ctx));

  if (!items.length && !state.folders.size) {
    root.append(h('section', { class: 'hero-empty' },
      h('div', { class: 'hero-mark', html: mark() }),
      h('h1', null, t('emptyTitle')),
      h('p', null, t('emptyText')),
      h('div', { class: 'hero-actions' },
        h('button', { class: 'btn primary lg', onClick: () => ctx.addFiles() }, h('span', { html: ic('plus') }), t('addFiles')),
        h('button', { class: 'btn ghost lg', onClick: () => ctx.newFolder() }, h('span', { html: ic('folderPlus') }), t('newFolder'))),
      h('ul', { class: 'hero-points' },
        h('li', null, h('span', { html: ic('cloud') }), t('pointOffline')),
        h('li', null, h('span', { html: ic('shield') }), t('pointPrivate')))));
    return root;
  }

  const total = items.reduce((a, i) => a + (i.size || 0), 0);
  root.append(h('div', { class: 'greet' },
    h('h1', null, t('homeTitle')),
    h('p', null, t('homeStats', { n: items.length, size: fmtBytes(total) }))));

  const { cont, played } = mediaLists(items, { favs: false });
  const lead = stripNodes({ cont, played, fav: [] });
  root.append(...lead);

  const counts = Object.fromEntries(KINDS.map((k) => [k, 0]));
  items.forEach((i) => counts[i.kind]++);
  root.append(sectionHead(t('browse')),
    h('div', { class: 'kinds' }, KINDS.map((k) =>
      h('button', { class: `kind-tile k-${k}`, onClick: () => ctx.openLibrary({ filter: k }) },
        h('span', { class: 'kt-ic', html: ic(k) }),
        h('span', { class: 'kt-nm' }, t('kinds_' + k)),
        h('span', { class: 'kt-n' }, String(counts[k]))))));

  root.append(sectionHead(t('playlists')), playlistCards(ctx));

  const recent = items.filter((i) => !i.noRecent).sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 12);
  if (recent.length) {
    root.append(sectionHead(t('recent'), { action: t('seeAll'), onAction: () => ctx.openLibrary({ filter: 'all', sort: 'added-desc' }) }),
      h('div', { class: 'strip', dataset: { sec: 'recent' } }, recent.map((i) => itemCard(i, { mode: 'mini' }))));
  }

  const favs = items.filter((i) => i.fav).slice(0, 12);
  if (favs.length) {
    root.append(sectionHead(t('favorites'), { action: t('seeAll'), onAction: () => ctx.openLibrary({ filter: 'fav' }) }),
      h('div', { class: 'strip', dataset: { sec: 'fav' } }, favs.map((i) => itemCard(i, { mode: 'mini' }))));
  }

  wireMedia(root, ctx, cont.concat(played, recent, favs).map((i) => i.id));
  return root;
}
