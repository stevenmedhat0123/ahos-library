// Owner panel: subscription codes, the member list, and the owner's own account.
// Only reachable after the owner signs in (auth.js checks the signed token; the server checks it again on every call).
import { h, fmtDate } from '../util.js';
import { ic } from '../icons.js';
import { t, lang } from '../i18n.js';
import { toast, pushLayer, confirmDialog, promptDialog, openSheet } from '../ui.js';
import { admin, isOwner, sessionInfo, changePassword, changeBackup, logout } from '../auth.js';
import { serverUrl, derive } from '../server.js';
import { shareText, copyText } from '../native.js';
import { errText } from './gate.js';

const UNITS = ['day', 'week', 'month', 'year'];
let open = null; // { root, layer }

/* ---------------- helpers ---------------- */
function randomCode() {
  const up = 'ABCDEFGHJKLMNPQRSTUVWXYZ', lo = 'abcdefghijkmnpqrstuvwxyz', dg = '23456789', sy = '#@$%&*+=?!';
  const rnd = (n) => crypto.getRandomValues(new Uint32Array(1))[0] % n;
  const pick = (s) => s[rnd(s.length)];
  const chars = [pick(up), pick(lo), pick(dg), pick(sy), pick(sy)];
  const pool = up + lo + dg;
  while (chars.length < 14) chars.push(pick(pool));
  for (let i = chars.length - 1; i > 0; i--) { const j = rnd(i + 1); [chars[i], chars[j]] = [chars[j], chars[i]]; }
  return chars.join('');
}

function segmented(options, value, onChange) {
  let cur = value;
  const el = h('div', { class: 'seg', role: 'radiogroup' });
  const paint = () => el.replaceChildren(...options.map(([v, label]) =>
    h('button', { type: 'button', class: 'seg-b' + (cur === v ? ' on' : ''), role: 'radio', 'aria-checked': String(cur === v), onClick: () => { cur = v; paint(); onChange?.(v); } }, label)));
  paint();
  return { el, get: () => cur };
}

const unitOptions = () => UNITS.map((u) => [u, t('u_' + u)]);
const when = (ts) => fmtDate(ts, lang());
const fail = (e) => toast(errText(e));

async function copy(text) { toast((await copyText(text)) ? t('o_copied') : t('o_copyFail')); }

function numberField({ value = 1, min = 1, max = 36500, label }) {
  const input = h('input', { class: 'field op-num', type: 'number', inputmode: 'numeric', min, max, value, dir: 'ltr' });
  return { input, wrap: h('label', { class: 'g-f' }, label ? h('span', null, label) : null, input), get: () => Math.floor(Number(input.value)) };
}

function loader(host, load, render) {
  host.replaceChildren(h('div', { class: 'g-spin' }));
  return load().then((data) => { render(data); }).catch((e) => {
    host.replaceChildren(h('div', { class: 'op-fail' }, h('p', null, errText(e)),
      h('button', { class: 'btn ghost sm', onClick: () => loader(host, load, render) }, t('g_retry'))));
  });
}

/* ---------------- codes ---------------- */
function codesTab() {
  const root = h('div', { class: 'op-tab' });
  const listHost = h('div', { class: 'op-list' });

  const codeIn = h('input', { class: 'field g-code', type: 'text', dir: 'ltr', placeholder: t('o_codePh'), autocomplete: 'off', autocapitalize: 'none', autocorrect: 'off', spellcheck: 'false', maxlength: 64 });
  const rndBtn = h('button', { class: 'btn ghost sm', type: 'button', onClick: () => { codeIn.value = randomCode(); } }, h('span', { html: ic('sparkle') }), t('o_random'));
  const amount = numberField({ value: 30, label: t('o_duration') });
  const unit = segmented(unitOptions(), 'day');
  const uses = numberField({ value: 1, max: 100000, label: t('o_uses') });
  const note = h('input', { class: 'field', type: 'text', maxlength: 120, placeholder: t('o_notePh') });
  const made = h('div', { class: 'op-made' });
  const submit = h('button', { class: 'btn primary lg', type: 'submit' }, t('o_create'));

  const form = h('form', { class: 'op-card op-new', novalidate: true, onSubmit: async (e) => {
    e.preventDefault();
    submit.disabled = true;
    try {
      const r = await admin('code/create', { code: codeIn.value.trim(), amount: amount.get(), unit: unit.get(), max: uses.get(), note: note.value.trim() });
      codeIn.value = ''; note.value = '';
      showMade(r.code);
      load();
    } catch (x) { fail(x); } finally { submit.disabled = false; }
  } },
  h('h3', null, t('o_newCode')),
  h('label', { class: 'g-f' }, h('span', null, t('o_codeText')), h('div', { class: 'op-codeRow' }, codeIn, rndBtn), h('small', null, t('o_codeHint'))),
  h('div', { class: 'g-f' }, h('span', null, t('o_duration')), h('div', { class: 'op-durRow' }, amount.input, unit.el), h('small', null, t('o_durHint'))),
  uses.wrap, h('small', { class: 'op-hint' }, t('o_usesHint')),
  h('label', { class: 'g-f' }, h('span', null, t('o_note')), note),
  submit);

  function showMade(code) {
    made.replaceChildren(h('div', { class: 'op-card op-made-in' },
      h('b', null, t('o_created')),
      h('code', { class: 'op-code big', dir: 'ltr' }, code),
      h('div', { class: 'op-actions' },
        h('button', { class: 'btn primary sm', onClick: () => copy(code) }, t('o_copy')),
        h('button', { class: 'btn ghost sm', onClick: async () => { if (!(await shareText(t('o_shareText', { code })))) copy(code); } }, t('o_share')))));
  }

  function card(c) {
    const left = c.max - c.used;
    const st = c.revoked ? 'revoked' : left <= 0 ? 'used' : 'active';
    return h('div', { class: 'op-card ' + st },
      h('div', { class: 'op-row' }, h('code', { class: 'op-code', dir: 'ltr' }, c.code), h('span', { class: 'op-badge ' + st }, t('o_st_' + st))),
      h('div', { class: 'op-meta' }, `${t('dur', { n: c.amount, unit: c.unit })} · ${t('o_usesLine', { used: c.used, max: c.max })}`),
      c.note ? h('div', { class: 'op-meta' }, c.note) : null,
      c.by.length ? h('div', { class: 'op-by' }, h('small', null, t('o_usedBy')), c.by.map((b) => h('span', { class: 'op-chip' }, `${b.name} · ${when(b.at)}`))) : null,
      h('div', { class: 'op-actions' },
        h('button', { class: 'btn ghost sm', onClick: () => copy(c.code) }, t('o_copy')),
        h('button', { class: 'btn ghost sm', onClick: async () => {
          if (!c.revoked && !(await confirmDialog({ title: t('o_revokeQ'), message: t('o_revokeMsg'), ok: t('o_revoke'), danger: true }))) return;
          try { await admin('code/revoke', { code: c.code, revoked: !c.revoked }); load(); } catch (x) { fail(x); }
        } }, c.revoked ? t('o_restore') : t('o_revoke')),
        h('button', { class: 'btn ghost sm danger-t', onClick: async () => {
          if (!(await confirmDialog({ title: t('o_deleteCodeQ'), message: t('o_deleteCodeMsg'), ok: t('delete'), danger: true }))) return;
          try { await admin('code/delete', { code: c.code }); load(); } catch (x) { fail(x); }
        } }, t('delete'))));
  }

  function load() {
    return loader(listHost, () => admin('codes'), ({ codes }) => {
      listHost.replaceChildren(...(codes.length ? codes.map(card) : [h('p', { class: 'op-empty' }, t('o_noCodes'))]));
    });
  }
  root.append(form, made, listHost);
  load();
  return root;
}

/* ---------------- members ---------------- */
function memberState(m) {
  const now = Date.now();
  if (m.blocked) return { st: 'blocked', text: t('o_m_blocked') };
  if (m.end > now) return { st: 'active', text: t('o_m_active', { date: when(m.end) }) };
  if (m.end > 0) return { st: 'used', text: t('o_m_expired', { date: when(m.end) }) };
  return { st: 'none', text: t('o_m_none') };
}

function membersTab() {
  const root = h('div', { class: 'op-tab' });
  const search = h('input', { class: 'field', type: 'search', placeholder: t('o_search'), autocomplete: 'off', spellcheck: 'false' });
  const summary = h('div', { class: 'op-summary' });
  const listHost = h('div', { class: 'op-list' });
  let members = [];

  const paint = () => {
    const q = search.value.trim().toLowerCase();
    const shown = members.filter((m) => !q || m.name.toLowerCase().includes(q));
    const active = members.filter((m) => !m.blocked && m.end > Date.now()).length;
    summary.textContent = t('o_membersCount', { n: members.length, active });
    listHost.replaceChildren(...(shown.length ? shown.map((m) => {
      const s = memberState(m);
      return h('button', { class: 'op-card op-member ' + s.st, type: 'button', onClick: () => manage(m) },
        h('div', { class: 'op-row' }, h('b', { class: 'op-name', dir: 'auto' }, m.name), h('span', { class: 'op-badge ' + s.st }, s.st === 'active' ? t('o_st_active') : s.st === 'blocked' ? t('o_m_blocked') : s.st === 'used' ? t('o_st_ended') : t('o_st_none'))),
        h('div', { class: 'op-meta' }, s.text),
        h('div', { class: 'op-meta faint' }, `${t('o_seen')}: ${m.seen ? when(m.seen) : '—'}`));
    }) : [h('p', { class: 'op-empty' }, members.length ? t('noResults') : t('o_noMembers'))]));
  };
  search.addEventListener('input', paint);

  function load() {
    return loader(listHost, () => admin('members'), (r) => { members = r.members; paint(); });
  }

  function manage(m) {
    const s = memberState(m);
    const sheet = openSheet({ title: m.name, tall: true, className: 'op-sheet' });
    const done = (msg) => { sheet.close(); if (msg) toast(msg); load(); };
    const amount = numberField({ value: 30, label: t('o_extend') });
    const unit = segmented(unitOptions(), 'day');
    const act = (icon, label, fn, danger = false) => h('button', { class: 'act' + (danger ? ' danger' : ''), onClick: fn }, h('span', { class: 'act-ic', html: ic(icon) }), h('span', { class: 'act-label' }, label));
    sheet.body.append(
      h('div', { class: 'op-meta' }, s.text),
      h('div', { class: 'op-meta faint' }, `${t('o_joined')}: ${when(m.created)} · ${t('o_seen')}: ${m.seen ? when(m.seen) : '—'}`),
      m.codes.length ? h('div', { class: 'op-by' }, h('small', null, t('o_codesUsed', { n: m.codes.length })), m.codes.slice(0, 8).map((c) => h('span', { class: 'op-chip', dir: 'ltr' }, `${c.code} · ${when(c.at)}`))) : null,
      h('div', { class: 'op-extend' }, amount.wrap, unit.el,
        h('button', { class: 'btn primary', onClick: async () => {
          try { const r = await admin('member/extend', { id: m.id, amount: amount.get(), unit: unit.get() }); done(t('o_extended', { date: when(r.end) })); } catch (x) { fail(x); }
        } }, t('o_extendBtn'))),
      m.end > Date.now() ? act('clock', t('o_endNow'), async () => {
        if (!(await confirmDialog({ title: t('o_endNow'), message: t('o_endMsg', { name: m.name }), ok: t('o_endNow'), danger: true }))) return;
        try { await admin('member/end', { id: m.id }); done(t('o_ended')); } catch (x) { fail(x); }
      }) : null,
      act(m.blocked ? 'unlock' : 'lock', m.blocked ? t('o_unblock') : t('o_block'), async () => {
        try { await admin('member/block', { id: m.id, blocked: !m.blocked }); done(m.blocked ? t('o_unblocked') : t('o_blocked')); } catch (x) { fail(x); }
      }),
      act('edit', t('o_setPw'), async () => {
        const pw = await promptDialog({ title: t('o_setPw'), message: t('o_setPwMsg'), type: 'text', ok: t('save'), maxlength: 100 });
        if (!pw) return;
        if (pw.length < 6) { toast(t('g_pwShort', { n: 6 })); return; }
        try { await admin('member/password', { id: m.id, pw: await derive(pw, m.name) }); done(t('o_pwSet')); } catch (x) { fail(x); }
      }),
      act('trash', t('o_deleteMember'), async () => {
        if (!(await confirmDialog({ title: t('o_deleteMemberQ', { name: m.name }), message: t('o_deleteMemberMsg'), ok: t('delete'), danger: true }))) return;
        try { await admin('member/delete', { id: m.id }); done(t('o_deleted')); } catch (x) { fail(x); }
      }, true));
  }

  root.append(search, summary, listHost);
  load();
  return root;
}

/* ---------------- owner account ---------------- */
function accountTab() {
  const me = sessionInfo();
  const askTwo = async (title, curMsg, nextMsg, min) => {
    const cur = await promptDialog({ title, message: curMsg, type: 'password', ok: t('next'), maxlength: 200 });
    if (!cur) return null;
    const next = await promptDialog({ title, message: nextMsg, type: 'password', ok: t('save'), maxlength: 200 });
    if (!next) return null;
    if (next.length < min) { toast(t('g_pwShort', { n: min })); return null; }
    return { cur, next };
  };
  const row = (icon, title, sub, onClick, danger = false) => h('button', { class: 'row tap' + (danger ? ' danger' : ''), onClick },
    h('span', { class: 'row-ic', html: ic(icon) }), h('span', { class: 'row-tx' }, h('b', null, title), sub ? h('small', null, sub) : null));
  return h('div', { class: 'op-tab' },
    h('div', { class: 'op-card' }, h('b', { dir: 'auto' }, me?.name || ''), h('div', { class: 'op-meta' }, t('acc_owner'))),
    h('div', { class: 'group-body' },
      row('lock', t('o_changeMain'), null, async () => {
        const r = await askTwo(t('o_changeMain'), t('acc_curPw'), t('g_newPw'), 8);
        if (!r) return;
        try { await changePassword(r.cur, r.next); toast(t('g_pwChanged')); } catch (x) { fail(x); }
      }),
      row('shield', t('o_changeBackup'), t('o_changeBackupSub'), async () => {
        const r = await askTwo(t('o_changeBackup'), t('o_curBackup'), t('o_newBackup'), 8);
        if (!r) return;
        try { await changeBackup(r.cur, r.next); toast(t('o_backupChanged')); } catch (x) { fail(x); }
      }),
      row('upload', t('g_signOut'), null, async () => {
        if (await confirmDialog({ title: t('g_signOut'), message: t('acc_signOutMsg'), ok: t('g_signOut'), danger: true })) { closeOwnerPanel(); logout(); }
      }, true)),
    h('p', { class: 'gate-note' }, t('o_server'), ' ', h('span', { dir: 'ltr' }, serverUrl())));
}

/* ---------------- shell ---------------- */
export function closeOwnerPanel() {
  if (!open) return;
  const { root, layer } = open;
  open = null;
  root.classList.remove('in');
  setTimeout(() => root.remove(), 250);
  if (layer && !layer.closed) layer.close();
}

export function openOwnerPanel({ tab = 'codes' } = {}) {
  if (!isOwner() || open) return;
  const body = h('div', { class: 'op-body' });
  const tabs = [['codes', t('o_tabCodes'), codesTab], ['members', t('o_tabMembers'), membersTab], ['account', t('o_tabAccount'), accountTab]];
  const bar = h('div', { class: 'op-tabs', role: 'tablist' });
  const cache = new Map();
  const select = (id) => {
    bar.querySelectorAll('button').forEach((b) => { const on = b.dataset.tab === id; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
    if (!cache.has(id)) cache.set(id, tabs.find((x) => x[0] === id)[2]());
    body.replaceChildren(cache.get(id));
    body.scrollTop = 0;
  };
  tabs.forEach(([id, label]) => bar.append(h('button', { class: 'op-tab-b', role: 'tab', dataset: { tab: id }, onClick: () => select(id) }, label)));
  const root = h('div', { class: 'opanel', role: 'dialog', 'aria-modal': 'true' },
    h('header', { class: 'op-top' },
      h('h1', null, t('o_title')),
      h('button', { class: 'icon-btn', 'aria-label': t('o_close'), html: ic('close'), onClick: () => closeOwnerPanel() })),
    bar, body);
  document.body.append(root);
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('in')));
  const layer = pushLayer(() => { open = null; root.classList.remove('in'); setTimeout(() => root.remove(), 250); });
  open = { root, layer };
  select(tab);
}

export const ownerPanelOpen = () => !!open;
