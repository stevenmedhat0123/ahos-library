// Importing files into the library (file picker, folder picker, drag & drop).
import { uid, kindOf, extOf } from './util.js';
import { state, addItem, updateItem, createFolder, childFolders } from './store.js';
import { analyze } from './covers.js';
import { progressCard, toast } from './ui.js';
import { t } from './i18n.js';

export function pickFiles({ accept = '', multiple = true, directory = false } = {}) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = multiple;
    if (accept) input.accept = accept;
    if (directory) { input.setAttribute('webkitdirectory', ''); input.setAttribute('directory', ''); }
    input.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
    document.body.append(input);
    const done = (files) => { input.remove(); resolve(files); };
    input.addEventListener('change', () => done(Array.from(input.files || [])));
    input.addEventListener('cancel', () => done([]));
    input.click();
  });
}

/** Creates (or reuses) the folder chain for a webkitRelativePath like "Course/Week 1/a.mp4". */
function ensureFolderPath(parts, rootId, cache) {
  let parent = rootId || null;
  let key = '';
  for (const name of parts) {
    key += '/' + name;
    if (!cache.has(key)) {
      const existing = childFolders(parent).find((f) => f.name === name);
      cache.set(key, (existing || createFolder(name, parent)).id);
    }
    parent = cache.get(key);
  }
  return parent;
}

export async function importFiles(files, folderId = null) {
  files = files.filter((f) => f && f.size >= 0);
  if (!files.length) return { ok: 0 };
  const card = progressCard(t('importing'));
  let ok = 0, skipped = 0, failed = 0;
  const folderCache = new Map();

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    card.update(`${i + 1} / ${files.length}  ·  ${f.name}`, i / files.length);

    let target = folderId || null;
    const rel = f.webkitRelativePath;
    if (rel && rel.includes('/')) target = ensureFolderPath(rel.split('/').slice(0, -1), folderId, folderCache);

    const dup = [...state.items.values()].some((x) => x.name === f.name && x.size === f.size && (x.folderId || null) === target);
    if (dup) { skipped++; continue; }

    const kind = kindOf(f), ext = extOf(f.name);
    const id = uid();
    const item = {
      id, name: f.name, kind, ext, mime: f.type || '', size: f.size,
      folderId: target, tags: [], fav: false, added: Date.now() + i, opened: 0, progress: null, thumb: null, meta: {},
    };
    try {
      await addItem(item, f);
      ok++;
    } catch (e) {
      failed++;
      console.warn('import failed', f.name, e);
      if (e && e.name === 'QuotaExceededError') { toast(t('storageFull')); break; }
      continue;
    }
    const { thumb, meta } = await analyze(f, kind, ext);
    updateItem(id, { thumb, meta: { ...(meta || {}) } });
  }

  card.update(t('done'), 1);
  setTimeout(() => card.done(), 450);
  const parts = [];
  if (ok) parts.push(t('importedN', { n: ok }));
  if (skipped) parts.push(t('skippedN', { n: skipped }));
  if (failed) parts.push(t('failedN', { n: failed }));
  toast(parts.join(' · ') || t('nothingImported'));
  return { ok, skipped, failed };
}
