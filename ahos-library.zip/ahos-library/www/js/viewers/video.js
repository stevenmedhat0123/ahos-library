// Video + audio player with gestures, resume, subtitles, playlist and speed control.
import { h, fmtDur, clamp, readText, isNative } from '../util.js';
import { ic } from '../icons.js';
import { t } from '../i18n.js';
import { state, getBlob, updateItem, setSetting } from '../store.js';
import { actionSheet, toast } from '../ui.js';
import { mountViewer, touchOpened, saveProgress, barBtn } from './common.js';
import { thumbURL, genSVG } from '../covers.js';
import { lockOrientation, immersive, keepAwake } from '../native.js';
import { pickFiles } from '../import.js';
import { exportItem, itemActions } from '../actions.js';

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

function srtToVtt(s) {
  return 'WEBVTT\n\n' + s.replace(/\r+/g, '').replace(/^﻿/, '').replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2').trim() + '\n';
}

export function openMedia(startId, listIds = []) {
  const start = state.items.get(startId);
  if (!start) return;
  const kind = start.kind;
  const items = listIds.map((i) => state.items.get(i)).filter((it) => it && it.kind === kind);
  let idx = items.findIndex((i) => i.id === startId);
  if (idx < 0) { items.unshift(start); idx = 0; }
  let cur = items[idx];
  let url = '';
  let landscape = false;
  let uiTimer = 0, saveTimer = 0, raf = 0, holdTimer = 0, holding = false, lastTap = 0, lastX = 0, tapTimer = 0;
  let speed = state.settings.speed || 1;
  let fit = 'contain';
  let dragging = false;
  const subUrls = [];

  const V = mountViewer(`media k-${kind}`, { onClose: cleanup });
  const root = V.el;
  root.classList.add('ui-on');

  const video = h('video', { playsinline: '', preload: 'auto', crossorigin: 'anonymous' });
  video.setAttribute('webkit-playsinline', '');
  const art = h('div', { class: 'a-art' });
  const tapZone = h('div', { class: 'v-tap' });
  const indicator = h('div', { class: 'v-ind' });
  const err = h('div', { class: 'v-err' });
  const spinner = h('div', { class: 'v-spin' });

  /* ---------- controls ---------- */
  const title = h('div', { class: 'v-title', dir: 'auto' });
  const sub = h('div', { class: 'v-subtitle', dir: 'auto' });
  const playBtn = h('button', { class: 'v-play', 'aria-label': t('play'), onClick: () => toggle() });
  const prevBtn = barBtn('prev', t('previous'), () => go(-1), 'v-prev');
  const nextBtn = barBtn('next', t('next'), () => go(1), 'v-next');
  const rewBtn = barBtn('rew10', '-10', () => seekBy(-10), 'v-rew');
  const fwdBtn = barBtn('fwd10', '+10', () => seekBy(10), 'v-fwd');
  const curT = h('span', { class: 'v-time' }, '0:00');
  const durT = h('span', { class: 'v-time' }, '0:00');
  const buf = h('i', { class: 'sb-buf' });
  const fill = h('i', { class: 'sb-fill' });
  const knob = h('i', { class: 'sb-knob' });
  const bubble = h('span', { class: 'sb-bubble' });
  const bar = h('div', { class: 'sb', role: 'slider', tabindex: '0', 'aria-label': t('seek') }, h('div', { class: 'sb-track' }, buf, fill, knob), bubble);

  const ccBtn = barBtn('cc', t('subtitles'), () => subsMenu());
  const speedBtn = h('button', { class: 'vbtn txt', 'aria-label': t('speed'), onClick: () => speedMenu() }, '1×');
  const fitBtn = barBtn('fit', t('fitFill'), () => { fit = fit === 'contain' ? 'cover' : 'contain'; video.style.objectFit = fit; flash(fit === 'cover' ? t('fill') : t('fit')); });
  const pipBtn = barBtn('pip', t('pip'), async () => { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else await video.requestPictureInPicture(); } catch { toast(t('pipUnavailable')); } });
  const rotBtn = barBtn('rotate', t('rotate'), () => toggleLandscape());
  const moreBtn = barBtn('more', t('more'), () => itemActions(cur.id, { afterDelete: () => V.close() }));

  const top = h('div', { class: 'v-top' },
    h('button', { class: 'vbtn', 'aria-label': t('back'), onClick: () => V.close(), html: ic('back', 'flip-rtl') }),
    h('div', { class: 'v-titles' }, title, sub),
    kind === 'video' ? ccBtn : null, speedBtn, moreBtn);
  const mid = h('div', { class: 'v-mid' }, prevBtn, rewBtn, playBtn, fwdBtn, nextBtn);
  const bottom = h('div', { class: 'v-bot', dir: 'ltr' },
    h('div', { class: 'v-seekrow' }, curT, bar, durT),
    kind === 'video' ? h('div', { class: 'v-tools' }, fitBtn, document.pictureInPictureEnabled ? pipBtn : null, rotBtn) : null);
  const ui = h('div', { class: 'v-ui' }, top, mid, bottom);

  root.append(h('div', { class: 'v-stage' }, video, art, tapZone, spinner, indicator, err), ui);
  video.style.objectFit = fit;

  /* ---------- helpers ---------- */
  function setPlayIcon() { playBtn.innerHTML = ic(video.paused ? 'play' : 'pause'); playBtn.setAttribute('aria-label', video.paused ? t('play') : t('pause')); root.classList.toggle('paused', video.paused); }
  function flash(text, pos) {
    indicator.textContent = text;
    indicator.className = 'v-ind show ' + (pos || '');
    clearTimeout(flash.t); flash.t = setTimeout(() => { indicator.className = 'v-ind'; }, 650);
  }
  function showUI() {
    root.classList.add('ui-on');
    clearTimeout(uiTimer);
    if (kind === 'video' && !video.paused && !dragging) uiTimer = setTimeout(() => root.classList.remove('ui-on'), 3200);
  }
  function toggleUI() { if (root.classList.contains('ui-on') && !video.paused && kind === 'video') { root.classList.remove('ui-on'); clearTimeout(uiTimer); } else showUI(); }
  function toggle() { if (video.paused) video.play().catch(() => {}); else video.pause(); }
  function seekBy(d) {
    if (!isFinite(video.duration)) return;
    video.currentTime = clamp(video.currentTime + d, 0, video.duration);
    flash((d > 0 ? '+' : '−') + Math.abs(d) + ' ' + t('sec'), d > 0 ? 'right' : 'left');
    showUI();
  }

  function paint() {
    const d = video.duration;
    const c = video.currentTime;
    if (isFinite(d) && d > 0) {
      const p = (c / d) * 100;
      fill.style.width = p + '%'; knob.style.left = p + '%';
      if (video.buffered.length) { buf.style.width = (video.buffered.end(video.buffered.length - 1) / d) * 100 + '%'; }
      durT.textContent = fmtDur(d);
    }
    if (!dragging) curT.textContent = fmtDur(c);
  }
  function loop() { paint(); if (!video.paused) raf = requestAnimationFrame(loop); }

  function persist() {
    const d = video.duration;
    if (!isFinite(d) || d <= 0 || !cur) return;
    const c = video.currentTime;
    if (c < 3 && !(cur.progress && cur.progress.f > 0)) return;
    const done = c > d - Math.min(8, d * 0.04);
    saveProgress(cur.id, done ? 1 : c / d, done ? 0 : c);
    if (!cur.meta?.duration) updateItem(cur.id, { meta: { ...cur.meta, duration: d, w: video.videoWidth, h: video.videoHeight } }, { silent: true });
  }

  /* ---------- loading items ---------- */
  async function load(i, { autoplay = true } = {}) {
    persist();
    idx = clamp(i, 0, items.length - 1);
    cur = items[idx];
    touchOpened(cur.id);
    err.classList.remove('show');
    spinner.classList.add('show');
    title.textContent = cur.meta?.title || cur.name.replace(/\.[^.]+$/, '');
    sub.textContent = kind === 'audio' ? (cur.meta?.author || '') : (items.length > 1 ? `${idx + 1} / ${items.length}` : '');
    prevBtn.disabled = idx <= 0; nextBtn.disabled = idx >= items.length - 1;
    prevBtn.classList.toggle('off', prevBtn.disabled); nextBtn.classList.toggle('off', nextBtn.disabled);
    drawArt();
    const blob = await getBlob(cur.id);
    if (!blob) { showError(t('fileMissing')); return; }
    if (url) URL.revokeObjectURL(url);
    video.querySelectorAll('track').forEach((tr) => tr.remove());
    subUrls.splice(0).forEach((u) => URL.revokeObjectURL(u));
    url = URL.createObjectURL(blob);
    video.src = url;
    video.defaultPlaybackRate = speed; video.playbackRate = speed;
    (cur.subs || []).forEach((s, n) => addTrack(s, n === 0));
    const resume = cur.progress && cur.progress.f > 0 && cur.progress.f < 0.97 ? cur.progress.pos : 0;
    video.addEventListener('loadedmetadata', () => { if (resume > 2 && isFinite(video.duration)) video.currentTime = Math.min(resume, video.duration - 2); }, { once: true });
    if (autoplay) video.play().catch(() => { setPlayIcon(); });
    updateMediaSession();
  }

  function drawArt() {
    art.replaceChildren();
    if (kind !== 'audio') return;
    const u = thumbURL(cur);
    const cover = h('div', { class: 'a-cover' });
    if (u) cover.append(h('img', { src: u, alt: '' })); else cover.innerHTML = genSVG(cur.id + cur.name, 'audio') + `<div class="gen-ic">${ic('audio')}</div>`;
    art.append(cover, h('div', { class: 'a-name', dir: 'auto' }, cur.meta?.title || cur.name.replace(/\.[^.]+$/, '')), h('div', { class: 'a-by', dir: 'auto' }, cur.meta?.author || ''));
  }

  function showError(msg) {
    spinner.classList.remove('show');
    err.replaceChildren(h('div', { class: 've-ic', html: ic('info') }), h('p', null, msg),
      h('button', { class: 'btn primary', onClick: () => exportItem(cur.id) }, h('span', { html: ic('share') }), t('exportOpenWith')));
    err.classList.add('show');
    root.classList.add('ui-on');
  }

  function go(d) {
    const n = idx + d;
    if (n < 0 || n >= items.length) return;
    load(n);
  }

  /* ---------- subtitles ---------- */
  function addTrack(s, show) {
    const u = URL.createObjectURL(new Blob([s.vtt], { type: 'text/vtt' }));
    subUrls.push(u);
    const tr = h('track', { kind: 'subtitles', label: s.name, srclang: 'und', src: u });
    video.append(tr);
    tr.track.mode = show ? 'showing' : 'disabled';
  }
  function subsMenu() {
    const tracks = Array.from(video.textTracks);
    actionSheet(t('subtitles'), [
      { icon: 'close', label: t('subsOff'), checked: !tracks.some((x) => x.mode === 'showing'), onClick: () => tracks.forEach((x) => { x.mode = 'disabled'; }) },
      ...tracks.map((tr) => ({ icon: 'cc', label: tr.label || 'Subtitles', checked: tr.mode === 'showing', onClick: () => tracks.forEach((x) => { x.mode = x === tr ? 'showing' : 'disabled'; }) })),
      { icon: 'plus', label: t('addSubs'), onClick: async () => {
        const [f] = await pickFiles({ accept: '.srt,.vtt,text/vtt,application/x-subrip', multiple: false });
        if (!f) return;
        let text = await readText(f);
        if (!/^﻿?WEBVTT/.test(text)) text = srtToVtt(text);
        const entry = { name: f.name.replace(/\.[^.]+$/, ''), vtt: text };
        updateItem(cur.id, { subs: [...(cur.subs || []), entry] }, { silent: true });
        Array.from(video.textTracks).forEach((x) => { x.mode = 'disabled'; });
        addTrack(entry, true);
        toast(t('subsAdded'));
      } },
    ]);
  }

  function speedMenu() {
    actionSheet(t('speed'), SPEEDS.map((s) => ({ icon: 'speed', label: s + '×', checked: s === speed, onClick: () => setSpeed(s) })));
  }
  function setSpeed(s) { speed = s; video.defaultPlaybackRate = s; video.playbackRate = s; speedBtn.textContent = s + '×'; setSetting('speed', s); }

  /* ---------- orientation / fullscreen ---------- */
  async function toggleLandscape() {
    landscape = !landscape;
    if (landscape) {
      await lockOrientation('landscape');
      if (!isNative() && root.requestFullscreen) { try { await root.requestFullscreen(); } catch { /* ignore */ } }
    } else {
      await lockOrientation(null);
      if (document.fullscreenElement) { try { await document.exitFullscreen(); } catch { /* ignore */ } }
    }
  }

  /* ---------- seek bar ---------- */
  function seekFromEvent(e, commit) {
    const r = bar.getBoundingClientRect();
    const p = clamp((e.clientX - r.left) / r.width, 0, 1);
    const d = video.duration || 0;
    const time = p * d;
    fill.style.width = p * 100 + '%'; knob.style.left = p * 100 + '%';
    curT.textContent = fmtDur(time);
    bubble.textContent = fmtDur(time); bubble.style.left = p * 100 + '%';
    if (commit && isFinite(d)) video.currentTime = time;
  }
  bar.addEventListener('pointerdown', (e) => { dragging = true; bar.classList.add('drag'); bar.setPointerCapture(e.pointerId); clearTimeout(uiTimer); seekFromEvent(e, false); });
  bar.addEventListener('pointermove', (e) => { if (dragging) seekFromEvent(e, false); });
  const endDrag = (e) => { if (!dragging) return; seekFromEvent(e, true); dragging = false; bar.classList.remove('drag'); showUI(); };
  bar.addEventListener('pointerup', endDrag);
  bar.addEventListener('pointercancel', () => { dragging = false; bar.classList.remove('drag'); });
  bar.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') seekBy(5); if (e.key === 'ArrowLeft') seekBy(-5); });

  /* ---------- gestures: tap, double-tap, hold for 2x ---------- */
  tapZone.addEventListener('pointerdown', (e) => {
    holding = false;
    clearTimeout(holdTimer);
    holdTimer = setTimeout(() => {
      if (video.paused || kind !== 'video') return;
      holding = true; video.playbackRate = 2; flash('2×', 'center');
    }, 520);
    lastX = e.clientX;
  });
  const endHold = () => { clearTimeout(holdTimer); if (holding) { holding = false; video.playbackRate = speed; indicator.className = 'v-ind'; return true; } return false; };
  tapZone.addEventListener('pointercancel', endHold);
  tapZone.addEventListener('pointerup', (e) => {
    if (endHold()) return;
    const now = performance.now();
    const r = tapZone.getBoundingClientRect();
    const rel = (e.clientX - r.left) / r.width;
    if (now - lastTap < 300 && Math.abs(e.clientX - lastX) < 90) {
      clearTimeout(tapTimer); lastTap = 0;
      if (rel < 0.34) seekBy(-10); else if (rel > 0.66) seekBy(10); else toggle();
    } else {
      lastTap = now; lastX = e.clientX;
      clearTimeout(tapTimer);
      tapTimer = setTimeout(toggleUI, 300);
    }
  });

  /* ---------- keyboard ---------- */
  const onKey = (e) => {
    if (e.target.matches('input, textarea')) return;
    const k = e.key;
    if (k === ' ' || k === 'k') { e.preventDefault(); toggle(); }
    else if (k === 'ArrowRight') seekBy(10);
    else if (k === 'ArrowLeft') seekBy(-10);
    else if (k === 'ArrowUp') { video.volume = clamp(video.volume + 0.1, 0, 1); flash(Math.round(video.volume * 100) + '%', 'center'); }
    else if (k === 'ArrowDown') { video.volume = clamp(video.volume - 0.1, 0, 1); flash(Math.round(video.volume * 100) + '%', 'center'); }
    else if (k === 'm') { video.muted = !video.muted; flash(video.muted ? t('muted') : t('unmuted'), 'center'); }
    else if (k === 'f') toggleLandscape();
    else if (k === 'n') go(1);
    else if (k === 'p') go(-1);
    else if (k === 'Escape' && !document.fullscreenElement) V.close();
    showUI();
  };
  document.addEventListener('keydown', onKey);

  /* ---------- video events ---------- */
  video.addEventListener('play', () => { setPlayIcon(); cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); keepAwake(true); showUI(); });
  video.addEventListener('pause', () => { setPlayIcon(); paint(); keepAwake(false); persist(); showUI(); });
  video.addEventListener('waiting', () => spinner.classList.add('show'));
  video.addEventListener('canplay', () => spinner.classList.remove('show'));
  video.addEventListener('playing', () => spinner.classList.remove('show'));
  video.addEventListener('loadedmetadata', () => { paint(); setPlayIcon(); });
  video.addEventListener('timeupdate', () => { if (video.paused) paint(); });
  video.addEventListener('ended', () => {
    saveProgress(cur.id, 1, 0);
    if (state.settings.autoNext && idx < items.length - 1) go(1); else { setPlayIcon(); showUI(); }
  });
  video.addEventListener('error', () => {
    const code = video.error?.code;
    if (code === 1) return;
    showError(kind === 'video' ? t('cannotPlayVideo') : t('cannotPlayAudio'));
  });
  saveTimer = setInterval(() => { if (!video.paused) persist(); }, 5000);

  function updateMediaSession() {
    if (!('mediaSession' in navigator)) return;
    try {
      const u = thumbURL(cur);
      navigator.mediaSession.metadata = new MediaMetadata({ title: cur.meta?.title || cur.name, artist: cur.meta?.author || 'AHOS Library', artwork: u ? [{ src: u, sizes: '420x420', type: 'image/jpeg' }] : [] });
      navigator.mediaSession.setActionHandler('play', () => video.play());
      navigator.mediaSession.setActionHandler('pause', () => video.pause());
      navigator.mediaSession.setActionHandler('previoustrack', items.length > 1 ? () => go(-1) : null);
      navigator.mediaSession.setActionHandler('nexttrack', items.length > 1 ? () => go(1) : null);
      navigator.mediaSession.setActionHandler('seekbackward', () => seekBy(-10));
      navigator.mediaSession.setActionHandler('seekforward', () => seekBy(10));
    } catch { /* optional */ }
  }

  function cleanup() {
    persist();
    clearInterval(saveTimer); clearTimeout(uiTimer); clearTimeout(holdTimer); clearTimeout(tapTimer); cancelAnimationFrame(raf);
    document.removeEventListener('keydown', onKey);
    try { video.pause(); } catch { /* ignore */ }
    video.removeAttribute('src'); video.load();
    if (url) URL.revokeObjectURL(url);
    subUrls.forEach((u) => URL.revokeObjectURL(u));
    keepAwake(false);
    if (landscape) lockOrientation(null);
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    immersive(false);
    if ('mediaSession' in navigator) { try { navigator.mediaSession.metadata = null; } catch { /* ignore */ } }
  }

  speedBtn.textContent = speed + '×';
  setPlayIcon();
  if (kind === 'video') immersive(true);
  load(idx);
}
