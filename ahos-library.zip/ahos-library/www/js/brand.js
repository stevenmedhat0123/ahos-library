// The AHOS mark: contour rings around a pyramid-shaped "A". Same artwork as the app icon.
export function mark(cls = '') {
  return `<svg class="mark ${cls}" viewBox="0 0 512 512" aria-hidden="true">
  <g fill="none" stroke="var(--mark-ring, #3CCBBC)" stroke-linecap="round">
    <ellipse cx="256" cy="292" rx="228" ry="176" transform="rotate(-14 256 292)" stroke-width="5" opacity=".35"/>
    <ellipse cx="256" cy="292" rx="186" ry="142" transform="rotate(-14 256 292)" stroke-width="8" opacity=".6"/>
    <ellipse cx="256" cy="292" rx="144" ry="108" transform="rotate(-14 256 292)" stroke-width="5" opacity=".4"/>
  </g>
  <path fill="var(--mark-a, #E7B94F)" d="M256 112 L396 396 H334 L256 238 L178 396 H116 Z"/>
  <path fill="var(--mark-a, #E7B94F)" d="M204 318 H308 V352 H204 Z"/>
</svg>`;
}
