// Inline SVG icon set (24x24, stroke based). ic('name') returns an <svg> string.

const P = (d, extra = '') => `<path d="${d}" ${extra}/>`;
const F = (d) => `<path d="${d}" fill="currentColor" stroke="none"/>`;
const dot = (x, y) => `<path d="M${x} ${y}h.01" stroke-width="2.6"/>`;

const I = {
  home: P('M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z'),
  library: P('M4 4h4v16H4zM10 4h4v16h-4zM16 6.2 19.4 5.2 22.4 17.6 19 18.6z'),
  plus: P('M12 5v14M5 12h14'),
  search: P('M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4'),
  settings: P('M4 7h9M17 7h3M4 17h3M11 17h9M15 7m-2 0a2 2 0 1 0 4 0 2 2 0 1 0-4 0M9 17m-2 0a2 2 0 1 0 4 0 2 2 0 1 0-4 0'),
  video: P('M4 6h11a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2zM17 10.5l5-3v9l-5-3z'),
  image: P('M4 4h16a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM3 17l5-5 4 4 3-3 6 6M9 9m-1.5 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0'),
  book: P('M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5zM5 19.5A1.5 1.5 0 0 0 6.5 21H19M9 7h6'),
  audio: P('M9 18V6l11-2v12M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z'),
  file: P('M6 3h8l5 5v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM14 3v5h5'),
  folder: P('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'),
  folderPlus: P('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM12 10.5v5M9.5 13h5'),
  star: P('M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9 6.8 19.7l1-5.9L3.5 9.7l5.9-.8z'),
  more: dot(12, 5.5) + dot(12, 12) + dot(12, 18.5),
  chev: P('M9 5l7 7-7 7'),
  back: P('M15 5l-7 7 7 7'),
  down: P('M5 9l7 7 7-7'),
  close: P('M6 6l12 12M18 6 6 18'),
  trash: P('M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3'),
  edit: P('M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4'),
  move: P('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 13h7M13.5 10.5 16 13l-2.5 2.5'),
  tag: P('M3 12V4h8l10 10-8 8zM7.5 8.5h.01', 'stroke-width="2.4"'),
  info: P('M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.6h.01', 'stroke-width="2"'),
  share: P('M12 3v12M7 8l5-5 5 5M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5'),
  lock: P('M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3'),
  unlock: P('M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 6.8-1.2'),
  check: P('M5 12.5l4.5 4.5L19 7.5'),
  checkCircle: P('M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8 12.5l3 3 5-6'),
  grid: P('M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z'),
  list: P('M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01', 'stroke-width="2.4"'),
  sort: P('M7 4v16M3.5 16.5 7 20l3.5-3.5M17 20V4M13.5 7.5 17 4l3.5 3.5'),
  play: F('M7 4.5v15l13-7.5z'),
  pause: F('M7 5h3.5v14H7zM13.5 5H17v14h-3.5z'),
  next: F('M6 5l10 7-10 7z') + P('M19 5v14', 'stroke-width="2.2"'),
  prev: F('M18 5 8 12l10 7z') + P('M5 5v14', 'stroke-width="2.2"'),
  rew10: P('M4 12a8 8 0 1 0 2.4-5.7M4 4v4.5h4.5') + '<text x="12" y="15.2" font-size="7.4" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700" font-family="Inter,sans-serif">10</text>',
  fwd10: P('M20 12a8 8 0 1 1-2.4-5.7M20 4v4.5h-4.5') + '<text x="12" y="15.2" font-size="7.4" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700" font-family="Inter,sans-serif">10</text>',
  speed: P('M4 18a9 9 0 1 1 16 0M12 14l4-5'),
  pip: P('M3 5h18v14H3zM12 12h7v5h-7z'),
  rotate: P('M20 12a8 8 0 1 1-2.5-5.8M20 4v4.5h-4.5'),
  fit: P('M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5'),
  cc: P('M3 6h18v12H3zM10.2 10.6a2.2 2.2 0 1 0 0 2.8M17.2 10.6a2.2 2.2 0 1 0 0 2.8'),
  download: P('M12 4v11M7 11l5 5 5-5M5 20h14'),
  upload: P('M12 16V4M7 9l5-5 5 5M5 20h14'),
  sun: P('M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4'),
  moon: P('M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z'),
  textsize: P('M2.5 19L8 5l5.5 14M4.6 14h6.8M21 12.4v5.2M21 15a2.6 2.6 0 1 0-5.2 0 2.6 2.6 0 0 0 5.2 0'),
  zoomIn: P('M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4M8 11h6M11 8v6'),
  zoomOut: P('M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4M8 11h6'),
  globe: P('M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18'),
  storage: P('M3 14h18v5H3zM6.5 16.5h.01M3 14l3-9h12l3 9', 'stroke-width="1.8"'),
  sparkle: P('M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z'),
  repeat: P('M4 12V9a3 3 0 0 1 3-3h11M15 3l3 3-3 3M20 12v3a3 3 0 0 1-3 3H6M9 21l-3-3 3-3'),
  moonStar: P('M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z'),
  select: P('M4 4h16v16H4zM8 12.5l3 3 5-6'),
  cloud: P('M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.5a4 4 0 0 1-.5 8.5z'),
  shield: P('M12 3l8 3v6c0 4.5-3.2 7.6-8 9-4.8-1.4-8-4.5-8-9V6z'),
  eye: P('M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12zM12 9.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z'),
  mobile: P('M7 3h10a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM11 18h2'),
};

export function ic(name, cls = '') {
  const inner = I[name] || I.file;
  return `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
}

export const kindIcon = { video: 'video', image: 'image', book: 'book', audio: 'audio', file: 'file' };
