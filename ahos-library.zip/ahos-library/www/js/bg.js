// The living background: a slowly drifting topographic map drawn with marching squares.
// Every 3rd contour is an "index" line, like a real survey map. It follows the page scroll.

let canvas, ctx, W = 0, H = 0, dpr = 1;
let cols = 0, rows = 0, vals = new Float32Array(0);
let raf = 0, last = 0, t0 = 0, scroll = 0, mode = 'full', paused = false;
let colA = '231,185,79', colB = '60,203,188', aMinor = 0.1, aMajor = 0.26;
const CELL = 22;
const LEVELS = [];
for (let i = -5; i <= 5; i++) LEVELS.push(i * 0.27);

function field(x, y, t) {
  return (
    Math.sin(x * 1.25 + t * 0.34) * 0.55 +
    Math.sin(y * 1.05 - t * 0.27 + Math.sin(x * 0.62 + t * 0.1) * 1.4) * 0.5 +
    Math.sin((x + y) * 0.74 + t * 0.2) * 0.38 +
    Math.cos(x * 1.9 - y * 1.6 + t * 0.14) * 0.22
  );
}

function readColors() {
  const cs = getComputedStyle(document.documentElement);
  colA = (cs.getPropertyValue('--c-line-a') || '231,185,79').trim();
  colB = (cs.getPropertyValue('--c-line-b') || '60,203,188').trim();
  aMinor = parseFloat(cs.getPropertyValue('--a-minor')) || 0.1;
  aMajor = parseFloat(cs.getPropertyValue('--a-major')) || 0.26;
}

function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  W = window.innerWidth; H = window.innerHeight;
  canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
  cols = Math.ceil(W / CELL) + 2; rows = Math.ceil(H / CELL) + 2;
  vals = new Float32Array(cols * rows);
  draw(performance.now());
}

function draw(now) {
  const t = ((now - t0) / 1000) * (mode === 'calm' ? 0.55 : 1);
  const oy = scroll * 0.0042;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) vals[j * cols + i] = field(i * CELL * 0.0105, j * CELL * 0.0105 + oy, t);
  }

  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, `rgba(${colA},1)`);
  g.addColorStop(0.55, `rgba(${colA},1)`);
  g.addColorStop(1, `rgba(${colB},1)`);

  for (const pass of [0, 1]) {
    ctx.beginPath();
    for (let li = 0; li < LEVELS.length; li++) {
      const major = li % 3 === 0;
      if ((pass === 1) !== major) continue;
      marching(LEVELS[li]);
    }
    ctx.globalAlpha = pass ? aMajor : aMinor;
    ctx.lineWidth = pass ? 1.35 : 0.8;
    ctx.strokeStyle = g;
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

function marching(L) {
  for (let j = 0; j < rows - 1; j++) {
    for (let i = 0; i < cols - 1; i++) {
      const a = vals[j * cols + i], b = vals[j * cols + i + 1], c = vals[(j + 1) * cols + i + 1], d = vals[(j + 1) * cols + i];
      const idx = (a > L ? 8 : 0) | (b > L ? 4 : 0) | (c > L ? 2 : 0) | (d > L ? 1 : 0);
      if (idx === 0 || idx === 15) continue;
      const x0 = i * CELL, y0 = j * CELL, x1 = x0 + CELL, y1 = y0 + CELL;
      const top = () => [x0 + CELL * ((L - a) / (b - a)), y0];
      const right = () => [x1, y0 + CELL * ((L - b) / (c - b))];
      const bottom = () => [x0 + CELL * ((L - d) / (c - d)), y1];
      const left = () => [x0, y0 + CELL * ((L - a) / (d - a))];
      const seg = (p, q) => { ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); };
      switch (idx) {
        case 1: case 14: seg(left(), bottom()); break;
        case 2: case 13: seg(bottom(), right()); break;
        case 3: case 12: seg(left(), right()); break;
        case 4: case 11: seg(top(), right()); break;
        case 5: seg(top(), left()); seg(bottom(), right()); break;
        case 6: case 9: seg(top(), bottom()); break;
        case 7: case 8: seg(top(), left()); break;
        case 10: seg(top(), right()); seg(left(), bottom()); break;
        default: break;
      }
    }
  }
}

function loop(now) {
  raf = requestAnimationFrame(loop);
  const gap = mode === 'calm' ? 70 : 42; // ~24fps / ~14fps
  if (now - last < gap) return;
  last = now;
  draw(now);
}

function run() {
  cancelAnimationFrame(raf);
  if (mode === 'off' || paused || document.hidden || matchMedia('(prefers-reduced-motion: reduce)').matches) { if (ctx) draw(performance.now()); return; }
  raf = requestAnimationFrame(loop);
}

export function startBackground(el) {
  canvas = el; ctx = canvas.getContext('2d');
  t0 = performance.now() - 14000 * 1; // start mid-way so the first frame already looks rich
  readColors(); resize(); run();
  window.addEventListener('resize', () => { resize(); });
  document.addEventListener('visibilitychange', run);
}

export const setScroll = (y) => { scroll = y; if (mode === 'off' || paused) draw(performance.now()); };
export function setMode(m) { mode = m; document.documentElement.dataset.bg = m; run(); }
export function setPaused(p) { paused = p; run(); }
export function refreshColors() { readColors(); if (ctx) draw(performance.now()); }
