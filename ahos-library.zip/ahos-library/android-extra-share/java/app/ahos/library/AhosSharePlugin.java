package app.ahos.library;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.StatFs;
import android.provider.OpenableColumns;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.util.ArrayList;

/**
 * Receives what other apps hand to AHOS Library ("Share" -> AHOS Library, or "Open with" -> AHOS Library) and tells the web page about it,
 * and reports how much room the phone has (for the optional "phone storage"). Nothing is copied here: the page reads each shared file
 * straight from its content address (/_capacitor_content_/...) while it imports it.
 */
@CapacitorPlugin(name = "AhosShare")
public class AhosSharePlugin extends Plugin {
    private JSObject pending = null;

    @Override
    public void load() {
        try {
            if (getActivity() != null) take(getActivity().getIntent());
        } catch (Exception e) {
            // nothing was shared
        }
    }

    // the app is already running and something new was shared / opened with it
    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        try {
            if (take(intent)) notifyListeners("shared", new JSObject(), true);
        } catch (Exception e) {
            // ignore a broken intent
        }
    }

    /** Reads the files / text out of an intent. Returns true when there was something. */
    private boolean take(Intent intent) {
        if (intent == null) return false;
        String action = intent.getAction();
        if (action == null) return false;
        boolean send = Intent.ACTION_SEND.equals(action), many = Intent.ACTION_SEND_MULTIPLE.equals(action), view = Intent.ACTION_VIEW.equals(action);
        if (!send && !many && !view) return false;

        ArrayList<Uri> uris = new ArrayList<>();
        String type = intent.getType();
        String text = null;
        try {
            if (view) {
                if (intent.getData() != null) uris.add(intent.getData());
            } else if (send) {
                @SuppressWarnings("deprecation")
                Uri u = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) uris.add(u);
                CharSequence tx = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
                if (tx != null) text = tx.toString();
            } else {
                @SuppressWarnings("deprecation")
                ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (list != null) uris.addAll(list);
            }
            ClipData clip = intent.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri u = clip.getItemAt(i).getUri();
                    if (u != null && !uris.contains(u)) uris.add(u);
                }
            }
        } catch (Exception e) {
            // keep what was read so far
        }

        JSArray items = new JSArray();
        ContentResolver cr = getContext().getContentResolver();
        for (Uri u : uris) {
            String scheme = u.getScheme();
            if (scheme == null || !("content".equals(scheme))) continue;   // file:// addresses are no longer shared between apps
            String name = null;
            long size = -1;
            Cursor c = null;
            try {
                c = cr.query(u, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
                if (c != null && c.moveToFirst()) {
                    if (!c.isNull(0)) name = c.getString(0);
                    if (!c.isNull(1)) size = c.getLong(1);
                }
            } catch (Exception e) {
                // some providers refuse the query: the name is worked out below
            } finally {
                if (c != null) c.close();
            }
            if (name == null || name.length() == 0) {
                String last = u.getLastPathSegment();
                name = last == null ? "file" : last;
                int slash = name.lastIndexOf('/');
                if (slash >= 0) name = name.substring(slash + 1);
            }
            String mime = null;
            try {
                mime = cr.getType(u);
            } catch (Exception e) {
                // fall back to the type the sender declared
            }
            if (mime == null || mime.length() == 0 || mime.indexOf('*') >= 0) mime = type;
            JSObject o = new JSObject();
            o.put("u", u.toString());
            o.put("n", name);
            o.put("m", mime == null ? "" : mime);
            o.put("s", size);
            items.put(o);
        }
        boolean hasText = text != null && text.trim().length() > 0 && items.length() == 0;
        if (items.length() == 0 && !hasText) return false;

        JSObject out = new JSObject();
        out.put("items", items);
        out.put("text", hasText ? text : "");
        out.put("action", view ? "view" : "send");
        pending = out;
        // the same intent must not be taken again when the activity is recreated
        try {
            intent.setAction(Intent.ACTION_MAIN);
            intent.removeExtra(Intent.EXTRA_STREAM);
            intent.removeExtra(Intent.EXTRA_TEXT);
            intent.setData(null);
        } catch (Exception e) {
            // ignore
        }
        return true;
    }

    /** What was shared / opened with the app since the page last asked: { items: [{u, n, m, s}], text, action } or { items: [] }. */
    @PluginMethod
    public void getShared(PluginCall call) {
        JSObject out = pending;
        pending = null;
        if (out == null) {
            out = new JSObject();
            out.put("items", new JSArray());
            out.put("text", "");
            out.put("action", "");
        }
        call.resolve(out);
    }

    /** Room on the phone's storage (where the app keeps its own files): { free, total }. */
    @PluginMethod
    public void diskInfo(PluginCall call) {
        JSObject o = new JSObject();
        try {
            File dir = getContext().getExternalFilesDir(null);
            if (dir == null) dir = getContext().getFilesDir();
            StatFs fs = new StatFs(dir.getAbsolutePath());
            o.put("free", fs.getAvailableBytes());
            o.put("total", fs.getTotalBytes());
        } catch (Exception e) {
            o.put("free", -1);
            o.put("total", -1);
        }
        call.resolve(o);
    }

    /**
     * Full screen ("immersive"): hides the status bar (clock, wifi, battery) and the navigation bar. A swipe from the top / bottom edge
     * shows them for a moment (this is also how the notification curtain is reached) and they hide again by themselves.
     * { on: true | false }
     */
    @PluginMethod
    public void setImmersive(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        final android.app.Activity a = getActivity();
        if (a == null) { call.resolve(); return; }
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.view.Window w = a.getWindow();
                    androidx.core.view.WindowInsetsControllerCompat c = androidx.core.view.WindowCompat.getInsetsController(w, w.getDecorView());
                    if (c != null) {
                        int bars = androidx.core.view.WindowInsetsCompat.Type.statusBars() | androidx.core.view.WindowInsetsCompat.Type.navigationBars();
                        if (on) {
                            c.setSystemBarsBehavior(androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                            c.hide(bars);
                        } else {
                            c.show(bars);
                        }
                    }
                } catch (Throwable e) {
                    // the page falls back to the SystemBars plugin
                }
                call.resolve();
            }
        });
    }
}
