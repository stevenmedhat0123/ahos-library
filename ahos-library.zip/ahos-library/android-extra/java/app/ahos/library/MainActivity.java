package app.ahos.library;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    static final String PREFS = "ahos_chrome";
    static final int DEFAULT_BG = 0xFF0B1233;
    // "fill": the page is drawn behind the camera hole (the page keeps its own safe-area padding), so a phone that hides the front camera
    // (ColorOS "Hide front camera") has no black line there: the app declares that it handles the camera area itself
    static final String DEFAULT_CUTOUT = "fill";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AhosPlaybackPlugin.class);
        // no title bar, asked for BEFORE the window is built. (The window must not be built before AppCompat's own set-up in super.onCreate:
        // the earlier release did that to ask for edge-to-edge, and a title bar with the app name then sat over the top of every page.)
        TopBand.noTitle(this);
        super.onCreate(savedInstanceState);
        // the colour the page had last time: the window is painted with it from the first frame, so nothing but the page's own colour is ever
        // visible around the camera, behind the status bar or while the page loads
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            applyChrome(this, sp.getInt("bg", DEFAULT_BG), sp.getBoolean("light", false), sp.getString("cutout", DEFAULT_CUTOUT));
        } catch (Throwable ignored) {
            applyChrome(this, DEFAULT_BG, false, DEFAULT_CUTOUT);
        }
        dropSplashAtOnce();
        // from now on nothing but the page may be at the top of the window
        TopBand.watch(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        TopBand.clean(this);
    }

    // Android 12+ keeps its own splash view above the page until the app says it is ready; on some phones (ColorOS with "Hide front camera")
    // that view lingers as a picture or a band over the header, so the buttons under it cannot be seen or tapped. The page is the first thing
    // drawn, so the splash is removed as soon as the system hands it over.
    private void dropSplashAtOnce() {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            getSplashScreen().setOnExitAnimationListener(new android.window.SplashScreen.OnExitAnimationListener() {
                @Override
                public void onSplashScreenExit(android.window.SplashScreenView view) {
                    try {
                        view.remove();
                    } catch (Throwable ignored) {
                        // already gone
                    }
                }
            });
        } catch (Throwable ignored) {
            // an older or customised system without the call: nothing to remove
        }
    }

    /**
     * The look of the window around the page: one solid colour everywhere (no splash picture, nothing stretched), the camera cut-out mode and the
     * colour of the status-bar icons. Called when the app starts and whenever the page changes its look (Settings).
     * cutout: "auto" = the phone decides (its own "Full screen for apps" setting – e.g. Hide front camera – is respected),
     *         "fill" = the page is drawn behind the camera (the default), "below" = the page stays under the camera and the bar there has the page's colour.
     */
    static void applyChrome(Activity a, int bg, boolean light, String cutout) {
        try {
            Window w = a.getWindow();
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = w.getAttributes();
                int mode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                if ("fill".equals(cutout)) {
                    mode = Build.VERSION.SDK_INT >= 30
                        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                } else if ("below".equals(cutout)) {
                    mode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
                }
                if (lp.layoutInDisplayCutoutMode != mode) {
                    lp.layoutInDisplayCutoutMode = mode;
                    w.setAttributes(lp);
                }
            }
            w.setBackgroundDrawable(new ColorDrawable(bg));
            w.getDecorView().setBackgroundColor(bg);
            if (Build.VERSION.SDK_INT < 35) {
                w.setStatusBarColor(Color.TRANSPARENT);
                w.setNavigationBarColor(Color.TRANSPARENT);
            }
            if (Build.VERSION.SDK_INT >= 29) {
                // no grey scrim behind the bars (what the edge-to-edge helper used to switch off)
                w.setStatusBarContrastEnforced(false);
                w.setNavigationBarContrastEnforced(false);
            }
            androidx.core.view.WindowInsetsControllerCompat c = androidx.core.view.WindowCompat.getInsetsController(w, w.getDecorView());
            if (c != null) {
                c.setAppearanceLightStatusBars(light);
                c.setAppearanceLightNavigationBars(light);
            }
            if (a instanceof BridgeActivity && ((BridgeActivity) a).getBridge() != null) {
                WebView wv = ((BridgeActivity) a).getBridge().getWebView();
                if (wv != null) {
                    wv.setBackgroundColor(bg);
                    ViewParent p = wv.getParent();
                    if (p instanceof View) ((View) p).setBackgroundColor(bg);
                }
                TopBand.clean((BridgeActivity) a);
            }
        } catch (Throwable ignored) {
            // cosmetic only: the page still works with the bars where the system puts them
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        keepPageAlive();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepPageAlive();
    }

    // keep the page (and the audio it plays) running while the app is in the background
    private void keepPageAlive() {
        if (AhosPlaybackPlugin.playing && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
