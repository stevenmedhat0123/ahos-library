package app.ahos.library;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AhosPlaybackPlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
        keepPageAlive();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepPageAlive();
    }

    // keep the page (and the audio it plays) running while the app is in the background
    private void keepPageAlive() {
        if (AhosPlaybackPlugin.playing && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
