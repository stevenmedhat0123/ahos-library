package app.ahos.library;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AhosPlaybackPlugin.class);
        enableEdgeToEdge();
        super.onCreate(savedInstanceState);
        fillWholeScreen();
    }

    // Capacitor 8 wants this before its own set-up so the web view is laid out edge to edge (the page adds its own padding below the status bar).
    // Done by reflection: if a future library drops the class nothing breaks, the window flags below still apply.
    private void enableEdgeToEdge() {
        try {
            Class.forName("androidx.activity.EdgeToEdge").getMethod("enable", androidx.activity.ComponentActivity.class).invoke(null, this);
        } catch (Throwable ignored) {
            // cosmetic only
        }
    }

    // The app draws on the whole screen, including behind the front-camera cut-out, instead of leaving a black bar there
    // (without this Android letterboxes the cut-out strip as soon as the status bar is hidden).
    private void fillWholeScreen() {
        try {
            android.view.Window w = getWindow();
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false);
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = android.os.Build.VERSION.SDK_INT >= 30
                    ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            w.getDecorView().setBackgroundColor(0xFF0B1233);
            if (android.os.Build.VERSION.SDK_INT < 35) {
                w.setStatusBarColor(android.graphics.Color.TRANSPARENT);
                w.setNavigationBarColor(android.graphics.Color.TRANSPARENT);
            }
        } catch (Throwable ignored) {
            // cosmetic only: the page still works with the bars where the system puts them
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        keepPageAlive();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepPageAlive();
    }

    // keep the page (and the audio it plays) running while the app is in the background
    private void keepPageAlive() {
        if (AhosPlaybackPlugin.playing && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
