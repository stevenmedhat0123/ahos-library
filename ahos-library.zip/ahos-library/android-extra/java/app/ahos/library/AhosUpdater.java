package app.ahos.library;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;

/** Downloads a new APK into the app's cache (with progress) and opens the system installer. */
final class AhosUpdater {
    interface Sink {
        void emit(String event, JSObject data);
    }

    private static volatile boolean cancelled = false;
    private static Thread worker = null;

    private AhosUpdater() {
    }

    static synchronized boolean start(final Context ctx, final String url, final String name, final Sink sink) {
        if (worker != null && worker.isAlive()) return false;
        cancelled = false;
        final File dir = new File(ctx.getCacheDir(), "ahos-update");
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                download(dir, url, name, sink);
            }
        }, "ahos-download");
        worker = t;
        t.start();
        return true;
    }

    static void cancel() {
        cancelled = true;
    }

    private static void send(Sink sink, String state, long bytes, long total, double speed, String path, String name, String error) {
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("bytes", bytes);
        o.put("total", total);
        o.put("speed", speed);
        if (path != null) o.put("path", path);
        if (name != null) o.put("name", name);
        if (error != null) o.put("error", error);
        sink.emit("download", o);
    }

    private static void download(File dir, String url, String name, Sink sink) {
        HttpURLConnection conn = null;
        InputStream in = null;
        OutputStream os = null;
        File part = null;
        String safe = "update.apk";
        try {
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) {
                for (File f : old) f.delete();
            }
            safe = name == null ? "update.apk" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safe.toLowerCase().endsWith(".apk")) safe = safe + ".apk";
            File out = new File(dir, safe);
            part = new File(dir, safe + ".part");
            send(sink, "start", 0, 0, 0, null, safe, null);
            conn = (HttpURLConnection) new URI(url).toURL().openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "AHOS-Library");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            long total = conn.getContentLength();
            in = conn.getInputStream();
            os = new FileOutputStream(part);
            byte[] buf = new byte[64 * 1024];
            long got = 0;
            long lastT = System.currentTimeMillis();
            long lastBytes = 0;
            double speed = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                if (cancelled) {
                    send(sink, "cancelled", got, total, 0, null, safe, null);
                    return;
                }
                os.write(buf, 0, n);
                got += n;
                long now = System.currentTimeMillis();
                if (now - lastT >= 350) {
                    double inst = (got - lastBytes) * 1000.0 / (now - lastT);
                    speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4;
                    lastT = now;
                    lastBytes = got;
                    send(sink, "progress", got, total, speed, null, safe, null);
                }
            }
            os.flush();
            os.close();
            os = null;
            if (total > 0 && got != total) throw new Exception("incomplete download");
            if (out.exists()) out.delete();
            if (!part.renameTo(out)) throw new Exception("could not save the file");
            send(sink, "done", got, got, 0, out.getAbsolutePath(), safe, null);
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            send(sink, "error", 0, 0, 0, null, safe, msg);
        } finally {
            try {
                if (os != null) os.close();
            } catch (Exception ignore) {
                // ignore
            }
            try {
                if (in != null) in.close();
            } catch (Exception ignore) {
                // ignore
            }
            if (conn != null) conn.disconnect();
            if (part != null && part.exists() && (cancelled)) part.delete();
        }
    }

    /** Opens the installer. When Android has not yet allowed this app to install packages, opens that setting instead. */
    static JSObject install(Context ctx, String path) {
        JSObject r = new JSObject();
        try {
            File f = new File(path == null ? "" : path);
            File dir = new File(ctx.getCacheDir(), "ahos-update");
            if (!f.isFile() || !f.getCanonicalPath().startsWith(dir.getCanonicalPath())) {
                r.put("ok", false);
                r.put("error", "missing");
                return r;
            }
            if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
                Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName()));
                s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(s);
                r.put("ok", false);
                r.put("needsPermission", true);
                return r;
            }
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".updates", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            r.put("ok", true);
        } catch (Exception e) {
            r.put("ok", false);
            r.put("error", e.getMessage() == null ? "install" : e.getMessage());
        }
        return r;
    }
}
