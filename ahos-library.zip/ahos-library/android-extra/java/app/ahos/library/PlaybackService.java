package app.ahos.library;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Bundle;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

/** Foreground service that keeps playback alive in the background and shows the media notification. */
public class PlaybackService extends Service {
    static final String CHANNEL = "ahos_playback";
    static final int NOTIF_ID = 4711;
    static final String ACTION_UPDATE = "app.ahos.library.UPDATE";
    static final String ACTION_CMD = "app.ahos.library.CMD";
    static PlaybackService instance;

    private MediaSession session;
    private PowerManager.WakeLock wake;
    private String title = "";
    private String artist = "";
    private boolean playing = false;
    private boolean hasPrev = false;
    private boolean hasNext = false;
    private long positionMs = 0;
    private long durationMs = 0;
    private float speed = 1f;
    private boolean foreground = false;

    // While playing, the notification counts the time itself once a second (the page only reports every few seconds).
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private long anchorPos = 0;
    private long anchorAt = 0;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!playing || !foreground) return;
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
            ticker.postDelayed(this, 1000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();
        session = new MediaSession(this, "AHOS Library");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                AhosPlaybackPlugin.emit("play", 0);
            }

            @Override
            public void onPause() {
                AhosPlaybackPlugin.emit("pause", 0);
            }

            @Override
            public void onSkipToNext() {
                AhosPlaybackPlugin.emit("next", 0);
            }

            @Override
            public void onSkipToPrevious() {
                AhosPlaybackPlugin.emit("prev", 0);
            }

            @Override
            public void onStop() {
                AhosPlaybackPlugin.emit("stop", 0);
            }

            @Override
            public void onSeekTo(long pos) {
                AhosPlaybackPlugin.emit("seek", pos / 1000.0);
            }

            @Override
            public void onRewind() {
                AhosPlaybackPlugin.emit("rew", 0);
            }

            @Override
            public void onFastForward() {
                AhosPlaybackPlugin.emit("fwd", 0);
            }

            @Override
            public void onCustomAction(String act, Bundle extras) {
                if ("rew".equals(act)) AhosPlaybackPlugin.emit("rew", 0);
                else if ("fwd".equals(act)) AhosPlaybackPlugin.emit("fwd", 0);
            }
        });
        session.setActive(true);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ahos:playback");
            wake.setReferenceCounted(false);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String a = intent.getAction();
            if (ACTION_CMD.equals(a)) {
                String cmd = intent.getStringExtra("cmd");
                AhosPlaybackPlugin.emit(cmd, 0);
                if ("stop".equals(cmd)) shutdown();
                else if (!foreground) stopSelf();
                return START_NOT_STICKY;
            }
            if (ACTION_UPDATE.equals(a)) {
                title = nz(intent.getStringExtra("title"));
                artist = nz(intent.getStringExtra("artist"));
                playing = intent.getBooleanExtra("playing", true);
                positionMs = intent.getLongExtra("positionMs", 0L);
                durationMs = intent.getLongExtra("durationMs", 0L);
                speed = intent.getFloatExtra("speed", 1f);
                hasPrev = intent.getBooleanExtra("hasPrev", false);
                hasNext = intent.getBooleanExtra("hasNext", false);
            }
        }
        render();
        return START_NOT_STICKY;
    }

    void apply(String t, String a, boolean isPlaying, long pos, long dur, float spd, boolean prev, boolean next) {
        title = nz(t);
        artist = nz(a);
        playing = isPlaying;
        positionMs = pos;
        durationMs = dur;
        speed = spd;
        hasPrev = prev;
        hasNext = next;
        render();
    }

    void shutdown() {
        foreground = false;
        ticker.removeCallbacks(tick);
        try {
            stopForeground(true);
        } catch (Exception e) {
            // ignore
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        ticker.removeCallbacksAndMessages(null);
        if (wake != null && wake.isHeld()) wake.release();
        if (session != null) {
            session.setActive(false);
            session.release();
        }
        instance = null;
        super.onDestroy();
    }

    private long currentPos() {
        if (!playing) return positionMs;
        long p = anchorPos + (long) ((SystemClock.elapsedRealtime() - anchorAt) * speed);
        if (durationMs > 0 && p > durationMs) p = durationMs;
        return p < 0 ? 0 : p;
    }

    private static String clock(long ms) {
        long s = ms / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void render() {
        updateSession();
        Notification n = buildNotification();
        if (!foreground) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
            foreground = true;
        } else {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, n);
        }
        anchorPos = positionMs;
        anchorAt = SystemClock.elapsedRealtime();
        ticker.removeCallbacks(tick);
        if (playing) ticker.postDelayed(tick, 1000);
        if (wake != null) {
            if (playing && !wake.isHeld()) wake.acquire(6L * 60L * 60L * 1000L);
            else if (!playing && wake.isHeld()) wake.release();
        }
    }

    private void updateSession() {
        MediaMetadata md = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs)
                .build();
        session.setMetadata(md);
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
        if (hasPrev) actions |= PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        if (hasNext) actions |= PlaybackState.ACTION_SKIP_TO_NEXT;
        PlaybackState.Builder sb = new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, positionMs, playing ? speed : 0f);
        if (durationMs > 0) {
            sb.addCustomAction("rew", "Back 10 s", android.R.drawable.ic_media_rew);
            sb.addCustomAction("fwd", "Forward 10 s", android.R.drawable.ic_media_ff);
        }
        session.setPlaybackState(sb.build());
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) return null;
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent cmdIntent(String cmd) {
        Intent i = new Intent(this, PlaybackService.class);
        i.setAction(ACTION_CMD);
        i.putExtra("cmd", cmd);
        return PendingIntent.getService(this, cmd.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification.Action action(int iconRes, String label, String cmd) {
        return new Notification.Action.Builder(Icon.createWithResource(this, iconRes), label, cmdIntent(cmd)).build();
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, CHANNEL);
        else b = new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_ahos)
                .setContentTitle(title)
                .setContentText(artist)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT);
        long pos = currentPos();
        b.setSubText(durationMs > 0 ? clock(pos) + " / " + clock(durationMs) : clock(pos));
        if (durationMs > 0) {
            int max = (int) Math.min((long) Integer.MAX_VALUE, durationMs);
            b.setProgress(max, (int) Math.min((long) max, pos), false);
        }
        PendingIntent open = openApp();
        if (open != null) b.setContentIntent(open);

        // [previous] [-10 s] [play/pause] [+10 s] [next]; a stop button only if there is room (5 is the most a media notification shows).
        // Dismissing a paused notification stops the service (delete intent).
        boolean seekable = durationMs > 0;
        int count = 0;
        int prevIdx = -1;
        int rewIdx = -1;
        int playIdx = -1;
        int fwdIdx = -1;
        int nextIdx = -1;
        if (hasPrev) {
            b.addAction(action(android.R.drawable.ic_media_previous, "Previous", "prev"));
            prevIdx = count++;
        }
        if (seekable) {
            b.addAction(action(android.R.drawable.ic_media_rew, "Back 10 s", "rew"));
            rewIdx = count++;
        }
        if (playing) b.addAction(action(android.R.drawable.ic_media_pause, "Pause", "pause"));
        else b.addAction(action(android.R.drawable.ic_media_play, "Play", "play"));
        playIdx = count++;
        if (seekable) {
            b.addAction(action(android.R.drawable.ic_media_ff, "Forward 10 s", "fwd"));
            fwdIdx = count++;
        }
        if (hasNext) {
            b.addAction(action(android.R.drawable.ic_media_next, "Next", "next"));
            nextIdx = count++;
        }
        if (count < 5) b.addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Stop", "stop"));
        b.setDeleteIntent(cmdIntent("stop"));

        int[] compact;
        if (prevIdx >= 0 && nextIdx >= 0) compact = new int[]{prevIdx, playIdx, nextIdx};
        else if (rewIdx >= 0 && fwdIdx >= 0) compact = new int[]{rewIdx, playIdx, fwdIdx};
        else if (nextIdx >= 0) compact = new int[]{playIdx, nextIdx};
        else if (prevIdx >= 0) compact = new int[]{prevIdx, playIdx};
        else compact = new int[]{playIdx};
        b.setStyle(new Notification.MediaStyle()
                .setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(compact));
        return b.build();
    }
}
