package app.ahos.library;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Foreground service that keeps playback alive in the background and shows the media notification. */
public class PlaybackService extends Service {
    static final String CHANNEL = "ahos_playback";
    static final int NOTIF_ID = 4711;
    static final String ACTION_UPDATE = "app.ahos.library.UPDATE";
    static final String ACTION_CMD = "app.ahos.library.CMD";
    static PlaybackService instance;

    private MediaSession session;
    private PowerManager.WakeLock wake;
    private String title = "";
    private String artist = "";
    private boolean playing = false;
    private boolean hasPrev = false;
    private boolean hasNext = false;
    private long positionMs = 0;
    private long durationMs = 0;
    private float speed = 1f;
    private boolean foreground = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();
        session = new MediaSession(this, "AHOS Library");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                AhosPlaybackPlugin.emit("play", 0);
            }

            @Override
            public void onPause() {
                AhosPlaybackPlugin.emit("pause", 0);
            }

            @Override
            public void onSkipToNext() {
                AhosPlaybackPlugin.emit("next", 0);
            }

            @Override
            public void onSkipToPrevious() {
                AhosPlaybackPlugin.emit("prev", 0);
            }

            @Override
            public void onStop() {
                AhosPlaybackPlugin.emit("stop", 0);
            }

            @Override
            public void onSeekTo(long pos) {
                AhosPlaybackPlugin.emit("seek", pos / 1000.0);
            }
        });
        session.setActive(true);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ahos:playback");
            wake.setReferenceCounted(false);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String a = intent.getAction();
            if (ACTION_CMD.equals(a)) {
                AhosPlaybackPlugin.emit(intent.getStringExtra("cmd"), 0);
                if (!foreground) stopSelf();
                return START_NOT_STICKY;
            }
            if (ACTION_UPDATE.equals(a)) {
                title = nz(intent.getStringExtra("title"));
                artist = nz(intent.getStringExtra("artist"));
                playing = intent.getBooleanExtra("playing", true);
                positionMs = intent.getLongExtra("positionMs", 0L);
                durationMs = intent.getLongExtra("durationMs", 0L);
                speed = intent.getFloatExtra("speed", 1f);
                hasPrev = intent.getBooleanExtra("hasPrev", false);
                hasNext = intent.getBooleanExtra("hasNext", false);
            }
        }
        render();
        return START_NOT_STICKY;
    }

    void apply(String t, String a, boolean isPlaying, long pos, long dur, float spd, boolean prev, boolean next) {
        title = nz(t);
        artist = nz(a);
        playing = isPlaying;
        positionMs = pos;
        durationMs = dur;
        speed = spd;
        hasPrev = prev;
        hasNext = next;
        render();
    }

    void shutdown() {
        foreground = false;
        try {
            stopForeground(true);
        } catch (Exception e) {
            // ignore
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (wake != null && wake.isHeld()) wake.release();
        if (session != null) {
            session.setActive(false);
            session.release();
        }
        instance = null;
        super.onDestroy();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void render() {
        updateSession();
        Notification n = buildNotification();
        if (!foreground) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
            foreground = true;
        } else {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, n);
        }
        if (wake != null) {
            if (playing && !wake.isHeld()) wake.acquire(6L * 60L * 60L * 1000L);
            else if (!playing && wake.isHeld()) wake.release();
        }
    }

    private void updateSession() {
        MediaMetadata md = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs)
                .build();
        session.setMetadata(md);
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
        if (hasPrev) actions |= PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        if (hasNext) actions |= PlaybackState.ACTION_SKIP_TO_NEXT;
        PlaybackState st = new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, positionMs, playing ? speed : 0f)
                .build();
        session.setPlaybackState(st);
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) return null;
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification.Action action(int iconRes, String label, String cmd) {
        Intent i = new Intent(this, PlaybackService.class);
        i.setAction(ACTION_CMD);
        i.putExtra("cmd", cmd);
        PendingIntent pi = PendingIntent.getService(this, cmd.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, iconRes), label, pi).build();
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, CHANNEL);
        else b = new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_ahos)
                .setContentTitle(title)
                .setContentText(artist)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT);
        PendingIntent open = openApp();
        if (open != null) b.setContentIntent(open);

        int count = 0;
        int prevIdx = -1;
        int playIdx = -1;
        int nextIdx = -1;
        if (hasPrev) {
            b.addAction(action(android.R.drawable.ic_media_previous, "Previous", "prev"));
            prevIdx = count++;
        }
        if (playing) b.addAction(action(android.R.drawable.ic_media_pause, "Pause", "pause"));
        else b.addAction(action(android.R.drawable.ic_media_play, "Play", "play"));
        playIdx = count++;
        if (hasNext) {
            b.addAction(action(android.R.drawable.ic_media_next, "Next", "next"));
            nextIdx = count++;
        }
        b.addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Stop", "stop"));

        int[] compact;
        if (prevIdx >= 0 && nextIdx >= 0) compact = new int[]{prevIdx, playIdx, nextIdx};
        else if (nextIdx >= 0) compact = new int[]{playIdx, nextIdx};
        else if (prevIdx >= 0) compact = new int[]{prevIdx, playIdx};
        else compact = new int[]{playIdx};
        b.setStyle(new Notification.MediaStyle()
                .setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(compact));
        return b.build();
    }
}
