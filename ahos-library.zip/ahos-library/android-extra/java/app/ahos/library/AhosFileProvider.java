package app.ahos.library;

import androidx.core.content.FileProvider;

/** Our own file provider (own authority), so the update installer does not depend on the template's provider. */
public class AhosFileProvider extends FileProvider {
}
