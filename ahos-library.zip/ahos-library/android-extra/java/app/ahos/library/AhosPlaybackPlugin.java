package app.ahos.library;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.WindowManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Bridges the web player to a foreground service (notification, lock-screen controls, background playback). */
@CapacitorPlugin(name = "AhosPlayback")
public class AhosPlaybackPlugin extends Plugin {
    static AhosPlaybackPlugin instance;
    static volatile boolean playing = false;

    @Override
    public void load() {
        instance = this;
    }

    static void emit(String action, double positionSec) {
        AhosPlaybackPlugin p = instance;
        if (p == null || action == null) return;
        JSObject o = new JSObject();
        o.put("action", action);
        o.put("position", positionSec);
        p.notifyListeners("action", o);
    }

    @PluginMethod
    public void update(PluginCall call) {
        final String title = call.getString("title", "");
        final String artist = call.getString("artist", "");
        final boolean isPlaying = Boolean.TRUE.equals(call.getBoolean("playing", true));
        final long positionMs = call.getInt("positionMs", 0);
        final long durationMs = call.getInt("durationMs", 0);
        final float speed = call.getDouble("speed", 1.0).floatValue();
        final boolean hasPrev = Boolean.TRUE.equals(call.getBoolean("hasPrev", false));
        final boolean hasNext = Boolean.TRUE.equals(call.getBoolean("hasNext", false));
        playing = isPlaying;
        final PlaybackService svc = PlaybackService.instance;
        try {
            if (svc != null) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        svc.apply(title, artist, isPlaying, positionMs, durationMs, speed, hasPrev, hasNext);
                    }
                });
            } else {
                Context ctx = getContext();
                Intent i = new Intent(ctx, PlaybackService.class);
                i.setAction(PlaybackService.ACTION_UPDATE);
                i.putExtra("title", title);
                i.putExtra("artist", artist);
                i.putExtra("playing", isPlaying);
                i.putExtra("positionMs", positionMs);
                i.putExtra("durationMs", durationMs);
                i.putExtra("speed", speed);
                i.putExtra("hasPrev", hasPrev);
                i.putExtra("hasNext", hasNext);
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
                else ctx.startService(i);
            }
        } catch (Exception e) {
            // starting a foreground service from the background can be refused; playback itself is unaffected
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        playing = false;
        final PlaybackService svc = PlaybackService.instance;
        if (svc != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    svc.shutdown();
                }
            });
        }
        call.resolve();
    }

    @PluginMethod
    public void keepScreenOn(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        final Activity a = getActivity();
        if (a != null) {
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }
        call.resolve();
    }

    @PluginMethod
    public void requestNotifyPermission(PluginCall call) {
        Activity a = getActivity();
        if (Build.VERSION.SDK_INT >= 33 && a != null
                && getContext().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
        call.resolve();
    }

    /* ---------------- in-app update: download with progress, then open the installer ---------------- */
    @PluginMethod
    public void downloadApk(PluginCall call) {
        String url = call.getString("url", "");
        String name = call.getString("name", "update.apk");
        if (url == null || !url.startsWith("https://")) {
            call.reject("bad url");
            return;
        }
        boolean started = AhosUpdater.start(getContext(), url, name, new AhosUpdater.Sink() {
            @Override
            public void emit(String event, JSObject data) {
                notifyListeners(event, data);
            }
        });
        JSObject o = new JSObject();
        o.put("started", started);
        call.resolve(o);
    }

    @PluginMethod
    public void cancelDownload(PluginCall call) {
        AhosUpdater.cancel();
        call.resolve();
    }

    @PluginMethod
    public void installApk(PluginCall call) {
        call.resolve(AhosUpdater.install(getContext(), call.getString("path", ""), !Boolean.TRUE.equals(call.getBoolean("probe", false))));
    }

    /* ---------------- notifications ---------------- */
    @PluginMethod
    public void notificationState(PluginCall call) {
        boolean on = true;
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) on = nm.areNotificationsEnabled();
        } catch (Exception e) {
            // assume enabled
        }
        JSObject o = new JSObject();
        o.put("enabled", on);
        o.put("needsAsk", Build.VERSION.SDK_INT >= 33 && getContext().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED);
        call.resolve(o);
    }

    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 26) {
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            // nothing to open
        }
        call.resolve();
    }
}
