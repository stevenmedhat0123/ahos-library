package app.ahos.library;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;

import com.getcapacitor.BridgeActivity;

/**
 * Keeps the top of the window clean: nothing but the page may be there.
 *
 * Some phones (and some themes) put a title bar, an action bar or a left-over start-up view above or over the page. The page then loses its
 * top (the back button, the header) and a coloured band with the app's name sits there instead. This class
 *  - asks for a window without a title before the window is built ({@link #noTitle}),
 *  - hides the action bar if there is one, and
 *  - hides every view that sits next to the page's own views on the way up to the window root (the page is the only thing the app draws),
 *    except the two bars the system paints for its own bars.
 * It runs when the app starts, whenever the app comes back, and (cheaply, at most about three times a second) when the layout changes.
 * What it hid is remembered for Settings > Screen check, so a screenshot says what was there.
 */
final class TopBand {
    private TopBand() { }

    /** What was hidden (class, id, height), for the Screen check. */
    static volatile String hidden = "";

    /** Before the window is built: no title bar and no action bar are asked for (a request made after the window exists would change nothing). */
    static void noTitle(BridgeActivity a) {
        try {
            a.requestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Throwable ignored) {
            // the window already exists: the cleaner below takes care of it
        }
        try {
            a.supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Throwable ignored) {
            // same
        }
    }

    /** After the window is built: clean now, a few times while the app starts, again whenever the layout changes (throttled). */
    static void watch(final BridgeActivity a) {
        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable run = new Runnable() {
            @Override
            public void run() {
                clean(a);
            }
        };
        h.post(run);
        long[] later = {150, 500, 1200, 3000, 7000};
        for (long ms : later) h.postDelayed(run, ms);
        try {
            final View decor = a.getWindow().getDecorView();
            decor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                private long last = 0;

                @Override
                public void onGlobalLayout() {
                    long now = SystemClock.uptimeMillis();
                    if (now - last < 300) return;
                    last = now;
                    clean(a);
                }
            });
        } catch (Throwable ignored) {
            // the timed runs above still happen
        }
    }

    /** One pass: hide the action bar(s) and everything beside the page on its way up to the window root. Safe to call any number of times. */
    static void clean(BridgeActivity a) {
        try {
            androidx.appcompat.app.ActionBar sab = a.getSupportActionBar();
            if (sab != null && sab.isShowing()) sab.hide();
        } catch (Throwable ignored) {
            // no action bar
        }
        try {
            android.app.ActionBar ab = a.getActionBar();
            if (ab != null && ab.isShowing()) ab.hide();
        } catch (Throwable ignored) {
            // no action bar
        }
        try {
            if (a.getBridge() == null || a.getBridge().getWebView() == null) return;
            View decor = a.getWindow().getDecorView();
            View v = a.getBridge().getWebView();
            float dp = a.getResources().getDisplayMetrics().density;
            int guard = 0;
            while (v != null && v != decor && guard++ < 24) {
                ViewParent p = v.getParent();
                if (!(p instanceof ViewGroup)) break;
                ViewGroup g = (ViewGroup) p;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View c = g.getChildAt(i);
                    if (c == v || c.getVisibility() == View.GONE || keep(c)) continue;
                    remember(c, dp);
                    c.setVisibility(View.GONE);
                }
                v = g;
            }
        } catch (Throwable ignored) {
            // cosmetic only
        }
    }

    /** The two views the system paints behind its own bars, and the action-mode (text selection) bar: not ours to hide. */
    private static boolean keep(View c) {
        String n = idName(c);
        return n.equals("statusBarBackground") || n.equals("navigationBarBackground") || n.startsWith("action_mode");
    }

    private static String idName(View v) {
        try {
            int id = v.getId();
            return id == View.NO_ID ? "" : v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "";
        }
    }

    private static void remember(View c, float dp) {
        try {
            String n = idName(c);
            String d = c.getClass().getSimpleName() + (n.isEmpty() ? "" : "#" + n) + " " + Math.round(c.getHeight() / dp) + "dp";
            if (!hidden.contains(d) && hidden.length() < 700) hidden = hidden + d + "; ";
        } catch (Throwable ignored) {
            // only the note is lost
        }
    }

    /** The views of the window as text (class, id, size in dp) down to the page: shown in the Screen check when something still looks wrong. */
    static String tree(Activity a) {
        StringBuilder sb = new StringBuilder();
        try {
            dump(a.getWindow().getDecorView(), 0, sb, a.getResources().getDisplayMetrics().density);
        } catch (Throwable ignored) {
            // whatever was collected
        }
        return sb.toString();
    }

    private static void dump(View v, int depth, StringBuilder sb, float dp) {
        if (sb.length() > 1400 || depth > 9) return;
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append(v.getClass().getSimpleName());
        String n = idName(v);
        if (!n.isEmpty()) sb.append('#').append(n);
        sb.append(' ').append(Math.round(v.getWidth() / dp)).append('x').append(Math.round(v.getHeight() / dp));
        if (v.getVisibility() == View.GONE) sb.append(" gone");
        else if (v.getVisibility() != View.VISIBLE) sb.append(" hidden");
        sb.append('\n');
        if (v instanceof android.webkit.WebView) return;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dump(g.getChildAt(i), depth + 1, sb, dp);
        }
    }
}
