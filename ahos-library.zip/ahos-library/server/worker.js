// AHOS Library — access server. Runs on Cloudflare Workers (free) with a D1 database bound as `DB`.
// Secrets/variables (Worker > Settings): SETUP_KEY = a long phrase only you know (needed once, to create the owner account).
// Passwords never reach this server in clear: the app sends a PBKDF2-derived value which is hashed again here.

const DAY = 86400000;
const UNITS = ['day', 'week', 'month', 'year', 'forever']; // 'forever' = no end date (stored as the year 3000)
const OWNER_TOKEN_DAYS = 30;
const USER_TOKEN_DAYS = 400;
const MAX_FAILS = 8;
const LOCK_MS = 15 * 60 * 1000;

const te = new TextEncoder();
const b64u = (buf) => { let s = ''; const a = new Uint8Array(buf); for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s).replace(/\+/g, '-').replace(/[/]/g, '_').replace(/=+$/, ''); };
const unb64u = (s) => { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s); const a = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; };
const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, '0')).join('');
const randHex = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-allow-headers': 'authorization, content-type',
  'access-control-max-age': '86400',
};
const reply = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...CORS } });
const fail = (error, status = 400, extra = {}) => reply({ ok: false, error, ...extra }, status);

/* ---------------- names ---------------- */
// Must stay identical to www/js/namekey.js (the app derives the password salt from this key).
function nameKey(name) {
  return String(name || '').normalize('NFKC')
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .toLowerCase().replace(/\s+/g, ' ').trim();
}
function validName(name) {
  const clean = String(name || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  if (clean.length > 80) return false;
  if (!/^[\p{L}\p{M}' -]+$/u.test(clean)) return false;
  const parts = clean.split(' ').filter((p) => p.replace(/[^\p{L}]/gu, '').length >= 2);
  return parts.length >= 4;
}
const cleanName = (name) => String(name || '').normalize('NFKC').replace(/\s+/g, ' ').trim();

/* ---------------- dates ---------------- */
const FOREVER_END = Date.UTC(3000, 0, 1);
function addDuration(from, amount, unit) {
  if (unit === 'forever' || from >= FOREVER_END) return FOREVER_END;
  if (unit === 'day') return from + amount * DAY;
  if (unit === 'week') return from + amount * 7 * DAY;
  const d = new Date(from);
  const months = unit === 'year' ? amount * 12 : amount;
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d.getTime();
}
const MAX_END = Date.UTC(2200, 0, 1);
function parseDuration(body) {
  const amount = Number(body.amount), unit = String(body.unit || '');
  if (unit === 'forever') return { amount: 1, unit };
  if (!Number.isInteger(amount) || amount < 1 || amount > 36500 || !UNITS.includes(unit)) return null;
  const probe = addDuration(Date.now(), amount, unit);
  if (!(probe < MAX_END)) return null;
  return { amount, unit };
}

/* ---------------- database ---------------- */
const SCHEMA = [
  'CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL)',
  'CREATE TABLE IF NOT EXISTS owner (id INTEGER PRIMARY KEY CHECK (id = 1), name TEXT NOT NULL, nkey TEXT NOT NULL, salt TEXT NOT NULL, pw TEXT NOT NULL, bsalt TEXT NOT NULL, bpw TEXT NOT NULL, ver INTEGER NOT NULL DEFAULT 1, created INTEGER NOT NULL)',
  'CREATE TABLE IF NOT EXISTS members (id TEXT PRIMARY KEY, name TEXT NOT NULL, nkey TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, pw TEXT NOT NULL, device TEXT, devchg INTEGER NOT NULL DEFAULT 0, sub_end INTEGER NOT NULL DEFAULT 0, last_code TEXT, blocked INTEGER NOT NULL DEFAULT 0, ver INTEGER NOT NULL DEFAULT 1, created INTEGER NOT NULL, seen INTEGER NOT NULL DEFAULT 0)',
  'CREATE TABLE IF NOT EXISTS codes (code TEXT PRIMARY KEY, amount INTEGER NOT NULL, unit TEXT NOT NULL, max_uses INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0, revoked INTEGER NOT NULL DEFAULT 0, note TEXT, created INTEGER NOT NULL)',
  'CREATE TABLE IF NOT EXISTS redemptions (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, member_id TEXT NOT NULL, at INTEGER NOT NULL, new_end INTEGER NOT NULL, UNIQUE (code, member_id))',
  'CREATE TABLE IF NOT EXISTS fails (k TEXT PRIMARY KEY, n INTEGER NOT NULL, until INTEGER NOT NULL DEFAULT 0, at INTEGER NOT NULL)',
];
let schemaReady = null;
function ensureSchema(env) {
  if (!schemaReady) {
    schemaReady = env.DB.batch(SCHEMA.map((s) => env.DB.prepare(s))).catch((e) => { schemaReady = null; throw e; });
  }
  return schemaReady;
}
const q = (env, sql, ...args) => env.DB.prepare(sql).bind(...args);
const first = (env, sql, ...args) => q(env, sql, ...args).first();
const all = async (env, sql, ...args) => (await q(env, sql, ...args).all()).results || [];
const run = (env, sql, ...args) => q(env, sql, ...args).run();

/* ---------------- passwords ---------------- */
const isHex64 = (s) => typeof s === 'string' && /^[0-9a-f]{64}$/.test(s);
async function hashPw(salt, pw) { return hex(await crypto.subtle.digest('SHA-256', te.encode(salt + ':' + pw))); }
function same(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

/* ---------------- brute-force protection ---------------- */
async function lockedFor(env, key) {
  const r = await first(env, 'SELECT n, until FROM fails WHERE k = ?', key);
  return r && r.until > Date.now() ? Math.ceil((r.until - Date.now()) / 1000) : 0;
}
async function noteFail(env, key) {
  const now = Date.now();
  const r = await first(env, 'SELECT n, until, at FROM fails WHERE k = ?', key);
  let n = r ? r.n + 1 : 1;
  if (r && now - r.at > LOCK_MS * 4 && r.until < now) n = 1;
  const until = n >= MAX_FAILS ? now + LOCK_MS : 0;
  if (until) n = 0;
  await run(env, 'INSERT INTO fails (k, n, until, at) VALUES (?, ?, ?, ?) ON CONFLICT(k) DO UPDATE SET n = excluded.n, until = excluded.until, at = excluded.at', key, n, until, now);
}
const clearFails = (env, key) => run(env, 'DELETE FROM fails WHERE k = ?', key);

/* ---------------- signed tokens (ECDSA P-256; the app verifies them offline with the public key) ---------------- */
let keyCache = null;
async function sigKeys(env) {
  if (keyCache) return keyCache;
  let row = await first(env, "SELECT v FROM meta WHERE k = 'sigkey'");
  if (!row) {
    const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
    const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
    const pub = await crypto.subtle.exportKey('jwk', kp.publicKey);
    await run(env, "INSERT OR IGNORE INTO meta (k, v) VALUES ('sigkey', ?)", JSON.stringify({ priv, pub }));
    row = await first(env, "SELECT v FROM meta WHERE k = 'sigkey'");
  }
  const { priv, pub } = JSON.parse(row.v);
  keyCache = {
    pub,
    sign: await crypto.subtle.importKey('jwk', priv, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']),
    verify: await crypto.subtle.importKey('jwk', pub, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']),
  };
  return keyCache;
}
async function signToken(env, payload) {
  const k = await sigKeys(env);
  const body = b64u(te.encode(JSON.stringify(payload)));
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, k.sign, te.encode(body));
  return body + '.' + b64u(sig);
}
async function readToken(env, req) {
  const h = req.headers.get('authorization') || '';
  const t = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  const [body, sig] = t.split('.');
  if (!body || !sig) return null;
  try {
    const k = await sigKeys(env);
    const ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k.verify, unb64u(sig), te.encode(body));
    if (!ok) return null;
    const p = JSON.parse(new TextDecoder().decode(unb64u(body)));
    return p && p.exp > Date.now() ? p : null;
  } catch { return null; }
}
const ownerToken = (env, o) => signToken(env, { r: 'owner', n: o.name, v: o.ver, iat: Date.now(), exp: Date.now() + OWNER_TOKEN_DAYS * DAY });
const userToken = (env, m) => signToken(env, { r: 'user', id: m.id, n: m.name, d: m.device || '', end: m.sub_end || 0, v: m.ver, iat: Date.now(), exp: Date.now() + USER_TOKEN_DAYS * DAY });

/* ---------------- request helpers ---------------- */
async function readBody(req) {
  if (req.method === 'GET') return {};
  const text = await req.text();
  if (text.length > 20000) throw new Error('too_big');
  if (!text) return {};
  return JSON.parse(text);
}
const memberOut = (m, redeemed = []) => ({
  id: m.id, name: m.name, created: m.created, seen: m.seen, end: m.sub_end, blocked: !!m.blocked,
  lastCode: m.last_code || '', deviceChanges: m.devchg, hasDevice: !!m.device, codes: redeemed,
});

async function requireOwner(env, req) {
  const p = await readToken(env, req);
  if (!p || p.r !== 'owner') return null;
  const o = await first(env, 'SELECT * FROM owner WHERE id = 1');
  if (!o || o.ver !== p.v) return null;
  return o;
}
async function requireUser(env, req, dev) {
  const p = await readToken(env, req);
  if (!p || p.r !== 'user') return { err: fail('bad_token', 401) };
  const m = await first(env, 'SELECT * FROM members WHERE id = ?', p.id);
  if (!m) return { err: fail('no_account', 401) };
  if (m.ver !== p.v) return { err: fail('session_ended', 401) };
  if (m.blocked) return { err: fail('blocked', 403) };
  if (m.device && m.device !== dev) return { err: fail('device_changed', 401) };
  return { m };
}

const CODE_CHARS = { up: 'ABCDEFGHJKLMNPQRSTUVWXYZ', lo: 'abcdefghijkmnpqrstuvwxyz', dg: '23456789', sy: '#@$%&*+=?!' };

/* ---------------- routes ---------------- */
const routes = {
  /* public */
  'GET /api/info': async (env) => {
    const k = await sigKeys(env);
    const o = await first(env, 'SELECT id FROM owner WHERE id = 1');
    return reply({ ok: true, v: 1, now: Date.now(), ownerExists: !!o, setupReady: !!env.SETUP_KEY, pub: k.pub });
  },

  /* owner */
  'POST /api/owner/claim': async (env, req, b) => {
    if (!env.SETUP_KEY) return fail('setup_disabled', 403);
    if (await first(env, 'SELECT id FROM owner WHERE id = 1')) return fail('owner_exists', 409);
    const lock = await lockedFor(env, 'claim');
    if (lock) return fail('locked', 429, { retry: lock });
    if (!same(String(b.setup || ''), String(env.SETUP_KEY))) { await noteFail(env, 'claim'); return fail('bad_setup_key', 403); }
    if (!validName(b.name)) return fail('bad_name');
    if (!isHex64(b.pw) || !isHex64(b.bpw) || b.pw === b.bpw) return fail('bad_request');
    const salt = randHex(16), bsalt = randHex(16);
    await run(env, 'INSERT INTO owner (id, name, nkey, salt, pw, bsalt, bpw, ver, created) VALUES (1, ?, ?, ?, ?, ?, ?, 1, ?)',
      cleanName(b.name), nameKey(b.name), salt, await hashPw(salt, b.pw), bsalt, await hashPw(bsalt, b.bpw), Date.now());
    await clearFails(env, 'claim');
    const o = await first(env, 'SELECT * FROM owner WHERE id = 1');
    return reply({ ok: true, token: await ownerToken(env, o), name: o.name });
  },
  'POST /api/owner/login': async (env, req, b) => {
    const lock = await lockedFor(env, 'owner');
    if (lock) return fail('locked', 429, { retry: lock });
    const o = await first(env, 'SELECT * FROM owner WHERE id = 1');
    if (!o) return fail('no_owner', 404);
    if (!isHex64(b.pw)) return fail('bad_request');
    const ok = o.nkey === nameKey(b.name) && same(await hashPw(o.salt, b.pw), o.pw);
    if (!ok) { await noteFail(env, 'owner'); return fail('bad_credentials', 401); }
    await clearFails(env, 'owner');
    return reply({ ok: true, token: await ownerToken(env, o), name: o.name });
  },
  'POST /api/owner/recover': async (env, req, b) => {
    const lock = await lockedFor(env, 'owner-recover');
    if (lock) return fail('locked', 429, { retry: lock });
    const o = await first(env, 'SELECT * FROM owner WHERE id = 1');
    if (!o) return fail('no_owner', 404);
    if (!isHex64(b.bpw) || !isHex64(b.pw)) return fail('bad_request');
    const ok = o.nkey === nameKey(b.name) && same(await hashPw(o.bsalt, b.bpw), o.bpw);
    if (!ok) { await noteFail(env, 'owner-recover'); return fail('bad_credentials', 401); }
    await clearFails(env, 'owner-recover');
    const salt = randHex(16);
    await run(env, 'UPDATE owner SET salt = ?, pw = ?, ver = ver + 1 WHERE id = 1', salt, await hashPw(salt, b.pw));
    const n = await first(env, 'SELECT * FROM owner WHERE id = 1');
    return reply({ ok: true, token: await ownerToken(env, n), name: n.name });
  },
  'POST /api/owner/password': async (env, req, b) => {
    const o = await requireOwner(env, req); if (!o) return fail('bad_token', 401);
    if (!isHex64(b.cur) || !isHex64(b.next)) return fail('bad_request');
    if (!same(await hashPw(o.salt, b.cur), o.pw)) return fail('bad_credentials', 401);
    const salt = randHex(16);
    await run(env, 'UPDATE owner SET salt = ?, pw = ?, ver = ver + 1 WHERE id = 1', salt, await hashPw(salt, b.next));
    const n = await first(env, 'SELECT * FROM owner WHERE id = 1');
    return reply({ ok: true, token: await ownerToken(env, n) });
  },
  'POST /api/owner/backup': async (env, req, b) => {
    const o = await requireOwner(env, req); if (!o) return fail('bad_token', 401);
    if (!isHex64(b.cur) || !isHex64(b.next)) return fail('bad_request');
    if (!same(await hashPw(o.bsalt, b.cur), o.bpw)) return fail('bad_credentials', 401);
    const bsalt = randHex(16);
    await run(env, 'UPDATE owner SET bsalt = ?, bpw = ? WHERE id = 1', bsalt, await hashPw(bsalt, b.next));
    return reply({ ok: true });
  },
  'POST /api/owner/check': async (env, req) => {
    const o = await requireOwner(env, req); if (!o) return fail('bad_token', 401);
    return reply({ ok: true, name: o.name });
  },

  /* owner: codes */
  'POST /api/admin/codes': async (env, req) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const codes = await all(env, 'SELECT * FROM codes ORDER BY created DESC');
    const reds = await all(env, 'SELECT r.code, r.at, m.name FROM redemptions r LEFT JOIN members m ON m.id = r.member_id ORDER BY r.at DESC');
    const by = new Map();
    for (const r of reds) { if (!by.has(r.code)) by.set(r.code, []); by.get(r.code).push({ name: r.name || '—', at: r.at }); }
    return reply({ ok: true, now: Date.now(), codes: codes.map((c) => ({ code: c.code, amount: c.amount, unit: c.unit, max: c.max_uses, used: c.used, revoked: !!c.revoked, note: c.note || '', created: c.created, by: by.get(c.code) || [] })) });
  },
  'POST /api/admin/code/create': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const dur = parseDuration(b); if (!dur) return fail('bad_duration');
    const max = Number(b.max);
    if (!Number.isInteger(max) || max < 0 || max > 100000) return fail('bad_uses'); // 0 = unlimited
    let code = String(b.code || '').trim();
    if (!code) {
      const pick = (set) => set[crypto.getRandomValues(new Uint32Array(1))[0] % set.length];
      const chars = [pick(CODE_CHARS.up), pick(CODE_CHARS.lo), pick(CODE_CHARS.dg), pick(CODE_CHARS.sy), pick(CODE_CHARS.sy)];
      const pool = CODE_CHARS.up + CODE_CHARS.lo + CODE_CHARS.dg;
      while (chars.length < 14) chars.push(pick(pool));
      for (let i = chars.length - 1; i > 0; i--) { const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1); [chars[i], chars[j]] = [chars[j], chars[i]]; }
      code = chars.join('');
    }
    if (!/^\S{4,64}$/u.test(code)) return fail('bad_code_format');
    if (await first(env, 'SELECT code FROM codes WHERE code = ?', code)) return fail('code_exists', 409);
    await run(env, 'INSERT INTO codes (code, amount, unit, max_uses, used, revoked, note, created) VALUES (?, ?, ?, ?, 0, 0, ?, ?)', code, dur.amount, dur.unit, max, String(b.note || '').slice(0, 120), Date.now());
    return reply({ ok: true, code });
  },
  'POST /api/admin/code/revoke': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const r = await run(env, 'UPDATE codes SET revoked = ? WHERE code = ?', b.revoked === false ? 0 : 1, String(b.code || ''));
    return r.meta.changes ? reply({ ok: true }) : fail('no_code', 404);
  },
  'POST /api/admin/code/delete': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const code = String(b.code || '');
    await env.DB.batch([q(env, 'DELETE FROM redemptions WHERE code = ?', code), q(env, 'DELETE FROM codes WHERE code = ?', code)]);
    return reply({ ok: true });
  },

  /* owner: members */
  'POST /api/admin/members': async (env, req) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const ms = await all(env, 'SELECT * FROM members ORDER BY created DESC');
    const reds = await all(env, 'SELECT code, member_id, at FROM redemptions ORDER BY at DESC');
    const by = new Map();
    for (const r of reds) { if (!by.has(r.member_id)) by.set(r.member_id, []); by.get(r.member_id).push({ code: r.code, at: r.at }); }
    return reply({ ok: true, now: Date.now(), members: ms.map((m) => memberOut(m, by.get(m.id) || [])) });
  },
  'POST /api/admin/member/extend': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const dur = parseDuration(b); if (!dur) return fail('bad_duration');
    const m = await first(env, 'SELECT * FROM members WHERE id = ?', String(b.id || ''));
    if (!m) return fail('no_account', 404);
    const end = addDuration(Math.max(Date.now(), m.sub_end || 0), dur.amount, dur.unit);
    if (!(end < MAX_END || end === FOREVER_END)) return fail('bad_duration');
    await run(env, 'UPDATE members SET sub_end = ? WHERE id = ?', end, m.id);
    return reply({ ok: true, end });
  },
  'POST /api/admin/member/end': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const r = await run(env, 'UPDATE members SET sub_end = 0 WHERE id = ?', String(b.id || ''));
    return r.meta.changes ? reply({ ok: true }) : fail('no_account', 404);
  },
  'POST /api/admin/member/block': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const r = await run(env, 'UPDATE members SET blocked = ? WHERE id = ?', b.blocked ? 1 : 0, String(b.id || ''));
    return r.meta.changes ? reply({ ok: true }) : fail('no_account', 404);
  },
  'POST /api/admin/member/device': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const r = await run(env, 'UPDATE members SET device = NULL WHERE id = ?', String(b.id || ''));
    return r.meta.changes ? reply({ ok: true }) : fail('no_account', 404);
  },
  'POST /api/admin/member/password': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    if (!isHex64(b.pw)) return fail('bad_request');
    const m = await first(env, 'SELECT id FROM members WHERE id = ?', String(b.id || ''));
    if (!m) return fail('no_account', 404);
    const salt = randHex(16);
    await run(env, 'UPDATE members SET salt = ?, pw = ?, ver = ver + 1, device = NULL WHERE id = ?', salt, await hashPw(salt, b.pw), m.id);
    return reply({ ok: true });
  },
  'POST /api/admin/member/delete': async (env, req, b) => {
    if (!(await requireOwner(env, req))) return fail('bad_token', 401);
    const id = String(b.id || '');
    await env.DB.batch([q(env, 'DELETE FROM redemptions WHERE member_id = ?', id), q(env, 'DELETE FROM members WHERE id = ?', id)]);
    return reply({ ok: true });
  },

  /* users */
  'POST /api/user/register': async (env, req, b) => {
    if (!validName(b.name)) return fail('bad_name');
    if (!isHex64(b.pw) || typeof b.dev !== 'string' || b.dev.length < 8 || b.dev.length > 80) return fail('bad_request');
    const key = nameKey(b.name);
    if (await first(env, 'SELECT id FROM members WHERE nkey = ?', key)) return fail('name_taken', 409);
    if ((await first(env, 'SELECT nkey FROM owner WHERE id = 1'))?.nkey === key) return fail('name_taken', 409);
    const id = randHex(12), salt = randHex(16), now = Date.now();
    await run(env, 'INSERT INTO members (id, name, nkey, salt, pw, device, devchg, sub_end, blocked, ver, created, seen) VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 1, ?, ?)',
      id, cleanName(b.name), key, salt, await hashPw(salt, b.pw), b.dev, now, now);
    const m = await first(env, 'SELECT * FROM members WHERE id = ?', id);
    return reply({ ok: true, token: await userToken(env, m), end: 0, now, name: m.name });
  },
  'POST /api/user/login': async (env, req, b) => {
    if (!isHex64(b.pw) || typeof b.dev !== 'string' || b.dev.length < 8 || b.dev.length > 80) return fail('bad_request');
    const key = nameKey(b.name);
    const lockKey = 'u:' + key;
    const lock = await lockedFor(env, lockKey);
    if (lock) return fail('locked', 429, { retry: lock });
    const m = await first(env, 'SELECT * FROM members WHERE nkey = ?', key);
    if (!m || !same(await hashPw(m.salt, b.pw), m.pw)) { await noteFail(env, lockKey); return fail('bad_credentials', 401); }
    await clearFails(env, lockKey);
    if (m.blocked) return fail('blocked', 403);
    const now = Date.now();
    const moved = m.device && m.device !== b.dev;
    await run(env, 'UPDATE members SET device = ?, devchg = devchg + ?, seen = ? WHERE id = ?', b.dev, moved ? 1 : 0, now, m.id);
    const n = await first(env, 'SELECT * FROM members WHERE id = ?', m.id);
    return reply({ ok: true, token: await userToken(env, n), end: n.sub_end, now, name: n.name });
  },
  'POST /api/user/status': async (env, req, b) => {
    const { m, err } = await requireUser(env, req, b.dev); if (err) return err;
    await run(env, 'UPDATE members SET seen = ? WHERE id = ?', Date.now(), m.id);
    return reply({ ok: true, token: await userToken(env, m), end: m.sub_end, now: Date.now(), name: m.name });
  },
  'POST /api/user/redeem': async (env, req, b) => {
    const { m, err } = await requireUser(env, req, b.dev); if (err) return err;
    const lockKey = 'c:' + m.id;
    const lock = await lockedFor(env, lockKey);
    if (lock) return fail('locked', 429, { retry: lock });
    const code = String(b.code || '').trim();
    const row = code ? await first(env, 'SELECT * FROM codes WHERE code = ?', code) : null;
    if (!row || row.revoked) { await noteFail(env, lockKey); return fail('bad_code', 404); }
    if (await first(env, 'SELECT id FROM redemptions WHERE code = ? AND member_id = ?', code, m.id)) return fail('code_mine', 409);
    if (row.max_uses > 0 && row.used >= row.max_uses) return fail('code_used_up', 410);
    const take = await run(env, 'UPDATE codes SET used = used + 1 WHERE code = ? AND revoked = 0 AND (max_uses = 0 OR used < max_uses)', code);
    if (!take.meta.changes) return fail('code_used_up', 410);
    const now = Date.now();
    const end = addDuration(Math.max(now, m.sub_end || 0), row.amount, row.unit);
    try {
      await env.DB.batch([
        q(env, 'INSERT INTO redemptions (code, member_id, at, new_end) VALUES (?, ?, ?, ?)', code, m.id, now, end),
        q(env, 'UPDATE members SET sub_end = ?, last_code = ? WHERE id = ?', end, code, m.id),
      ]);
    } catch (e) {
      await run(env, 'UPDATE codes SET used = used - 1 WHERE code = ? AND used > 0', code);
      return fail('code_mine', 409);
    }
    await clearFails(env, lockKey);
    const n = await first(env, 'SELECT * FROM members WHERE id = ?', m.id);
    return reply({ ok: true, token: await userToken(env, n), end, now, name: n.name });
  },
  'POST /api/user/password': async (env, req, b) => {
    const { m, err } = await requireUser(env, req, b.dev); if (err) return err;
    if (!isHex64(b.cur) || !isHex64(b.next)) return fail('bad_request');
    if (!same(await hashPw(m.salt, b.cur), m.pw)) return fail('bad_credentials', 401);
    const salt = randHex(16);
    await run(env, 'UPDATE members SET salt = ?, pw = ?, ver = ver + 1 WHERE id = ?', salt, await hashPw(salt, b.next), m.id);
    const n = await first(env, 'SELECT * FROM members WHERE id = ?', m.id);
    return reply({ ok: true, token: await userToken(env, n), end: n.sub_end, now: Date.now(), name: n.name });
  },
};

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(req.url);
    const handler = routes[`${req.method} ${url.pathname}`];
    if (!handler) {
      if (url.pathname === '/' || url.pathname === '') return new Response('AHOS Library access server is running.', { headers: { 'content-type': 'text/plain; charset=utf-8', ...CORS } });
      return fail('not_found', 404);
    }
    if (!env.DB) return fail('db_missing', 500);
    try {
      await ensureSchema(env);
      let body;
      try { body = await readBody(req); } catch { return fail('bad_request'); }
      if (!body || typeof body !== 'object') return fail('bad_request');
      return await handler(env, req, body);
    } catch (e) {
      console.error('server error', e && e.stack || e);
      return fail('server_error', 500);
    }
  },
};
