package app.ahos.library;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

/**
 * The plain activity (used when the build with the screen-colour / camera-area code could not be made, see ci/build.sh): it only registers the
 * playback plugin, asks for edge-to-edge by reflection and keeps the page alive while music plays in the background.
 */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AhosPlaybackPlugin.class);
        enableEdgeToEdge();
        super.onCreate(savedInstanceState);
    }

    private void enableEdgeToEdge() {
        try {
            Class.forName("androidx.activity.EdgeToEdge").getMethod("enable", androidx.activity.ComponentActivity.class).invoke(null, this);
        } catch (Throwable ignored) {
            // cosmetic only
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        keepPageAlive();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepPageAlive();
    }

    private void keepPageAlive() {
        if (AhosPlaybackPlugin.playing && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
