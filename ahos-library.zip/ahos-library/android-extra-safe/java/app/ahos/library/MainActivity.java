package app.ahos.library;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

/**
 * The plain activity (used when the build with the screen-colour / camera-area code could not be made, see ci/build.sh): it registers the
 * playback plugin, keeps the top of the window free of title / action bars (TopBand) and keeps the page alive while music plays in the background.
 */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AhosPlaybackPlugin.class);
        TopBand.noTitle(this);
        super.onCreate(savedInstanceState);
        TopBand.watch(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        TopBand.clean(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        keepPageAlive();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepPageAlive();
    }

    private void keepPageAlive() {
        if (AhosPlaybackPlugin.playing && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
