// Adds the native playback plugin (background audio, notification, keep-screen-on) to the generated Android project.
// Optional: ci/android.sh rebuilds without it if the Android build ever rejects it.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, copyFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const MAIN = join('android', 'app', 'src', 'main');
function copyDir(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const n of readdirSync(src)) {
    const s = join(src, n), d = join(dst, n);
    if (statSync(s).isDirectory()) copyDir(s, d); else copyFileSync(s, d);
  }
}
copyDir(join('android-extra', 'java'), join(MAIN, 'java'));
if (existsSync(join('android-extra', 'res'))) copyDir(join('android-extra', 'res'), join(MAIN, 'res'));

const mf = join(MAIN, 'AndroidManifest.xml');
let m = readFileSync(mf, 'utf8');
// each piece is added only if it is not there yet, so running this twice is harmless
const addInApp = (marker, xml) => { if (!m.includes(marker)) m = m.replace('</application>', xml + '\n    </application>'); };
addInApp('PlaybackService', '    <service android:name=".PlaybackService" android:exported="false" android:foregroundServiceType="mediaPlayback" />');
// the in-app updater hands the downloaded APK to the system installer through this provider
addInApp('AhosFileProvider', '    <provider android:name=".AhosFileProvider" android:authorities="${applicationId}.updates" android:exported="false" android:grantUriPermissions="true" />');
const perms = ['FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'REQUEST_INSTALL_PACKAGES']
  .filter((p) => !m.includes(`android.permission.${p}"`))
  .map((p) => `    <uses-permission android:name="android.permission.${p}" />\n`).join('');
if (perms) m = m.replace('</manifest>', perms + '</manifest>');
writeFileSync(mf, m);
console.log('native playback + updater plugin added');
