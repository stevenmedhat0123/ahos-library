// Adds the native plugins to the generated Android project.  Usage: node tools/patch-native.mjs [extras]
//   base (default): playback (background audio, notification, keep-screen-on) + in-app updater
//   folder: + the folder / Google Drive picker (android-extra-folder/)
//   share:  + "Share to AHOS Library" / "Open with" and the phone-storage disk info (android-extra-share/)
//   (joined with +, e.g. folder+share; the old numbers still work: 1 = base, 2 = folder, 3 = folder+share)
// Optional: ci/build.sh rebuilds with fewer extras if the Android build ever rejects them.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, copyFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const ARG = String(process.argv[2] || 'base');
const FEATURES = new Set(ARG === '2' ? ['folder'] : ARG === '3' ? ['folder', 'share'] : ARG.split('+'));
const LEVEL = ARG;
const MAIN = join('android', 'app', 'src', 'main');
function copyDir(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const n of readdirSync(src)) {
    const s = join(src, n), d = join(dst, n);
    if (statSync(s).isDirectory()) copyDir(s, d); else copyFileSync(s, d);
  }
}
copyDir(join('android-extra', 'java'), join(MAIN, 'java'));
const register = (cls) => {
  const act = join(MAIN, 'java', 'app', 'ahos', 'library', 'MainActivity.java');
  let a = readFileSync(act, 'utf8');
  if (!a.includes(cls)) a = a.replace('registerPlugin(AhosPlaybackPlugin.class);', `registerPlugin(AhosPlaybackPlugin.class);\n        registerPlugin(${cls}.class);`);
  writeFileSync(act, a);
};
if (FEATURES.has('folder') && existsSync('android-extra-folder')) {
  copyDir(join('android-extra-folder', 'java'), join(MAIN, 'java'));
  register('AhosFolderPlugin');
}
if (FEATURES.has('share') && existsSync('android-extra-share')) {
  copyDir(join('android-extra-share', 'java'), join(MAIN, 'java'));
  register('AhosSharePlugin');
}
if (existsSync(join('android-extra', 'res'))) copyDir(join('android-extra', 'res'), join(MAIN, 'res'));

const mf = join(MAIN, 'AndroidManifest.xml');
let m = readFileSync(mf, 'utf8');
// each piece is added only if it is not there yet, so running this twice is harmless
const addInApp = (marker, xml) => { if (!m.includes(marker)) m = m.replace('</application>', xml + '\n    </application>'); };
addInApp('PlaybackService', '    <service android:name=".PlaybackService" android:exported="false" android:foregroundServiceType="mediaPlayback" />');
// the in-app updater hands the downloaded APK to the system installer through this provider
addInApp('AhosFileProvider', '    <provider android:name=".AhosFileProvider" android:authorities="${applicationId}.updates" android:exported="false" android:grantUriPermissions="true" />');
if (FEATURES.has('share') && !m.includes('android.intent.action.SEND')) {
  // "Share" and "Open with" entries for AHOS Library: files of any kind, one or many (the page decides what it can open)
  const mimes = ['video/*', 'audio/*', 'image/*', 'application/pdf', 'application/epub+zip', 'application/zip', 'text/*', 'application/octet-stream'];
  const data = mimes.map((x) => `            <data android:mimeType="${x}" />`).join('\n');
  const filters = [
    `        <intent-filter>\n            <action android:name="android.intent.action.SEND" />\n            <category android:name="android.intent.category.DEFAULT" />\n            <data android:mimeType="*/*" />\n        </intent-filter>`,
    `        <intent-filter>\n            <action android:name="android.intent.action.SEND_MULTIPLE" />\n            <category android:name="android.intent.category.DEFAULT" />\n            <data android:mimeType="*/*" />\n        </intent-filter>`,
    `        <intent-filter>\n            <action android:name="android.intent.action.VIEW" />\n            <category android:name="android.intent.category.DEFAULT" />\n            <category android:name="android.intent.category.BROWSABLE" />\n            <data android:scheme="content" />\n${data}\n        </intent-filter>`,
  ].join('\n');
  // the first <activity> is MainActivity; a new share while the app is open must reach the running page, not start a second copy
  m = m.replace(/<activity\b([^>]*)>/, (all, attrs) => (/android:launchMode=/.test(attrs) ? all : `<activity${attrs} android:launchMode="singleTask">`));
  const i = m.indexOf('</activity>');
  if (i > 0) m = m.slice(0, i) + filters + '\n    ' + m.slice(i);
}
const perms = ['FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'REQUEST_INSTALL_PACKAGES']
  .filter((p) => !m.includes(`android.permission.${p}"`))
  .map((p) => `    <uses-permission android:name="android.permission.${p}" />\n`).join('');
if (perms) m = m.replace('</manifest>', perms + '</manifest>');
writeFileSync(mf, m);
console.log(`native plugins added (level ${LEVEL})`);
