// Adds the native playback plugin (background audio, notification, keep-screen-on) to the generated Android project.
// Optional: ci/android.sh rebuilds without it if the Android build ever rejects it.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, copyFileSync } from 'node:fs';
import { join } from 'node:path';

const MAIN = join('android', 'app', 'src', 'main');
function copyDir(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const n of readdirSync(src)) {
    const s = join(src, n), d = join(dst, n);
    if (statSync(s).isDirectory()) copyDir(s, d); else copyFileSync(s, d);
  }
}
copyDir(join('android-extra', 'java'), join(MAIN, 'java'));
copyDir(join('android-extra', 'res'), join(MAIN, 'res'));

const mf = join(MAIN, 'AndroidManifest.xml');
let m = readFileSync(mf, 'utf8');
if (!m.includes('PlaybackService')) {
  m = m.replace('</application>', '    <service android:name=".PlaybackService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n    </application>');
  const perms = ['FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'POST_NOTIFICATIONS', 'WAKE_LOCK']
    .filter((p) => !m.includes(`android.permission.${p}"`))
    .map((p) => `    <uses-permission android:name="android.permission.${p}" />\n`).join('');
  m = m.replace('</manifest>', perms + '</manifest>');
  writeFileSync(mf, m);
}
console.log('native playback plugin added');
