// Launcher-icon choice (feature "ui"): turns the manifest's launcher entry into <activity-alias>es, one per icon. Replaced by the real implementation.
export default async function patchIcons() { /* real implementation comes from the app-icons work */ }
