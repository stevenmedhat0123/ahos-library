// Customises the freshly generated Capacitor Android project: icons, splash colour, manifest, signing, version.
// Runs in CI after `npx cap add android`. Cosmetic steps never fail the build; signing/version steps do.
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, copyFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';

const ANDROID = 'android';
const APP = join(ANDROID, 'app');
const RES = join(APP, 'src', 'main', 'res');
const warn = (m) => console.warn('::warning::' + m);
const rel = JSON.parse(readFileSync('release.json', 'utf8'));
const build = parseInt(process.env.BUILD_NUMBER || '1', 10) || 1;
const BG = '#0B1233';

function copyDir(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const n of readdirSync(src)) {
    const s = join(src, n), d = join(dst, n);
    if (statSync(s).isDirectory()) copyDir(s, d); else copyFileSync(s, d);
  }
}

/* ---- icons + splash image ---- */
try {
  for (const d of readdirSync(RES)) {
    if (/^drawable(-|$)/.test(d) && existsSync(join(RES, d, 'splash.png'))) rmSync(join(RES, d, 'splash.png'));
  }
  copyDir('android-res', RES);
  const anydpi = join(RES, 'mipmap-anydpi-v26');
  mkdirSync(anydpi, { recursive: true });
  for (const n of ['ic_launcher', 'ic_launcher_round']) {
    writeFileSync(join(anydpi, n + '.xml'),
      `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n`);
  }
  console.log('icons + splash copied');
} catch (e) { warn('icons: ' + e.message); }

/* ---- splash background colour (Android 12+ system splash) ---- */
try {
  const f = join(RES, 'values', 'styles.xml');
  let s = readFileSync(f, 'utf8');
  const re = /(<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>)([\s\S]*?)(<\/style>)/;
  if (re.test(s)) {
    s = s.replace(re, (_, a, body, c) => {
      body = body.replace(/\s*<item name="windowSplashScreenBackground">[^<]*<\/item>/g, '');
      return `${a}${body}\n        <item name="windowSplashScreenBackground">${BG}</item>\n    ${c}`;
    });
    writeFileSync(f, s);
    console.log('splash colour set');
  } else warn('styles.xml: launch theme not found, splash colour left as default');
} catch (e) { warn('styles: ' + e.message); }

/* ---- manifest: no cloud backup (the library never leaves the phone), bigger heap for large files ---- */
try {
  const f = join(APP, 'src', 'main', 'AndroidManifest.xml');
  let s = readFileSync(f, 'utf8');
  s = s.replace(/android:allowBackup="[^"]*"/, 'android:allowBackup="false"');
  if (!/android:largeHeap=/.test(s)) s = s.replace(/<application\b/, '<application android:largeHeap="true"');
  writeFileSync(f, s);
  console.log('manifest patched');
} catch (e) { warn('manifest: ' + e.message); }

/* ---- gradle: signing + version + lint (appended; Gradle merges repeated android {} blocks) ---- */
const gradle = join(APP, 'build.gradle');
if (!existsSync(gradle)) { console.error('app/build.gradle not found'); process.exit(1); }
const block = `

// ---- added by tools/patch-android.mjs ----
android {
    defaultConfig {
        versionCode = ${build}
        versionName = "${String(rel.version).replace(/"/g, '')}"
    }
    signingConfigs {
        release {
            storeFile = file(System.getenv("AHOS_KEYSTORE") ?: "release.keystore")
            storePassword = System.getenv("AHOS_STORE_PASSWORD")
            keyAlias = System.getenv("AHOS_KEY_ALIAS") ?: "ahos"
            keyPassword = System.getenv("AHOS_STORE_PASSWORD")
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.release
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
`;
let g = readFileSync(gradle, 'utf8');
if (!g.includes('added by tools/patch-android.mjs')) writeFileSync(gradle, g + block);
console.log(`gradle patched: versionCode ${build}, versionName ${rel.version}`);
