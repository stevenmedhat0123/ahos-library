// Renders the app icon at every size needed (PWA + Android). Needs `sharp` (dev only).
import sharp from 'sharp';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const art = (scale = 1) => `
<g transform="translate(256 262) scale(${scale}) translate(-256 -262)">
  <g fill="none" stroke-linecap="round" transform="rotate(-14 256 292)">
    <ellipse cx="256" cy="292" rx="236" ry="182" stroke="#3CCBBC" stroke-width="4" opacity=".28"/>
    <ellipse cx="256" cy="292" rx="196" ry="150" stroke="#3CCBBC" stroke-width="9" opacity=".62"/>
    <ellipse cx="256" cy="292" rx="154" ry="116" stroke="#E7B94F" stroke-width="4" opacity=".42"/>
    <ellipse cx="256" cy="292" rx="114" ry="84" stroke="#E7B94F" stroke-width="3" opacity=".28"/>
  </g>
  <path fill="url(#gold)" d="M256 106 L400 400 H336 L256 236 L176 400 H112 Z"/>
  <path fill="url(#gold)" d="M200 318 H312 V354 H200 Z"/>
</g>`;
const defs = `<defs>
  <radialGradient id="bg" cx="30%" cy="16%" r="100%"><stop offset="0" stop-color="#2434A0"/><stop offset=".5" stop-color="#111B58"/><stop offset="1" stop-color="#070B22"/></radialGradient>
  <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F8DC8A"/><stop offset="1" stop-color="#D49A28"/></linearGradient>
</defs>`;
const svg = (inner, { bg = true, clip = '' } = {}) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${defs}${clip}${bg ? '<rect width="512" height="512" fill="url(#bg)"/>' : ''}${inner}</svg>`;

async function png(svgText, size, file) {
  mkdirSync(dirname(file), { recursive: true });
  await sharp(Buffer.from(svgText), { density: 300 }).resize(size, size).png({ compressionLevel: 9 }).toFile(file);
}

const out = (p) => join(root, p);
// PWA icons
await png(svg(art(1)), 192, out('www/icons/icon-192.png'));
await png(svg(art(1)), 512, out('www/icons/icon-512.png'));
await png(svg(art(0.74)), 512, out('www/icons/icon-maskable-512.png'));

// Android launcher icons (copied over the generated Capacitor project by tools/patch-android.mjs)
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
const round = `<clipPath id="rc"><circle cx="256" cy="256" r="256"/></clipPath>`;
const squircle = `<clipPath id="sq"><rect width="512" height="512" rx="112"/></clipPath>`;
for (const [d, k] of Object.entries(dens)) {
  const base = `android-res/mipmap-${d}`;
  await png(svg(`<g clip-path="url(#sq)">${art(0.9)}</g>`, { bg: false, clip: squircle }).replace('<defs>', '<defs>').replace('</defs>', '</defs><rect width="512" height="512" rx="112" fill="url(#bg)"/>'), Math.round(48 * k), out(`${base}/ic_launcher.png`));
  await png(svg(`<g clip-path="url(#rc)">${art(0.86)}</g>`, { bg: false, clip: round }).replace('</defs>', '</defs><circle cx="256" cy="256" r="256" fill="url(#bg)"/>'), Math.round(48 * k), out(`${base}/ic_launcher_round.png`));
  await png(svg(art(0.58), { bg: false }), Math.round(108 * k), out(`${base}/ic_launcher_foreground.png`));
}
mkdirSync(out('android-res/values'), { recursive: true });
writeFileSync(out('android-res/values/ic_launcher_background.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B1233</color>\n</resources>\n');

// Splash (square so it crops cleanly on any screen)
await png(svg(art(0.42)), 2048, out('android-res/drawable/splash.png'));
console.log('icons done');
