// Renders the app icon at every size needed (PWA + Android). Needs `sharp` (dev only).
import sharp from 'sharp';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { markArt } from '../www/js/brand.js';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const art = (scale = 1, dy = 0) => `<g transform="translate(256 ${262 + dy}) scale(${scale}) translate(-256 -262)">${markArt('a')}</g>`;
const defs = `<defs>
  <radialGradient id="bg" cx="28%" cy="12%" r="115%"><stop offset="0" stop-color="#2B1C86"/><stop offset=".45" stop-color="#120F45"/><stop offset="1" stop-color="#04050E"/></radialGradient>
  <radialGradient id="glowR" cx="85%" cy="95%" r="55%"><stop offset="0" stop-color="#FF3D6A" stop-opacity=".35"/><stop offset="1" stop-color="#FF3D6A" stop-opacity="0"/></radialGradient>
  <radialGradient id="glowB" cx="10%" cy="90%" r="55%"><stop offset="0" stop-color="#2F86FF" stop-opacity=".35"/><stop offset="1" stop-color="#2F86FF" stop-opacity="0"/></radialGradient>
  <linearGradient id="shine" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
</defs>`;
const bgFill = `<rect width="512" height="512" fill="url(#bg)"/><rect width="512" height="512" fill="url(#glowR)"/><rect width="512" height="512" fill="url(#glowB)"/>`;
const gloss = `<path d="M0 0 H512 V150 C380 215 130 215 0 150Z" fill="url(#shine)"/>`;
const svg = (inner, { bg = true, clip = '', shine = true } = {}) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${defs}${clip}${bg ? bgFill : ''}${inner}${bg && shine ? gloss : ''}</svg>`;

async function png(svgText, size, file) {
  mkdirSync(dirname(file), { recursive: true });
  await sharp(Buffer.from(svgText), { density: 300 }).resize(size, size).png({ compressionLevel: 9 }).toFile(file);
}

const out = (p) => join(root, p);
// PWA icons
await png(svg(art(0.98)), 192, out('www/icons/icon-192.png'));
await png(svg(art(0.98)), 512, out('www/icons/icon-512.png'));
await png(svg(art(0.72)), 512, out('www/icons/icon-maskable-512.png'));

// Android launcher icons (copied over the generated Capacitor project by tools/patch-android.mjs)
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
const sq = `<clipPath id="sq"><rect width="512" height="512" rx="112"/></clipPath>`;
const rc = `<clipPath id="rc"><circle cx="256" cy="256" r="256"/></clipPath>`;
for (const [d, k] of Object.entries(dens)) {
  const base = `android-res/mipmap-${d}`;
  const px = Math.round(48 * k);
  await png(svg(`<g clip-path="url(#sq)">${bgFill}${art(0.9)}${gloss}</g>`, { bg: false, clip: sq }), px, out(`${base}/ic_launcher.png`));
  await png(svg(`<g clip-path="url(#rc)">${bgFill}${art(0.8)}${gloss}</g>`, { bg: false, clip: rc }), px, out(`${base}/ic_launcher_round.png`));
  // adaptive icon: full-bleed 108dp layer, artwork kept inside the central safe zone
  await png(svg(art(0.66)), Math.round(108 * k), out(`${base}/ic_launcher_foreground.png`));
}
mkdirSync(out('android-res/values'), { recursive: true });
writeFileSync(out('android-res/values/ic_launcher_background.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B0E2E</color>\n</resources>\n');

// Splash (square so it crops cleanly on any screen)
await png(svg(art(0.46), { shine: false }), 2048, out('android-res/drawable/splash.png'));
console.log('icons done');
