// Generates www/sw.js with the list of files to cache. Run after changing anything inside www/.
import { readdirSync, statSync, readFileSync, writeFileSync } from 'node:fs';
import { join, relative, dirname, resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', 'www');
const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else files.push(relative(root, p).split('\\').join('/'));
  }
})(root);
const list = files.filter((f) => f !== 'sw.js' && !f.endsWith('.map') && f !== 'update.json').sort();
const hash = createHash('sha1');
for (const f of list) { hash.update(f); hash.update(readFileSync(join(root, f))); }
const tpl = readFileSync(join(root, '..', 'tools', 'sw.template.js'), 'utf8');
const out = tpl.replace('__HASH__', hash.digest('hex').slice(0, 10)).replace('__FILES__', JSON.stringify(['./', ...list], null, 1));
writeFileSync(join(root, 'sw.js'), out);
console.log(`sw.js: ${list.length} files cached`);

// Start-up speed: list every module the app needs at launch in index.html, so the browser fetches them all at once
// instead of discovering them one level at a time (main -> app -> views -> ...). Only static imports; lazy ones stay lazy.
const seen = new Set();
const queue = [join(root, 'js', 'main.js')];
while (queue.length) {
  const f = queue.shift();
  if (seen.has(f)) continue;
  seen.add(f);
  const src = readFileSync(f, 'utf8');
  for (const m of src.matchAll(/^\s*(?:import|export)\s[^'"`;]*?from\s*['"](\.[^'"]+)['"]|^\s*import\s*['"](\.[^'"]+)['"]/gm)) {
    const target = resolve(dirname(f), m[1] || m[2]);
    if (target.endsWith('.js')) queue.push(target);
  }
}
const preload = [...seen].map((f) => relative(root, f).split('\\').join('/')).sort((a, b) => (a === 'js/main.js' ? -1 : b === 'js/main.js' ? 1 : a.localeCompare(b)));
const indexPath = join(root, 'index.html');
let html = readFileSync(indexPath, 'utf8');
const block = `<!--preload-->\n${preload.map((f) => `<link rel="modulepreload" href="${f}">`).join('\n')}\n<!--/preload-->`;
if (/<!--preload-->[\s\S]*?<!--\/preload-->/.test(html)) html = html.replace(/<!--preload-->[\s\S]*?<!--\/preload-->/, block);
else html = html.replace('</head>', block + '\n</head>');
writeFileSync(indexPath, html);
console.log(`index.html: ${preload.length} startup modules preloaded`);
