// Generates www/sw.js with the list of files to cache. Run after changing anything inside www/.
import { readdirSync, statSync, readFileSync, writeFileSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', 'www');
const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else files.push(relative(root, p).split('\\').join('/'));
  }
})(root);
const list = files.filter((f) => f !== 'sw.js' && !f.endsWith('.map') && f !== 'update.json').sort();
const hash = createHash('sha1');
for (const f of list) { hash.update(f); hash.update(readFileSync(join(root, f))); }
const tpl = readFileSync(join(root, '..', 'tools', 'sw.template.js'), 'utf8');
const out = tpl.replace('__HASH__', hash.digest('hex').slice(0, 10)).replace('__FILES__', JSON.stringify(['./', ...list], null, 1));
writeFileSync(join(root, 'sw.js'), out);
console.log(`sw.js: ${list.length} files cached`);
