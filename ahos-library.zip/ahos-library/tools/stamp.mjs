// Writes www/update.json for this build (version, build number, channel, GitHub repo) and refreshes sw.js.
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const rel = JSON.parse(readFileSync('release.json', 'utf8'));
const build = parseInt(process.env.BUILD_NUMBER || '0', 10) || 0;
const repo = process.env.REPO || '';
const channel = rel.channel === 'stable' ? 'stable' : 'beta';
// Address of the access server (Cloudflare Worker). Empty = no sign-in screen. The GitHub variable AHOS_SERVER wins over release.json.
let server = String(process.env.AHOS_SERVER || rel.server || '').trim().replace(/\/+$/, '');
if (server && !/^https:\/\/[^\s/]+/i.test(server)) { console.warn(`AHOS_SERVER "${server}" ignored: it must start with https://`); server = ''; }
writeFileSync('www/update.json', JSON.stringify({ version: String(rel.version), build, channel, repo, server }, null, 2) + '\n');
execFileSync(process.execPath, ['tools/build-sw.mjs'], { stdio: 'inherit' });
console.log(`stamped: v${rel.version} build ${build} (${channel}) ${repo}${server ? ' · access server on' : ' · no access server'}`);
