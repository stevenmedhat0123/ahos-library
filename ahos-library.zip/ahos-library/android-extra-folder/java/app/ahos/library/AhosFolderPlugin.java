package app.ahos.library;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayDeque;

/**
 * Lets the person pick a whole folder (or a whole Google Drive account) with Android's own folder picker, lists everything inside it,
 * and lets the web page read each file straight from the picker's content address (/_capacitor_content_/...).
 * Nothing here copies or uploads anything.
 */
@CapacitorPlugin(name = "AhosFolder")
public class AhosFolderPlugin extends Plugin {
    private static final String DRIVE_AUTHORITY = "com.google.android.apps.docs.storage";
    private static final int MAX_FILES = 200000;

    private static void hint(Intent i, boolean drive) {
        if (!drive || Build.VERSION.SDK_INT < 26) return;
        try {
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildRootUri(DRIVE_AUTHORITY, "root"));
        } catch (Exception e) {
            // only a hint: the person can still open Drive from the picker's side menu
        }
    }

    @PluginMethod
    public void pickFolder(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        hint(i, Boolean.TRUE.equals(call.getBoolean("drive", false)));
        startActivityForResult(call, i, "folderResult");
    }

    @ActivityCallback
    private void folderResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject o = new JSObject();
        if (result == null || result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            o.put("cancelled", true);
            call.resolve(o);
            return;
        }
        Uri tree = result.getData().getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception e) {
            // the permission lasts while the app runs anyway
        }
        o.put("cancelled", false);
        o.put("uri", tree.toString());
        o.put("name", treeName(tree));
        call.resolve(o);
    }

    private String treeName(Uri tree) {
        String name = "";
        Cursor c = null;
        try {
            String id = DocumentsContract.getTreeDocumentId(tree);
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, id);
            c = getContext().getContentResolver().query(doc, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst() && !c.isNull(0)) name = c.getString(0);
        } catch (Exception e) {
            name = "";
        } finally {
            if (c != null) c.close();
        }
        return name == null ? "" : name;
    }

    /** Lists every file under the picked folder: {u: address, p: folder inside the picked one, n: name, s: bytes, m: type, d: modified}. */
    @PluginMethod
    public void scan(final PluginCall call) {
        final String treeStr = call.getString("uri");
        if (treeStr == null || treeStr.length() == 0) {
            call.reject("no folder");
            return;
        }
        final Uri tree = Uri.parse(treeStr);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    call.resolve(listTree(tree));
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    private JSObject listTree(Uri tree) {
        ContentResolver cr = getContext().getContentResolver();
        JSArray files = new JSArray();
        long bytes = 0;
        int dirs = 0, count = 0, skipped = 0;
        boolean truncated = false;
        long lastEmit = 0;
        ArrayDeque<String[]> queue = new ArrayDeque<String[]>();
        queue.add(new String[]{DocumentsContract.getTreeDocumentId(tree), ""});
        String[] cols = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_FLAGS};
        while (!queue.isEmpty() && !truncated) {
            String[] cur = queue.poll();
            Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, cur[0]);
            Cursor c = null;
            try {
                c = cr.query(kids, cols, null, null, null);
                while (c != null && c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.isNull(1) ? "" : c.getString(1);
                    String mime = c.isNull(2) ? "" : c.getString(2);
                    if (id == null || name.length() == 0) continue;
                    if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        if (name.startsWith(".")) continue;
                        dirs++;
                        queue.add(new String[]{id, cur[1].length() == 0 ? name : cur[1] + "/" + name});
                        continue;
                    }
                    int flags = c.isNull(5) ? 0 : c.getInt(5);
                    if ((flags & DocumentsContract.Document.FLAG_VIRTUAL_DOCUMENT) != 0 || mime.startsWith("application/vnd.google-apps")) {
                        skipped++;
                        continue;
                    }
                    if (name.startsWith(".")) continue;
                    long size = c.isNull(3) ? -1 : c.getLong(3);
                    long mod = c.isNull(4) ? 0 : c.getLong(4);
                    JSObject f = new JSObject();
                    f.put("u", DocumentsContract.buildDocumentUriUsingTree(tree, id).toString());
                    f.put("p", cur[1]);
                    f.put("n", name);
                    f.put("s", size);
                    f.put("m", mime);
                    f.put("d", mod);
                    files.put(f);
                    count++;
                    if (size > 0) bytes += size;
                    if (count >= MAX_FILES) {
                        truncated = true;
                        break;
                    }
                    long now = System.currentTimeMillis();
                    if (now - lastEmit > 350) {
                        lastEmit = now;
                        JSObject e = new JSObject();
                        e.put("files", count);
                        e.put("dirs", dirs);
                        notifyListeners("scan", e);
                    }
                }
            } catch (Exception e) {
                // a folder that cannot be read is left out; the rest is still listed
                skipped++;
            } finally {
                if (c != null) c.close();
            }
        }
        JSObject out = new JSObject();
        out.put("files", files);
        out.put("dirs", dirs);
        out.put("bytes", bytes);
        out.put("skipped", skipped);
        out.put("truncated", truncated);
        return out;
    }

    /** Some files (used by "Drive" -> files): the system picker, many at once. Resolves with {files: [{u, n, s, m}]}. */
    @PluginMethod
    public void pickFiles(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        hint(i, Boolean.TRUE.equals(call.getBoolean("drive", false)));
        startActivityForResult(call, i, "filesResult");
    }

    @ActivityCallback
    private void filesResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject out = new JSObject();
        JSArray files = new JSArray();
        Intent data = result == null ? null : result.getData();
        if (result == null || result.getResultCode() != Activity.RESULT_OK || data == null) {
            out.put("cancelled", true);
            out.put("files", files);
            call.resolve(out);
            return;
        }
        ContentResolver cr = getContext().getContentResolver();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int k = 0; k < clip.getItemCount(); k++) addOne(cr, files, clip.getItemAt(k).getUri());
        } else if (data.getData() != null) {
            addOne(cr, files, data.getData());
        }
        out.put("cancelled", false);
        out.put("files", files);
        call.resolve(out);
    }

    private void addOne(ContentResolver cr, JSArray files, Uri uri) {
        if (uri == null) return;
        String name = "";
        long size = -1;
        Cursor c = null;
        try {
            c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                if (!c.isNull(0)) name = c.getString(0);
                if (!c.isNull(1)) size = c.getLong(1);
            }
        } catch (Exception e) {
            // keep what we have
        } finally {
            if (c != null) c.close();
        }
        if (name == null || name.length() == 0) name = "file";
        String type = cr.getType(uri);
        JSObject f = new JSObject();
        f.put("u", uri.toString());
        f.put("p", "");
        f.put("n", name);
        f.put("s", size);
        f.put("m", type == null ? "" : type);
        f.put("d", 0);
        files.put(f);
    }
}
